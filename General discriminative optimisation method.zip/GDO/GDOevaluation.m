function [iRSGDO,MSEGDO,Runtime] = GDOevaluation(DM,Rtest1,Xtest1,MSEGDO,iRSGDO,normals,F,Mdl1)
   maxIter = 100;
   stopThres = 0.001;
   sigmaSq = 0.03;
   starttime_gdo = tic;
   [GDOYout,Ystep,Xstep] =inferGDO(DM,{Xtest1},maxIter,stopThres,sigmaSq,normals,F,Mdl1);%GDO
   runtime_gdo = toc(starttime_gdo);
    Runtime = runtime_gdo;
   if size(DM.Xmodel,2)>3
   Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*DM.Xmodel,Rtest1(1:3,4));% groundtruth
   else
   Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*DM.Xmodel',Rtest1(1:3,4));% groundtruth   
   end
   Xgts = single(Xstep{end}{1,1});
   [irsgdo, msegdo, judgement ] = isRegisterSuccessful( Xgt', Xgts');
   iRSGDO=[iRSGDO;irsgdo];
   MSEGDO=[MSEGDO;msegdo];

end

