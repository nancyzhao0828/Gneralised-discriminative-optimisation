function [D1] = pwSqDistfeature(F,F1)
%PWSQDIST pairwise squared distance
D1 = sum(F.*F, 2)*ones(1, length(F1)) + ones(length(F), 1) * sum(F1.*F1, 2)' - 2*F*F1';
end

