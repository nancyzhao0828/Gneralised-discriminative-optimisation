 clc;
 clear;
 nMap = 30; % number of maps
 sigmaSq = 0.03; % will be used for calculating feature function h
 beta=0.1;
 gridStep=0.05;
nTrain = 3000; % number of training samples
load('C:\Users\zy080\Documents\MATLAB\RDO\RDO\Handtest\DM.mat')
load('C:\Users\zy080\Documents\MATLAB\RDO\RDO\Handtest\Trainingdata3000.mat')
[DMDO,trainErr] = learnDO(modelSmp,Xtrain,Ytrain,nMap,sigmaSq,gridStep);
[DMGDO,errorGDO] = learnGDO(modelSmp,Xtrain,Ytrain,nMap,sigmaSq,gridStep);
% [DMGDO,errorGDO] = learnGDOnotime(modelSmp,Xtrain,Ytrain,nMap,sigmaSq,gridStep);
clc;
clear;
% load('C:\Users\zy080\Documents\MATLAB\Dog\Child\matlabDM.mat')
load('C:\Users\zy080\Documents\MATLAB\RDO\RDO\Happytest\DM.mat')
load('C:\Users\zy080\Documents\MATLAB\RDO\RDO\Happytest\Outliers\Outliers500.mat')
iRSDO=[];MSEDO=[];
iRSGDO=[];MSEGDO=[];
RuntimeGDO=zeros(1,75);
RuntimeDO=zeros(1,75);
for k=1:length(Xtest)
    Xtest{1,k}=single(Xtest{1,k});
    Ytest{1,k}=single(Ytest{1,k});
end
     gridStep=0.05;
      x = -2:gridStep:2;
      [X1,Y1,Z1] = meshgrid(x,x,x);
      D1 = [X1(:) Y1(:) Z1(:)]';
      Xmodel = DMDO.Xmodel; 
      [F,Mdl] = PDFnorm(Xmodel',D1);
      [ normals ] = findPointNormals(Xmodel,6,[0 0 0]);
for k=1:75
    Xtest1=Xtest{1,k};
    Rtest1=Rtest{1,k};
    [iRSDO,MSEDO,RuntimeDO(1,k)] = DOevaluation(DMDO,Rtest1,Xtest1,MSEDO,iRSDO);
    [iRSGDO,MSEGDO,RuntimeGDO(1,k)] = GDOevaluation(DMGDO,Rtest1,Xtest1,MSEGDO,iRSGDO,normals,F,Mdl);
%  [iRSGDO,MSEGDO,RuntimeGDO(1,k)] = GDOevaluationnotime(DMGDO,Rtest1,Xtest1,MSEGDO,iRSGDO,normals,F,Mdl);
end
mGDO=mean(MSEGDO);
mRuntimeGDO=mean(RuntimeGDO);
mDO=mean(MSEDO);
mRuntimeDO=mean(RuntimeDO);
A1=find(iRSDO~=1); 
B=find(iRSGDO~=1);
a=length(find(iRSDO~=1));
b=length(find(iRSGDO~=1));
ra=1-a/length(iRSDO);
rb=1-b/length(iRSGDO);
