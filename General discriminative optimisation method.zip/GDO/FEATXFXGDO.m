function [ lameda1,lameda2 ] = FEATXFXGDO( featX,featXF )
    A=cov(featXF');
    B=cov(featX');
    a=trace(A);
    b=trace(B);
    lameda1=a/(a+b);
    lameda2=b/(a+b);
end