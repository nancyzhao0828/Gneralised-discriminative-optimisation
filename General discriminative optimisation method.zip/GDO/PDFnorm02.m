function [F1] = PDFnorm02(modelSmp,Mdl)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
Xmodel=modelSmp;
% pcmptFeat.Dist = pwSqDist(Xmodel,D);
% for i=1:size(pcmptFeat.Dist',2)
%   [B(i,:),I(i,:)] = sort(pcmptFeat.Dist(i,:));
% end
IdxNN = knnsearch(Mdl,Xmodel','K',1);% for each point in Q, to find the nearest k points in Mdl;
I1=IdxNN(:,1);
I1U=unique(I1);
for i=1:length(I1U)
[M{i,1},n] = find(I1==I1U(i,1));
MC{i,1}=Xmodel(:,M{i,1});
sigma=zeros(3);
for k=1:size(MC{i,1},2)
sigma=((MC{i,1}(:,k)-mean(MC{i,1},2))*(MC{i,1}(:,k)-mean(MC{i,1},2))'+sigma);
end
Mmu{i,1}=mean(MC{i,1},2);
Sigmamatrix{i,1}=sigma/k;
end
for i=1:length(Xmodel)
 a=find(I1U==I1(i,1));
F1(i,1)= exp(-1*(Xmodel(:,i)-Mmu{a,1})'*pinv(Sigmamatrix{a,1})*(Xmodel(:,i)-Mmu{a,1})/2);
end
end

