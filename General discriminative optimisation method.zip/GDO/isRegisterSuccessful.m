function [ iRS, MSE , judgement] = isRegisterSuccessful( model, transformedPointCloud)
iRS = 0;
largestD = findLargestD(model);
MSE=immse(model,transformedPointCloud);
judgement = largestD * 0.05;
if MSE <= judgement
    iRS = 1;
end
end

function [largestD] = findLargestD(model)
largestD = 0;
for i = 1:length(model)
    for j = i:length(model)
        point1 = model(i,:);
        point2 = model(j,:);
        D = calculateD(point1, point2);
        if D > largestD
            largestD = D;
        end
    end
end
end

function [D] = calculateD(point1, point2)
x = point1;
y = point2;
if length(x)==3
 D = sqrt((x(1) - y(1)).^2 + (x(2) - y(2)).^2 + (x(3) - y(3)).^2);
else
D = sqrt((x(1) - y(1)).^2 + (x(2) - y(2)).^2);
end
end

function [nearestPoint] = findNearestPoint(model, point)
    x = model(:,1);
    y = model(:,2);
    if size(model,2)==3
    z = model(:,3);
    d = sqrt((point(1)-x).^2 + (point(2)-y).^2 + (point(3)-z).^2);
    JL_data = [x,y,z,d];
    [u,v]=sortrows(JL_data,4);
    else
    d = sqrt((point(1)-x).^2 + (point(2)-y).^2);
    JL_data = [x,y,d];
    [u,v]=sortrows(JL_data,3);
    end
    nearestPoint = model(v(1),:);
end








