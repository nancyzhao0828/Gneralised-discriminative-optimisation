function [ iRSDO,MSEDO,Runtime] = DOevaluation(DM,Rtest1,Xtest1,MSEDO,iRSDO)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
   maxIter = 100;
   stopThres = 0.001;
   sigmaSq = 0.03;
   starttime_do = tic;
   [DOYout,Ystep,Xstep] = infer_new(DM,{Xtest1},maxIter,stopThres,sigmaSq);
   runtime_do = toc(starttime_do);
   Runtime = runtime_do;
  if size(DM.Xmodel,2)>3
   Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*DM.Xmodel,Rtest1(1:3,4));% groundtruth
   else
   Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*DM.Xmodel',Rtest1(1:3,4));% groundtruth   
   end
   Xgts = single(Xstep{end}{1,1});
   [ irsdo,msedo, judgement ] = isRegisterSuccessful(Xgt', Xgts');
   iRSDO=[iRSDO;irsdo];
   MSEDO=[MSEDO;msedo];

end

