
function [DM,error4] = learnGDO(Xmodel,X,Y,nMap,pcmptFeat,normals)

% Input: Xmodel,X,sigmaSq,gridStep are used to calculate the feature Hf
%        Xmodel - orinigal model
%        X      - the model with perturbations
%        Y      - groundtruth (parameter vector)
% Output: The learned regressor

fprintf('Training GDO with %d maps\n',nMap)
fprintf('#data: %d \n',length(X)) 
D = cell(1,nMap);
error4 = inf(nMap,1);
Xori = X;
Yori = Y;
%[pcmptFeat,normals] = precomputeFeature(Xmodel,sigmaSq,gridStep);
Ygoal = transMatToParam(Yori);
Yinit = zeros(6,length(X));% the parameters are initialized to 0
Y = Yinit;
fprintf('It: %d, err: %f\n',0,norm(Ygoal-Y,'fro').^2/length(X))
gridStep=0.05;
sigmaSq=0.3;
x = -2:gridStep:2;
[X1,Y1,Z1] = meshgrid(x,x,x);
D1 = [X1(:) Y1(:) Z1(:)]';
[F,Mdl] = PDFnorm(Xmodel',D1); % calculate the probability density function
for itMap =1:nMap
 featX = extFeat(X,pcmptFeat); % extract the coordinate-based feature
 featXF = computeFeature_pdf01(Xmodel,X,sigmaSq,normals,F,Mdl);% extract the density-based feature
 [lameda1,lameda2] = FEATXFXGDO( featX,featXF );% calculate the weights for features
 FeatX=[lameda2*featX;lameda1*featXF];% achieve the cooperation of different features
 featY = Y - Ygoal;
 D{itMap} = (featY*FeatX')/(FeatX*FeatX'/length(X)+1e-4*(eye(size(FeatX,1))))/length(X);% attain the learned regressor
 Y = Y - D{itMap}*FeatX;
 clear featX FeatX featXF featY
 rotMat = paramToTransMatnew(Y); 
 X = transCellnew(rotMat,Xori,0);
 error4(itMap) = norm(Ygoal-Y,'fro')^2/length(X);
 fprintf('It: %d, err: %f\n',itMap,error4(itMap))
 s=0;
 if ~(itMap==1)
    deltaD=D{itMap}-D{itMap-1};
    for j=1:size(deltaD,2)
     s = s+ norm(deltaD(:,j));
     DD=s/size(deltaD,2);
    end
    if DD<10^(-4)
       break;
    end
end 
   
end
% save data

DM = struct();
DM.Dmap = D;
DM.runOrder = 1:length(D);
DM.trainErr =error4;
DM.Xmodel = Xmodel;
DM.pcmptFeat = pcmptFeat;

end

