function [featX] = computeFeature(model,X,sigmaSq,normals)
%   [ normals ] = findPointNormals(model',6,[0 0 0]);
  for i=1:length(X) % the X is the cell
     X{i}=X{i}(1:3,:);
     tmp=X{i};
     criteria = exp(-pwSqDistfeature(model,tmp')/sigmaSq);
%      [ normals ] = findPointNormals(model',6,[0 0 0]);
     dirMat = bsxfun(@gt,normals*tmp,sum(normals.*model,2));
     mapTmp1 = criteria;
     mapTmp1(dirMat) = 0;% scene is in the front of the object
     mapTmp2 = criteria;
     mapTmp2(~dirMat) = 0;% scene is in the back of the object
     mapTmp1=mapTmp1/sum(mapTmp1);
     mapTmp2=mapTmp2/sum(mapTmp2);
     featX(:,i) = [mapTmp1;mapTmp2]; 
     featX(~isfinite(featX)) = 0;
     for j=1:length(featX(:,i))
       if featX(j,i)<10^(-6)
         featX(j,i)=0;
       end
     end
  end
end

