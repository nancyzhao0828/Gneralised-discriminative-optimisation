function [featX] = computeFeature_pdf01(model,X,sigmaSq,normals,F,Mdl)
  for i=1:length(X) % the X is the cell
     X{i}=X{i}(1:3,:);
     tmp=X{i};
     [F1] = PDFnorm02(tmp,Mdl);
     criteria = exp(-pwSqDistfeature(F,F1)/sigmaSq);
     dirMat = bsxfun(@gt,normals*tmp,sum(normals.*model',2));
     mapXmodel21 = criteria;
     mapXmodel21(dirMat) =0;% scene is in the front of the object
     mapXmodel22 = criteria;
     mapXmodel22(~dirMat) = 0;% scene is in the back of the object
     mapXmodel21=mapXmodel21/sum(mapXmodel21);
     mapXmodel22=mapXmodel22/sum(mapXmodel22);
     featX(:,i) = [mapXmodel21;mapXmodel22]; 
     featX(~isfinite(featX)) = 0;
     for j=1:length(featX(:,i))
       if featX(j,i)<10^(-6)
         featX(j,i)=0;
       end
     end
  end
end

