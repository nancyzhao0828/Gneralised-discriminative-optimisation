h1=plot(MSEDO,'.','MarkerSize',30);
set(h1,'Color',[0.4660 0.6740 0.1880]);
hold on
h2=plot(MSEGDO,'.','MarkerSize',30);
set(h2,'Color',[0.3010 0.7450 0.9330]);
legend('DO','GDONNF');
xlabel('samples (rotation 30)');
ylabel('MSE');
A=find(iRSDO~=1);
B=find(iRSGDONF~=1);
a=length(find(iRSDO~=1));
b=length(find(iRSGDONF~=1));
ra=1-a/length(iRSDO);
rb=1-b/length(iRSGDONF);
MSEDO(A,1)=0;
MSEGDONF(B,1)=0;
a1=length(MSEDO)-a;
b1=length(MSEGDONF)-b;
mMSEDO=sum(MSEDO)/a1;
mMSEGDONF=sum(MSEGDONF)/b1;

MSEDO(B,1)=0;
MSEGDONF(A,1)=0;
MSEDOGDONF=MSEDO-MSEGDONF;
VoteGDONF=length(find(MSEDOGDONF>0))/length(MSEDOGDONF);
VoteDO=1-VoteGDONF;

