function [Pti_Lo,bids_X3_,Bid3,Bid4] = partition_repeat(PT_instr,s)
    %UNTITLED �˴���ʾ�йش˺�����ժҪ
    %   �˴���ʾ��ϸ˵��
[bids_X3_, E_X2_, Ne_X2_] = find_delaunay_boundary03_fig1(double(PT_instr.Location),s);
[Bid3,Bid4,Bid_] = bound_(bids_X3_);
[Instr_index_re] = bound_2(PT_instr,Bid_);
Bidd_=unique([Instr_index_re;cell2mat(Bid_')]);
pti_lo=PT_instr.Location;
cti_lo=PT_instr.Color;
pti_lo(Bidd_,:)=[];
cti_lo(Bidd_,:)=[];
Pti_Lo=pointCloud(pti_lo);
Pti_Lo.Color=cti_lo;
figure;
pcshow(Pti_Lo) %18225
end

