function [niw1] = Gauss_initi_p01(d,X1,sm,ss)
niw1.d  = d;                                                            % the dimensions of data
niw1.mu0 = (mean(X1,1))';    %prior mean
% niw1.mu0 = min(X1)';    %prior mean
niw1.k0 = 1;              %how strongly we believe in m0 prior
% niw1.S0 = chol( cov(X1));
%  niw1.S0 =diag(eig( cov(X1)));
niw1.S0 =diag(diag(cov(X1)));
niw1.nu0 = d+1;  %3       %how strongly we believe in S0 prior (dof) nu0>D-1
niw1.ss = sm^2/ss^2;      %cluster spread               % ??????
niw1.rr = 1/niw1.ss;       %1/cluster spread                % ??????
niw1.SS = niw1.nu0*niw1.S0; %nu0 * S0                    % ??????
end

