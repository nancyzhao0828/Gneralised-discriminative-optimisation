X1moving1=X1moving(:,1);
X1moving2=X1moving(:,2);
X1moving3=X1moving(:,3);
B1=cov(X1fixed');
B2 =cov(X1moving');
eigv=eig(cov(X1fixed'));
eigm=eig(cov(X1moving'));



X1fixed1=X1fixed(:,1);
X1fixed2=X1fixed(:,2);
X1fixed3=X1fixed(:,3);


figure
plot(X1fixed3)
hold on
plot(X1moving3)


figure
pcshowpair(pointCloud(X1moving),pointCloud(X1fixed));
plot3(X1moving(b,1),X1moving(b,2),X1moving(b,3),'*','MarkerSize',30);

A1= sqrt(sum(X1moving.^2,2));
A2= sqrt(sum(X1fixed.^2,2));
   
figure
histogram(X1fixed3)
hold on
histogram(X1moving3)

subplot(1,2,1)
pcshow(pointCloud(X1moving));
subplot(1,2,2)
pcshow(pointCloud(X1fixed));