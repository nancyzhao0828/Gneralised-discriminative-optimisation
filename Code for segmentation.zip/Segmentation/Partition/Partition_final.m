function [X1DDD,X2DDD] = Partition_final(X1DDD,X2DDD)
            x1=X1DDD{1,1}(:,1);
             minX1=min(x1);
             x2=X2DDD{1,1}(:,1);
             minX2=min(x2);
             x3=X2DDD{2,1}(:,1);
             minX3=min(x3);
             P=abs([minX1-minX2;minX1-minX3]);
              y1=X1DDD{1,1}(:,2);
             miny1=min(y1);
             y2=X2DDD{1,1}(:,2);
             miny2=min(y2);
             y3=X2DDD{2,1}(:,2);
             miny3=min(y3);
             P1=abs([miny1-miny2;miny1-miny3]);
            alpha1=min(P1)/max(P1);
            alpha=min(P)/max(P);
            if alpha1<alpha
             [minP,minP_index]=min(P1);
             d=2;
              l=-1;
            else
              [minP,minP_index]=min(P); 
              d=1;
              l=+1;
            end
             label = 3*unique(X2DDD{minP_index,1}(:,4));
             hh = histogram(X1DDD{1,1}(:,d));
             edges = hh.BinEdges;
             counts = hh.BinCounts;
             values = hh.Values;
            [a,b]=max(counts);
            X1DDD{1,1}(find(X1DDD{1,1}(:,d)<edges(b+l)),4)=label;
             if minP_index~=1
                 X1DDD{minP_index,1}=X1DDD{1,1}(find(X1DDD{1,1}(:,4)==label),:);
                 X1DDD{1,1}=X1DDD{1,1}(find(X1DDD{1,1}(:,4)~=label),:);
                 else
                 X1DDD{minP_index*3,1}=X1DDD{1,1}(find(X1DDD{1,1}(:,4)==label),:);   
                 X1DDD{2,1}=X1DDD{1,1}(find(X1DDD{1,1}(:,4)~=label),:);
                 X1DDD{1,1}=[];
                  X1DDD(cellfun(@isempty,X1DDD))=[];
             end
             if mod(label,2)~=0
                 if minP_index~=1
                    X1DDD{1,1}(:,4)=2;
                    X1DDD{minP_index,1}(:,4)=1;
                 else
                    X1DDD{minP_index,1}(:,4)=2;
                    X1DDD{2,1}(:,4)=1;
                 end
             end
             
end

