% Hierarchical partition+registration
clc;clear;
%%               Import data
    handData = load('hand3d.mat');
    moving = handData.moving;
    fixed = handData.fixed;
    movingDownsampled = pcdownsample(moving,'gridAverage',0.03);
    fixedDownsampled = pcdownsample(fixed,'gridAverage',0.03);
    figure
   pcshowpair(movingDownsampled, fixedDownsampled,'MarkerSize',50);
   legend('moving','fixed');
    tform = pcregistercpd(movingDownsampled,fixedDownsampled);
    movingReg = pctransform(movingDownsampled,tform);
     [~, dists] = knnsearch(movingReg.Location, fixedDownsampled.Location);
     rmsewhole = sqrt(mean(dists(:)));
     figure;
    pcshowpair(movingReg, fixedDownsampled,'MarkerSize',50)
    legend('transformed','groundtruth');
%%             Combine data   
    X1=fixedDownsampled.Location;
    X2=movingDownsampled.Location;
    X=[X1;X2];
%%             Determine the parameters
      [n,d] = size(X);
      ss = 0.5;                                                           
      sm = 30;  
% if niw1=niw2=niw,partition of the final transformed model groups one cluster
% if niw1~=niw2~=niw, partition groups two clusters
      [niw1] = Gauss_initi_p(d,X1,sm,ss); % the initial guass information for the fixed model
      [niw2] = Gauss_initi_p(d,X2,sm,ss); % the initial guass information for the moving model
      [niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster
%%     Achieve the clusters through DPMM  
     [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X,niw1,niw2,niw);
%    [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss(X);
%   Present the partition results    X1 moving: part 1 in moving ;  
%    X2 moving: part 2 in moving
%%  The first time partition
[X1moving,X1fixed,X2moving,X2fixed] = Partiton(dpmm,X,X1) ;

%%    Fine  Partition 
% finger X1, palm X2
% k=1
   X_new =cell(1,2);
   X_new{1,1}= [X1fixed;X1moving]; % finger  part 1 
   X_new{1,2}= [X2fixed;X2moving]; % palm   part 2
   N_Xnew_X1= [length(X1fixed),length(X2fixed)];
   flag=1;
   k=2;
   clear X1moving X1fixed X2moving X2fixed
  while flag
      
      X_nnew=cell(1,2^k);
   for i = 1 : 2^(k-1)
       X1 = X_new{1,i}(1:N_Xnew_X1(1,i),:);% fixed
       X2 = X_new{1,i}(N_Xnew_X1(1,i)+1:length(X_new{1,i}),:);% moving
       if isempty(X1)
            X1fixed{1,i}=[];
            X2fixed{1,i}=[];
            X1moving{1,i}=[];
            X2moving{1,i}=[];
           continue;
       end
       X=[X1;X2];
%        [n1,d1] = size(X_new{1,i});
       [n1,d1] = size(X);
       a1 = chol(cov(X1));
       ss = sqrt((trace(a1)/3)/2);                                                         
       sm = 30;  
      [niw1] = Gauss_initi_p(d,X1,sm,ss); % the initial guass information for the fixed model
      [niw2] = Gauss_initi_p(d,X2,sm,ss); % the initial guass information for the moving model
      [niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster
      [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X,niw1,niw2,niw);
%       [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss(X);
      [X1moving{1,i},X1fixed{1,i},X2moving{1,i},X2fixed{1,i}] = Partiton(dpmm,X,X1) ;
      X_nnew{1,2*i-1}= [X1fixed{1,i};X1moving{1,i}]; % left finger
      X_nnew{1,2*i}= [X2fixed{1,i};X2moving{1,i}]; % right finger
%       N_Xnew_X1(1,i)=length(X1fixed{1,i});
   end
   R1=X_nnew;
   R1=R1(~cellfun('isempty',R1));
    XPF=[X1fixed;X2fixed];  
    XPM=[X1moving;X2moving];
    XPF=reshape(XPF,2^k,1);
    XPM=reshape(XPM,2^k,1);
   for j=1:2^k
        N_Xnnew_X1(1,j)=length(XPF{j,1});
   end
    if length(R1)==length(X_new)
       break;
   end
   N_Xnew_X1 = N_Xnnew_X1;
   X_new = X_nnew;
%    X1Moving{1,k} = X1moving;
%    X1Fixed{1,k} = X1fixed;
%    X2Moving{1,k} = X2moving;
%    X2Fixed{1,k} = X2fixed;
   k=k+1;
   if k==3
       flag=0;
   else
       flag=1;
   end
   clear X1moving X1fixed X2moving X2fixed
  end
   R=X_nnew;
   R=R(~cellfun('isempty',R));
   XP_less=XPF;
   XP_less=XP_less(~cellfun('isempty',XP_less));
   XM_less=XPM;
   XM_less=XM_less(~cellfun('isempty',XM_less));
   %% figure setting
   Colgr = length (R);
   Color = lines(Colgr);
   Color(end,:)=[1,1,1];
   Color_matrix = cell(1,Colgr);
   ptCloudwhole = cell(1,Colgr);
   ptCloudfixed = cell(1,Colgr);
   ptCloudmoving = cell(1,Colgr);
   for i=1:Colgr
       Color_matrix{1,i} = ones(length(R{1,i}),1)*Color(i,:)*256;
       ptCloudwhole{1,i} = pointCloud(R{1,i});
       ptCloudfixed{1,i} = pointCloud(XP_less{i,1});
       ptCloudmoving{1,i} = pointCloud(XM_less{i,1});
       ptCloudwhole{1,i}.Color = uint8( Color_matrix{1,i});
       ptCloudfixed{1,i}.Color = uint8(ones(length(XP_less{i,1}),1)*Color(i,:)*256);
       ptCloudmoving{1,i}.Color = uint8(ones(length(XM_less{i,1}),1)*Color(i,:)*256);
   end
   %% figure
   figure
   for i=1:Colgr
       pcshow(ptCloudwhole{1,i},'MarkerSize',25);
       hold on
   end
     figure
   for i=1:Colgr
       pcshow(ptCloudfixed{1,i},'MarkerSize',40);
       hold on
   end
       figure
   for i=1:Colgr
       pcshow(ptCloudmoving{1,i},'MarkerSize',40);
       hold on
   end
%%  Registration based on partitions
movingReg_p = cell(1,Colgr);
Move_fina = [];
for p = 1:Colgr
    tform = pcregistercpd(ptCloudmoving{1,p},ptCloudfixed{1,p});
    movingReg_p{1,p} = pctransform(ptCloudmoving{1,p},tform);
    Move_fina = [movingReg_p{1,p}.Location;Move_fina];
end
ptCloud_Movef = pointCloud(Move_fina);
 [~, distsMf] = knnsearch(Move_fina, fixedDownsampled.Location);
  rmseMove_f = sqrt(mean(distsMf(:)));
figure
   for i=1:Colgr
       pcshow(movingReg_p{1,i},'MarkerSize',40);
       hold on
   end
   figure
   pcshowpair(ptCloud_Movef,fixedDownsampled,'MarkerSize',40);
   legend('transformed','groundtruth');
 

   
   
   
   
   
   
   
   
% % Partition X1
%    [n1,d1] = size(X1);
%     ss = 0.2;                                                           
%     sm = 30;  
%   [niw1] = Gauss_initi_p(d,X1fixed,sm,ss); % the initial guass information for the fixed model
%   [niw2] = Gauss_initi_p(d,X1moving,sm,ss); % the initial guass information for the moving model
%   [niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster
%   [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X1,niw1,niw2,niw);
%   [X1moving,X1fixed,X2moving,X2fixed] = Partiton(dpmm,X1,X1fixed) ;
%  % Partition X2
%    [n1,d1] = size(X2);
%     ss = 0.2;                                                           
%     sm = 30;  
%   [niw1] = Gauss_initi_p(d,X2fixed,sm,ss); % the initial guass information for the fixed model
%   [niw2] = Gauss_initi_p(d,X2moving,sm,ss); % the initial guass information for the moving model
%   [niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster
%   [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X2,niw1,niw2,niw);
%   [X1moving,X1fixed,X2moving,X2fixed] = Partiton(dpmm,X2,X2fixed) ;
%   
%   
%   
%   
%   
%   
%   
%   
%   
% %%    Check the partition of the transformed model 
%       X2_new = Moving.Location; 
%       X_new = [X1; X2_new];
%       [n_new,d_new] = size(X_new);
%       [niw2_new] = Gauss_initi_p(d_new,X2_new,sm,ss); % the initial guass information for the moving model
%       [niw_new] = Gauss01(d_new,ss,sm); % the intial guass for unknown cluster
% %%     Achieve the clusters through DPMM  
% %       [dpmm_transformed, dpmm_posterior_transformed, dpmm_time_transformed] = DPMM_gauss01(X_new,niw1,niw2_new,niw_new);
%       [dpmm_transformed, dpmm_posterior_transformed, dpmm_time_transformed] = DPMM_gauss(X_new);