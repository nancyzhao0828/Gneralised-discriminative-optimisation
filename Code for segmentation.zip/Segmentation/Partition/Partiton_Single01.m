function [XR] = Partiton_Single01(dpmm,X)
    % the output is the binary classification.
    z=dpmm.z;
    if  dpmm.K==2
%     figure(1)
    Index1=find(z==1);
    Index2=find(z==2);
%     hold on
%     plot3(X(Index1,1),X(Index1,2),X(Index1,3),'r.');
%     hold on
%     plot3(X(Index2,1),X(Index2,2),X(Index2,3),'m.');
%     title('the partitions in the whole model');
    else
    Index1=find(z==1);
    Index2=find(z==2);
    Index3=find(z==3);
%     hold on
%     plot3(X(Index1,1),X(Index1,2),X(Index1,3),'r.');
%     hold on
%     plot3(X(Index2,1),X(Index2,2),X(Index2,3),'m.');
%      hold on
%     plot3(X(Index3,1),X(Index3,2),X(Index3,3),'b.');
%     title('the partitions in the whole model');
    end
    for i=1:dpmm.K
        Index=find(z==i);
        XR{i,1}=X(Index,:);
    end
    
end

