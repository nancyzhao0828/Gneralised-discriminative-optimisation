function [] = dpmm_plot(dpmm)

cmap = hsv(dpmm.K);

for kk = 1:dpmm.K
  [mu sigma] = rand_sample(dpmm.gm{kk});
  plotellipse(mu,sigma,'color',cmap(kk,:),'linewidth',2);
  hold on
  ii = find(dpmm.z==kk);
  d=length(mu);
  if (d > 2)
    [x_coeff, x_score] = pca(dpmm.X);
    x_pca = x_score(:,1:2);
    xx = x_pca(ii,:);
    plot(xx(:,1),xx(:,2),'.','color',cmap(kk,:),'markersize',10); hold on;
    xlabel('PC 1'); ylabel('PC 2'); title('PCA Plot');       
  else
    xx = dpmm.X(ii,:);
    plot(xx(:,1),xx(:,2),'.','color',cmap(kk,:),'markersize',10); hold on;
    xlabel('X1'); ylabel('X2');
  end
end

end

