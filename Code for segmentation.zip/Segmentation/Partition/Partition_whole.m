function [dpmm,XR] =Partition_whole(X1,X2,sm,num_gibbs)
      X = [X1;X2];
      [n,d] = size(X(:,1:3));
      a1=diag(cov(X2(:,1:3)));  
      ss = sqrt((median(a1))/2);                                                         
%       sm = 30;  
% if niw1=niw2=niw,partition of the final transformed model groups one cluster
% if niw1~=niw2~=niw, partition groups two clusters
      [niw1] = Gauss_initi_p(d,X1(:,1:3),sm,ss); % the initial guass information for the fixed model
      [niw2] = Gauss_initi_p(d,X2(:,1:3),sm,ss); % the initial guass information for the moving model
      [niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster
%  niw=niw2;
%%     Achieve the clusters through DPMM  
[dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X(:,1:3),niw1,niw2,niw,num_gibbs); 
%  [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss(X(:,1:3)); 
 [XR] = Partiton02(dpmm,X,X1);
end

