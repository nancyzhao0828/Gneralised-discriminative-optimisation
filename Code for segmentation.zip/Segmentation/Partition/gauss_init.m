function [gauss] = gauss_init(niw1)
%create a gaussian struct with no data items

gauss.d = niw1.d;
gauss.n = 0;              % init number of items.
gauss.rr = niw1.rr;
gauss.nu0 = niw1.nu0;
gauss.Sigma = chol(niw1.SS + niw1.rr*niw1.mu0*niw1.mu0'); % Cholesky factorization
gauss.mu = niw1.rr*niw1.mu0;
gauss.Z0 = ZZ(niw1.d,gauss.n,gauss.rr,gauss.nu0,gauss.Sigma,gauss.mu);

end

