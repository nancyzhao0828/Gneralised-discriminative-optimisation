function tform = registerNonrigid007(moving, fixed, maxIterations, ...
    w, tolerance, beta, lambda)

% if(isSimMode())
%     printer = vision.internal.MessagePrinter.configure(verbose);
% end
 X = fixed;
Y = moving;

D = size(X, 2);
M = size(Y, 1);
N = size(X, 1);

% normalize to zero mean
xmean = mean(X);
ymean = mean(Y);
if(isSimMode())
    X = X - xmean;
    Y = Y - ymean;
else
    for i = 1 : D
        X(:,i) = X(:,i) - xmean(i);
        Y(:,i) = Y(:,i) - ymean(i);
    end
end

% Initialization
W = zeros(size(Y), 'like', Y);

sigma2     = cast(0, 'like', Y);

for col = 1 : D
    if(isSimMode())
        sigma2 = sigma2 + sum(sum((X(:,col) - Y(:,col)').^2 ));
    else
        for j = 1 : N
            sigma2 = sigma2 + sum((X(j, col) - Y(:, col)).^2);
        end
    end
end
sigma2 = sigma2 / (D*N*M);

nIter  = 0;
negativeLogLikelihood      = cast(0, 'like', X);
G      = zeros(M, M, 'like', Y);
if(~isSimMode())
    A      = zeros(M, M, 'like', Y);
end

for col = 1 : D
    if(isSimMode())
        G = G + (Y(:,col) - Y(:,col)').^2;
    else
        for j = 1 : M
            G(:, j) = G(:, j) + (Y(j, col) - Y(:, col)).^2;
        end
    end
end
G = exp((-1/(2*beta*beta))*G);

transformedY = Y;

if(~isSimMode())
    P1Y = zeros(size(Y), 'like', Y);
end

% EM optimization, repeat until convergence
while (nIter < maxIterations)
    negativeLogLikelihoodPrev = negativeLogLikelihood;
    
    % E-step: Compute P
    [ P1, Pt1, Px, negativeLogLikelihood ] = computeEStep(X, transformedY, sigma2, w);
    
    negativeLogLikelihood      = negativeLogLikelihood+lambda/2*trace(W'*G*W);
    ntol   = abs((negativeLogLikelihood-negativeLogLikelihoodPrev)/negativeLogLikelihood);
    
    % M-step: Solve G, W, sigma2
    if(isSimMode())
        A = (P1.*G + lambda*sigma2*eye(M));
    else
        for i = 1 : M
            A(:, i) = G(:, i).*P1;
            A(i, i) = A(i, i) + lambda*sigma2;
        end
    end
    rcondVal = rcond(A);
    if(isnan(rcondVal) || rcondVal<eps)
%         if(isSimMode())
%             printer.printMessage('vision:pointcloud:cpdStopCondIllMatrix');
%         end
        break;
    end
    if(isSimMode())
        W      = A\(Px - P1.*Y);
    else
        for i = 1 : D
            P1Y(:, i) = Px(:, i) - P1.*Y(:, i);
        end
        W      = A\(P1Y);
    end
    
    Np     = sum(P1);
    transformedY      = Y + G*W;
    if(isSimMode())
        sigma2 = (sum(sum((X.^2).*Pt1)) - 2*trace(Px'*transformedY) + sum(sum((transformedY.^2).*P1)))/(Np*D) ;
    else
        sum1 = cast(0, 'like', X);
        sum3 = cast(0, 'like', X);
        sum2 = cast(0, 'like', X);
        for c = 1 : D
            sum1 = sum1 + sum((X(:, c).^2).*Pt1);
            sum2 = sum2 + sum(Px(:, c).*transformedY(:, c));
            sum3 = sum3 + sum((transformedY(:, c).^2).*P1);
        end
        sigma2 = (sum1 - 2*sum2 + sum3)/(Np*D) ;
    end
    nIter  = nIter + 1;
%     if(isSimMode())
%         printer.linebreak;
%         printer.print('--------------------------------------------\n');
%         printer.printMessage('vision:pointcloud:cpdIteration','Nonrigid', nIter);
%         printer.printMessage('vision:pointcloud:cpdCurrentCovariance', mat2str(sigma2));
%         printer.printMessage('vision:pointcloud:cpdCurrentFcn', mat2str(ntol));
%     end
    if(ntol <= tolerance)
        break;
    end
end
% if(isSimMode())
%     if(nIter>0)
%         printer.print('--------------------------------------------\n');
%         printer.printMessage('vision:pointcloud:cpdTotalIterations', nIter);
%     end
% end
if(isSimMode())
    tform = G*W + (xmean-ymean);
else
    tform = G*W;
    for i = 1 : D
        tform(:, i) = tform(:, i) + (xmean(i)-ymean(i));
    end
end
end