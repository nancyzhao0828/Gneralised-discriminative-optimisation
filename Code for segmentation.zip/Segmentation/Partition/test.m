clc;
clear;
handData = load('hand3d.mat');
moving = handData.moving;
fixed = handData.fixed;
movingDownsampled = pcdownsample(moving,'gridAverage',0.03);
fixedDownsampled = pcdownsample(fixed,'gridAverage',0.03);
X1=fixedDownsampled.Location;
Y1=fixedDownsampled.Location(:,2);
X2=movingDownsampled.Location;
Y2=movingDownsampled.Location(:,2);
X=[Y1;Y2];
X2(:,2)=Y1(1:1372);
pcshow(pointCloud(X2));%moving
hold on
pcshow(pointCloud(X1));%fixed


figure;
for i=1:3
pd1 = fitdist(X1(:,i),'Normal');
y1= normpdf(X1(:,i),pd1.mu,pd1.sigma);
hold on
plot(X1(:,i),log(y1),'.','MarkerSize',10);
end
for i=1:3
pd2 = fitdist(X2(:,i),'Normal');
y2 = normpdf(X1(:,i),pd2.mu,pd2.sigma);
hold on
plot(X1(:,i),log(y2),'.','MarkerSize',10);
end
legend('xaxisf','yaxisf','zaxisf','xaxism','yaxism','zaxism');



%%
n=5;
ye = normrnd(pd2.mu,pd2.sigma,[length(X2),1]);





