clc;
clear;

%% data pre-processing
% 84,87 outliers
%  fixed = pcread('\\bournemouth.ac.uk\data\Staff\Home\zhaoy\MATLAB\BayesianCPD\BayesianCPD\boxing95.ply');
% % load('matlab.mat');
%  S=fixed.Location;
%  Fixed=pointCloud(S);
%  moving =pcread('\\bournemouth.ac.uk\data\Staff\Home\zhaoy\MATLAB\BayesianCPD\BayesianCPD\boxing130.ply');
%  T=moving.Location;
%  Moving=pointCloud(T);
%  movingDownsampled = pcdownsample(Moving,'gridAverage',0.01);
%  fixedDownsampled = pcdownsample(Fixed,'gridAverage',0.01);
%  X1=fixedDownsampled.Location;
%  X2=movingDownsampled.Location;  % seperate
% 
%  tic
 %% assigning labels
%  target data
%  [X1L] = Assigining_labels(X1,1);
%  [X2L] = Assigining_labels(X2,0);
%   X1L=[X1,ones(length(X1),1)];
%   figure;
%  pcshowpair(pointCloud(X2L(find(X2L(:,4)==1),1:3)),pointCloud(X2L(find(X2L(:,4)==2),1:3)));
load('boxing95130X2L.mat')
 %% Partition corse
 % XR is the remaining part ; X2D is the to be divided part for seperate.
 [XR,X2D,X1D] =Mainfunction(X1L,X2L);
 
 %% test for source data
[XR_s,XR_re] = outliers_detect(XR);
X1D={[cell2mat(X1D);XR_re]};
XR_new{1,1}=XR_s; % remaining part
XR_new{2,1}=cell2mat(XR{2,1}); % remaining part
XR_new{1,1}(:,4)=unique(XR_new{2,1}(:,4))*ones(length( XR_new{1,1}(:,4)),1);
%  figure
%  subplot(1,2,1)
%  pcshow(pointCloud(XR_new{1,1}(:,1:3)));
%  title('source data');
%  subplot(1,2,2)
%  pcshow(pointCloud(XR_new{2,1}(:,1:3)));
%  title('target data');

  %%  partiton again. fine
  X1D=X1D(~cellfun('isempty',X1D));
  X2D=X2D(~cellfun('isempty',X2D));
  % length(X2D{1,1})-length(X1D{1,1})>100
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   [XRD,X2DD,X1DD] =Mainfunction(X1D{1,1},X2D{1,1});
   if isempty(cell2mat(X1DD)) && isempty(cell2mat(X2DD))
       String = ' Partition is finished !';
       disp(String);
        X_source=[XR_new{1,1};cell2mat(XRD{1,1})];
        X_target=[XR_new{2,1};cell2mat(XRD{2,1})];     
   else if  length(XRD)==1 || isempty(cell2mat(cat(1,XRD{:})))
                       if ~isempty(cell2mat(XRD))
                       [XRD_s,XRD_re] = outliers_detect(XRD);
                       X1DD={[cell2mat(X1DD);XRD_re]};
                       XRD_new{1,1}=XRD_s; % remaining part
                       XRD_new{2,1}=cell2mat(XRD{2,1}); 
                       XRD_new{1,1}(:,4)=unique(XRD_new{2,1}(:,4))*ones(length( XRD_new{1,1}(:,4)),1);
                       else
                           XRD_new{1,1}=[];
                           XRD_new{2,1}=[];
                       end
        else  
                       [XRD_s,XRD_re] = outliers_detect(XRD);
                       X1DD={[cell2mat(X1DD);XRD_re]};
                       XRD_new{1,1}=XRD_s; % remaining part
                       XRD_new{2,1}=cell2mat(XRD{2,1}); 
                       XRD_new{1,1}(:,4)=unique(XRD_new{2,1}(:,4))*ones(length( XRD_new{1,1}(:,4)),1);
        end
%      figure
%      subplot(1,2,1)
%      pcshow(pointCloud(XRD_new{1,1}(:,1:3)));
%      title('source data');
%      subplot(1,2,2)
%      pcshow(pointCloud(XRD_new{2,1}(:,1:3)));
%      title('target data');
     
              X1DD=X1DD(~cellfun('isempty',X1DD));
              X2DD=X2DD(~cellfun('isempty',X2DD));
              XRDD_new1{1,1}=[];
              XRDD_new1{2,1}=[];
                  for i=1:length(X1DD)
                  [XRDD,X2DDD,X1DDD] =Mainfunction(X1DD{i,1},X2DD{i,1});
                  if ~isempty(X2DDD)&&~isempty(X1DDD)
                      if (length(unique(X2DDD{1,1}(:,4)))~=1)||(length(unique(X2DDD{2,1}(:,4)))~=1)
                          if abs( length(cell2mat(X2DDD))-length(cell2mat(X1DDD)))<5
                            String='actually does not need partition';  
                            disp(String);
                             [XRDD_s,XRDD_re] = outliers_detect(XRDD);
                              X1DDD={[cell2mat(X1DDD);XRDD_re]};
                               XRDD_new{1,1}=XRDD_s; % remaining part
                               XRDD_new{2,1}=cell2mat(XRDD{2,1}); 
                               XRDD_new{1,1}(:,4)=unique(XRDD_new{2,1}(:,4))*ones(length( XRDD_new{1,1}(:,4)),1);
                    %              figure
                    %              subplot(1,2,1)
                    %              pcshow(pointCloud(XRDD_new{1,1}(:,1:3)));
                    %              title('source data');
                    %              subplot(1,2,2)
                    %              pcshow(pointCloud(XRDD_new{2,1}(:,1:3)));
                    %              title('target data');
                                 X1DDD=X1DDD(~cellfun('isempty',X1DDD));
                                 X2DDD=X2DDD(~cellfun('isempty',X2DDD));
                                 X3DDD{1,1}=X2DDD{1,1}(find(X2DDD{1,1}(:,4)==1),:);
                                 X3DDD{2,1}=X2DDD{1,1}(find(X2DDD{1,1}(:,4)==2),:);
                                 X2DDD=X3DDD;
                                 [X1DDD,X2DDD] = Partition_final(X1DDD,X2DDD);
                          else
                               String='need partition';
                               disp(String);
                               if ~isempty(XRDD)
                                   [XRDD_s,XRDD_re] = outliers_detect(XRDD);
                                   X1DDD={[cell2mat(X1DDD);XRDD_re]};
                                   XRDD_new{1,1}=XRDD_s; % remaining part
                                   XRDD_new{2,1}=cell2mat(XRDD{2,1}); 
                                   XRDD_new{1,1}(:,4)=unique(XRDD_new{2,1}(:,4))*ones(length( XRDD_new{1,1}(:,4)),1);
                        %          figure
                        %          subplot(1,2,1)
                        %          pcshow(pointCloud(XRDD_new{1,1}(:,1:3)));
                        %          title('source data');
                        %          subplot(1,2,2)
                        %          pcshow(pointCloud(XRDD_new{2,1}(:,1:3)));
                        %          title('target data');
                                 X1DDD=X1DDD(~cellfun('isempty',X1DDD));
                                 X2DDD=X2DDD(~cellfun('isempty',X2DDD));
                                 
                               else
                                    XRDD_new1{1,1}=[];
                                    XRDD_new1{2,1}=[];
                                 X1DDD=X1DDD(~cellfun('isempty',X1DDD));
                                 X2DDD=X2DDD(~cellfun('isempty',X2DDD));
                                 X3D{i,1}=cell2mat(X1DDD);
                                 X4D{i,1}=cell2mat(X2DDD);
                                 clear X1DDD X2DDD
                               end
                          end
%                       else
%                           if isempty(XRDD)
% %                              XRDD_new1{1,1}=[cell2mat(X1DDD); XRDD_new1{1,1}];
% %                              XRDD_new1{2,1}=[cell2mat(X2DDD);XRDD_new1{2,1}];
%                           end       
                      end
                  else
                       [XRDD_s,XRDD_re] = outliers_detect(XRDD);
                       X1DDD={XRDD_s};
                       X2DDD=XRDD{2,1};
                       XRDD_new1{1,1}=[cell2mat(X1DDD); XRDD_new1{1,1}];
                       XRDD_new1{2,1}=[cell2mat(X2DDD);XRDD_new1{2,1}];
                %        [X1DDD,X2DDD] = Partition_final(X1DDD,X2DDD);
                       X1DDD{1,1}= XRDD_new1{1,1};
                       clear X2DDD
                       X2DDD{1,1}= XRDD_new1{2,1};
                       XRDD_new{1,1}=[];
                       XRDD_new{2,1}=[];
                  end

                  end
  % vertify again !
                    if length(X1DDD)==1
                      [X1DDDL] = Assigining_labels(X1DDD{1,1}(:,1:3),0);
                    %   pcshowpair(pointCloud(X1DDDL(find(X1DDDL(:,4)==1),1:3)),pointCloud(X1DDDL(find(X1DDDL(:,4)==2),1:3)));
                    %   X1DDD{1,1}(:,4)=X1DDDL(:,4);
                      if length(unique(X1DDDL(:,4)))~=1
                           T=tabulate(X1DDDL(:,4)); % new label
                           T1=tabulate(X1DDD{1,1}(:,4));% old label
                           [value_f,index_f]=max(T(:,2));
                           [value_mf,index_mf]=max(T1(:,2));
                           if (index_mf==index_f)&&(index_mf~=1)
                               XL_delta=X1DDDL(:,4)-X1DDD{1,1}(:,4);
                               X1DDD{1,1}(find(XL_delta~=0),4)=index_mf;
                               X1DDD{1,1}(find(XL_delta==0),4)=1;
                           elseif (index_mf==index_f)&&(index_mf==1)
                              XL_delta=X1DDDL(:,4)-X1DDD{1,1}(:,4);
                               X1DDD{1,1}(find(XL_delta~=0),4)=2;
                               X1DDD{1,1}(find(XL_delta==0),4)=index_mf;
                           end
                       XRDDnew=cell2mat(X1DDD);
                     end
                        XRDDD_new{1,1}=cell2mat(X1DDD);
                        XRDDD_new{2,1}=cell2mat(X2DDD);
                    else
                        XRDDD_new{1,1}=cell2mat(X1DDD);
                        XRDDD_new{2,1}=cell2mat(X2DDD);
                    end
  %% Reorientation
                     X_source=[XR_new{1,1};XRD_new{1,1};XRDD_new{1,1}; XRDDD_new{1,1}];
                      X_target=[XR_new{2,1};XRD_new{2,1};XRDD_new{2,1};XRDDD_new{2,1}];     
                      indeX_f = find(mod(X_source(:,4),2)==0);
                      X_source(indeX_f,4)=2;   
   end
   
   figure;
    subplot(1,2,1)
   pcshowpair(pointCloud(X_source(find(X_source(:,4)==1),1:3)),pointCloud(X_source(find(X_source(:,4)==2),1:3)),'MarkerSize',30);
   subplot(1,2,2)
   pcshowpair(pointCloud(X_target(find(X_target(:,4)==1),1:3)),pointCloud(X_target(find(X_target(:,4)==2),1:3)),'MarkerSize',30);

  Cs=cell(2,1);
  Ct=cell(2,1);
  for i=1:2
      Cs{i,1}=X_source(find(X_source(:,4)==i),1:3);
      Ct{i,1}=X_target(find(X_target(:,4)==i),1:3);
  end
  
ptCloudC1=pointCloud(Cs{1,1});
pcwrite(ptCloudC1,'hat_source8789.ply');
ptCloudC2=pointCloud(Ct{1,1});
pcwrite(ptCloudC2,'hat_target8789.ply');
ptCloudB1=pointCloud(Cs{2,1});
pcwrite(ptCloudB1,'body_source8789.ply');
ptCloudB2=pointCloud(Ct{2,1});
pcwrite(ptCloudB2,'body_target8789.ply');
toc
disp(['running time: ',num2str(toc)]);
        
      
    

 
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
       