function [XP] = Partiton02(dpmm,X,X1)
    % the output is the binary classification.
        k=dpmm.K;
        z=dpmm.z;
        N = length(X);
        N1= length(X1);
        X11=X(1:N1,:); %X1
        X22=X(N1+1:N,:); % X2
        XT{1,1}=X11;
        XT{2,1}=X22;
   if  dpmm.K==2
        figure(1)
        Index1=find(z==1);
        Index2=find(z==2);
%         hold on
%         plot3(X(Index1,1),X(Index1,2),X(Index1,3),'r.');
%         hold on
%         plot3(X(Index2,1),X(Index2,2),X(Index2,3),'m.');
%         title('the partitions in the whole model');
  else
        Index1=find(z==1);
        Index2=find(z==2);
        Index3=find(z==3);
%         hold on
%         plot3(X(Index1,1),X(Index1,2),X(Index1,3),'r.');
%         hold on
%         plot3(X(Index2,1),X(Index2,2),X(Index2,3),'m.');
%          hold on
%         plot3(X(Index3,1),X(Index3,2),X(Index3,3),'b.');
%         title('the partitions in the whole model');
  end
        XP=cell(2,1); %{X1} {X2}    
   for j=1:2
%         figure;
         for i=1:dpmm.K
                Index=find(z==i);
                XR=X(Index,:);
               [lo,iIndex2]=ismember(XT{j,1},XR,'rows');%moving
               iIndex2(iIndex2==0)=[];
               XP{j,1}{i,1}= XR(iIndex2,:); % finger in moving model
%                 scatter3(XP{j,1}{i,1}(:,1),XP{j,1}{i,1}(:,2),XP{j,1}{i,1}(:,3));
%                 hold on
          end
%            if j==1
%               title('the partition in the united model');
%            else
%               title('the partition in the seperate model');  
%             end
    end
end

