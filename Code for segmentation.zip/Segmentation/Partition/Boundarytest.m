function [X2L,X1L] = Boundarytest(X3L,X1)
X1L=X3L(1:length(X1),:);
X2L=X3L(length(X1)+1:end,:);
X2L1=X2L(find(X2L(:,4)==1),:);
X2L2=X2L(find(X2L(:,4)==2),:);
[bids_X2L1, E_X2L1, Ne_X2L1] = find_delaunay_boundary03_fig1(double(X2L1(:,2:3)),0.03);
[bids_X2L2, E_X2L2, Ne_X2L2] = find_delaunay_boundary03_fig1(double(X2L2(:,2:3)),0.03);
if length(bids_X2L1)~=1
    flag=1;
end
if length(bids_X2L2)~=1
    flag=-1;
    X2L1=X2L2;
    bids_X2L1=bids_X2L2;
end
kl=length(bids_X2L1);
i=1;
    while i~=(kl+1)
          a=length(bids_X2L1{1,i});
          if a<length(X2L1)
              A(i,1)=a;
              i=i+1;
          else
              break;
          end
          
    end
    [a1,b1] = min(A);
    if b1==1
          B = bids_X2L1{1,1}; 
          B=unique(B);
          C = bids_X2L1{1,kl};
          C=unique(C);
          
    else
         B = bids_X2L1{1,b1}; 
         B=unique(B);
         C = bids_X2L1{1,1};
         C=unique(C);
    end
    Mu=mean(X2L1(B,1:3));
    X2L1(B,4)=kl; % less for 2 boundary
    X2L1(C,4)=3;  % more for 3 boundary
%     [Lia,lia] = ismember(X2L1(:,1:3),X2L1(B,1:3),'rows');
%     indexx=find(Lia~=0);
    sr=2;
    D=X2L1(find(X2L1(:,4)==1),1:3);
    D(:,4)=zeros;
    X2V=[D;X2L1(C,:)];
%     index1=find(D(:,4)==0);
%     E=D(index1,1:3);
    while flag
        Ak=knnsearch(X2V(:,1:3),Mu,'K',sr);
        T=X2V(Ak,1:3);
        [Lia,lia] = ismember(X2L1(:,1:3),T,'rows');
        indexx=find(Lia~=0);
%         X2L1(indexx,4)=kl;
        if length(unique(X2L1(indexx,4)))<2
            D(Ak,:)=[];
            X2L1(indexx,4)=kl;
            B=X2L1(find(X2L1(:,4)==kl),:);
%             D(Ak,4)=ones(length(Ak),1)*kl;
%             index1=find(D(:,4)==0);
%             E=D(index1,1:3);
            Mu=mean(B(:,1:3));
            X2V=[D;X2L1(C,:)];
            sr=sr+2;
        else
            flag=0;
            X2V(:,4)=3;
            X2L1=[B;X2V];
        end    
    end
    XL2=[X2L1;X2L2];
    X2L=XL2;
    X2L(find(X2L(:,4)==3),4)=1;
    
end

