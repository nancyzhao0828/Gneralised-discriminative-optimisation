% Hierarchical partition
%%               Import data
    handData = load('hand3d.mat');
    moving = handData.moving;
    fixed = handData.fixed;
    movingDownsampled = pcdownsample(moving,'gridAverage',0.03);
    fixedDownsampled = pcdownsample(fixed,'gridAverage',0.03);
%%             Combine data   
    X1=fixedDownsampled.Location;
    X2=movingDownsampled.Location;
    X=[X1;X2];
%%             Determine the parameters
      [n,d] = size(X);
      ss = 0.1;                                                           
      sm = 30;  
% if niw1=niw2=niw,partition of the final transformed model groups one cluster
% if niw1~=niw2~=niw, partition groups two clusters
      [niw1] = Gauss_initi_p01(d,X1,sm,ss); % the initial guass information for the fixed model
      [niw2] = Gauss_initi_p01(d,X2,sm,ss); % the initial guass information for the moving model
      [niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster
%%     Achieve the clusters through DPMM  
     [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X,niw1,niw2,niw);
%       [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss(X);
%   Present the partition results
[X1moving,X1fixed,X2moving,X2fixed] = Partiton(dpmm,X,X1) ;

%%    Fine  Partition
% finger X1, palm X2
   X_new =cell(2,1);
   X_new{1,1}= [X1fixed;X1moving]; % finger % hat
   X_new{1,2}= [X2fixed;X2moving]; % palm
   N_Xnew_X1= [length(X1fixed),length(X2fixed)];
   flag=1;
   k=1;
   Xf = X_new{1,1};
   Xp = X_new{1,2};
   clear X1moving X1fixed X2moving X2fixed
  while flag
   for i = 1 : 2
       X1 = X_new{1,i}(1:N_Xnew_X1(1,i),:);% fixed
       X2 = X_new{1,i}(N_Xnew_X1(1,i)+1:length(X_new{1,i}),:); % moving % saperate 
       [n1,d1] = size(X_new{1,i});
%        a1 = chol(cov(X1));
%        a1=diag(diag(cov(X2)));
       a1=diag(cov(X1));
%        ss = sqrt((trace(a1)/3/2));        
       ss = sqrt((median(a1))/2);   
       sm = 30;  
       X=[X1;X2];
      [niw1] = Gauss_initi_p(d,X1,sm,ss); % the initial guass information for the fixed model
      [niw2] = Gauss_initi_p(d,X2,sm,ss); % the initial guass information for the moving model
      [niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster
%       niw=niw1;
      [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X,niw2,niw1,niw);
%      [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss(X2);
      [X1moving{1,i},X1fixed{1,i},X2moving{1,i},X2fixed{1,i}] = Partiton(dpmm,X_new{1,i},X1) ;
      X_new{1,i}= [X1fixed{1,i};X1moving{1,i}]; % moving is the seperate
      N_Xnew_X1(1,i)=length(X1fixed{1,i});
   end
   X1Moving{1,k} = X1moving;
   X1Fixed{1,k} = X1fixed;
   X2Moving{1,k} = X2moving;
   X2Fixed{1,k} = X2fixed;
   k=k+1;
   if k==3
       flag=0;
   else
       flag=1;
   end
   clear X1moving X1fixed X2moving X2fixed
   end
   
   
   
   
   
% Partition X1
   [n1,d1] = size(X1);
    ss = 0.2;                                                           
    sm = 30;  
  [niw1] = Gauss_initi_p(d,X1fixed,sm,ss); % the initial guass information for the fixed model
  [niw2] = Gauss_initi_p(d,X1moving,sm,ss); % the initial guass information for the moving model
  [niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster
  [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X1,niw1,niw2,niw);
  [X1moving,X1fixed,X2moving,X2fixed] = Partiton(dpmm,X1,X1fixed) ;
 % Partition X2
   [n1,d1] = size(X2);
    ss = 0.2;                                                           
    sm = 30;  
  [niw1] = Gauss_initi_p(d,X2fixed,sm,ss); % the initial guass information for the fixed model
  [niw2] = Gauss_initi_p(d,X2moving,sm,ss); % the initial guass information for the moving model
  [niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster
  [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X2,niw1,niw2,niw);
  [X1moving,X1fixed,X2moving,X2fixed] = Partiton(dpmm,X2,X2fixed) ;
  
  
  
  
  
  
  
  
  
%%    Check the partition of the transformed model 
      X2_new = Moving.Location; 
      X_new = [X1; X2_new];
      [n_new,d_new] = size(X_new);
      [niw2_new] = Gauss_initi_p(d_new,X2_new,sm,ss); % the initial guass information for the moving model
      [niw_new] = Gauss01(d_new,ss,sm); % the intial guass for unknown cluster
%%     Achieve the clusters through DPMM  
%       [dpmm_transformed, dpmm_posterior_transformed, dpmm_time_transformed] = DPMM_gauss01(X_new,niw1,niw2_new,niw_new);
      [dpmm_transformed, dpmm_posterior_transformed, dpmm_time_transformed] = DPMM_gauss(X_new);