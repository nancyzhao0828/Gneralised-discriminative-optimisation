clc;
clear;
 fixed =pcread('C:\Users\zy080\Documents\MATLAB\BayesianCPD\Partition\p000069.ply');
 moving =pcread('C:\Users\zy080\Documents\MATLAB\BayesianCPD\Partition\p000089.ply');
 movingDownsampled = pcdownsample(moving,'gridAverage',0.03);
 fixedDownsampled = pcdownsample(fixed,'gridAverage',0.03);
 X1=fixedDownsampled.Location;
 X2=movingDownsampled.Location;  % seperate
 X=[X1;X2];
%%             Determine the parameters
      [n,d] = size(X);
      a1=diag(cov(X2));  
      ss = sqrt((median(a1))/2);                                                         
      sm = 20;  
% if niw1=niw2=niw,partition of the final transformed model groups one cluster
% if niw1~=niw2~=niw, partition groups two clusters
      [niw1] = Gauss_initi_p(d,X1,sm,ss); % the initial guass information for the fixed model
      [niw2] = Gauss_initi_p(d,X2,sm,ss); % the initial guass information for the moving model
      [niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster

%%     Achieve the clusters through DPMM  
 [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X,niw1,niw2,niw);    % divided into 2 parts
 [X1moving,X1fixed,X2moving,X2fixed] = Partiton(dpmm,X,X1) ;
 X_new =cell(2,1);
   X_new{1,1}= [X1fixed;X1moving]; % finger % hat + arm  moving is seperate
   X_new{1,2}= [X2fixed;X2moving]; % palm   % body
   N_Xnew_X1= [length(X1fixed),length(X2fixed)];
   flag=1;
   k=1;
   Xf = X_new{1,1};
   Xp = X_new{1,2};
   %%%%%%%%%%%%%% need to judge the seperate parts
   %%%%%%%%%% X1fixed,X1moving X2fixed,X2moving
   figure
   subplot(2,2,1)
   pcshow(pointCloud(X1fixed)) %united %%%%%%%%%hat+arm
   title('X1fixed');
   subplot(2,2,2)
   pcshow(pointCloud(X1moving)) %seperate%%%%%%%%%%%%%%%%%%hat+arm
   title('X1moving');
   subplot(2,2,3)
   pcshow(pointCloud(X2fixed)) %united%%%%%%%%%%%%%%%%%body
   title('X2fixed');
   subplot(2,2,4)
   pcshow(pointCloud(X2moving)) % seperate%%%%%%%%%%%%%%%%%%%%body
   title('X2moving');
   c1 = X2fixed;    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% body for united
   c2 = X2moving;  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% body for seperate
   clear X1moving X1fixed X2moving X2fixed

       X1 = X_new{1,1}(1:N_Xnew_X1(1,1),:);% fixed % hat+arm
       X2 = X_new{1,1}(N_Xnew_X1(1,1)+1:length(X_new{1,1}),:); % moving % saperate % hat+arm
       [n1,d1] = size(X_new{1,1});
       a1=diag(cov(X2));  
       ss = sqrt((median(a1))/2);   
       sm = 30;  
       X=[X1;X1]; % united hat+arm
      [niw1] = Gauss_initi_p(d,X1,sm,ss); % the initial guass information for the fixed model
      [niw2] = Gauss_initi_p(d,X1,sm,ss); % the initial guass information for the moving model
%       niw=niw2;
      [niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster
      [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X,niw2,niw1,niw);
      [X1moving{1,1},X1fixed{1,1},X2moving{1,1},X2fixed{1,1}] = Partiton(dpmm,X,X1) ;
%%%%%%%%%%%%% united arm +hat
figure;
subplot(1,2,1)
pcshow(pointCloud(X1fixed{1,1})); % arm
subplot(1,2,2)
pcshow(pointCloud(X2fixed{1,1}));  %hat united hat1

   
       
       [n1,d1] = size(X_new{1,1});
       a1=diag(cov(X2));    
       ss = sqrt((median(a1))/2);   
       sm = 30;  
       X=[X2;X2];
%        X=X2;
      [niw1] = Gauss_initi_p01(d,X2,sm,ss); % the initial guass information for the fixed model
      [niw2] = Gauss_initi_p01(d,X2,sm,ss); % the initial guass information for the moving model
      [niw] = Gauss01(d,ss,sm); 
%      niw=niw2;
%       [niw] = Gauss02(d,ss,sm,niw1,niw2); % the intial guass for unknown cluster
%         niw.S0= niw1.S0+niw2.S0;
%         niw.mu0= niw1.mu0+niw2.mu0;
      [dpmm2, dpmm_posterior, dpmm_time] = DPMM_gauss01(X,niw1,niw2,niw);
      [X1moving{1,2},X1fixed{1,2},X2moving{1,2},X2fixed{1,2}] = Partiton(dpmm2,X,X2) ; 
  %%%%%%%%%%%% seperate arm+hat
  figure;
subplot(1,2,1)
pcshow(pointCloud(X1fixed{1,2})); % arm
subplot(1,2,2)
pcshow(pointCloud(X2fixed{1,2}));  %hat  seperate hat 1   
     %%%% check the gap seperate
 a1=diag(cov(X1fixed{1,2}));
 [dpmm_X2p1p2,X2p1p2p1,X2p1p2p2,niw] = Partition_single_partition(X1fixed{1,2},a1);
 
%  a3=diag(cov(X1fixed{1,2}));
%  [dpmm_X2p1p2,X2p1p2p1,X2p1p2p2,niw] = Partition_single_partition(X1fixed{1,1},a3);
%%%%%% seperate hat and arm
figure
subplot(1,2,1)
pcshow(pointCloud(X2p1p2p1)); %%% seperate arm 
subplot(1,2,2)
pcshow(pointCloud(X2p1p2p2)); %%%% seperte hat2
 
   
      
       X3 = X1fixed{1,1};
       a1=diag(cov(X3));    
       ss = sqrt((median(a1))/2);   
       sm =50;  
       X=[X3;X3];

      [niw1] = Gauss_initi_p(d,X3,sm,ss); % the initial guass information for the fixed model
      [niw2] = Gauss_initi_p(d,X3,sm,ss); % the initial guass information for the moving model
      [niw] = Gauss01(d,ss,sm); 
%      niw=niw2;
%       [niw] = Gauss02(d,ss,sm,niw1,niw2); % the intial guass for unknown cluster
      [dpmm3, dpmm_posterior, dpmm_time] = DPMM_gauss01(X,niw1,niw2,niw);
      [X3moving{1,2},X3fixed{1,2},X4moving{1,2},X4fixed{1,2}] = Partiton(dpmm3,X,X3) ;    
 figure;
subplot(1,2,1)
pcshow(pointCloud(X3fixed{1,2})); % arm % united arm
subplot(1,2,2)
pcshow(pointCloud(X4fixed{1,2}));  %hat    % united hat2



figure
subplot(2,4,1)
pcshow(pointCloud(c1))
title('source');
pcwrite(pointCloud(c1),'source1.ply');
subplot(2,4,2)
pcshow(pointCloud(c2))
pcwrite(pointCloud(c2),'target1.ply');
title('target');
subplot(2,4,3)
pcshow(pointCloud(X2p1p2p1));
pcwrite(pointCloud(X2p1p2p1),'target2.ply');
title('target');
subplot(2,4,4)
pcshow(pointCloud(X2p1p2p2));
pcwrite(pointCloud(X2p1p2p2),'target3.ply');
title('target');
subplot(2,4,5)
pcshow(pointCloud(X3fixed{1,2}));
title('source');
pcwrite(pointCloud(X3fixed{1,2}),'source2.ply');
subplot(2,4,6)
pcshow(pointCloud(X4fixed{1,2}));
title('source');
pcwrite(pointCloud(X4fixed{1,2}),'source3.ply');
subplot(2,4,7)
pcshow(pointCloud(X2fixed{1,1})); 
title('source');
pcwrite(pointCloud(X2fixed{1,1}),'source4.ply');
subplot(2,4,8)
pcshow(pointCloud(X2fixed{1,2}));  %hat    
title('target');
pcwrite(pointCloud(X2fixed{1,2}),'target4.ply');

   
   





















   
   
   
  while flag
   for i = 1 : 2
       X1 = X_new{1,i}(1:N_Xnew_X1(1,i),:);% fixed
       X2 = X_new{1,i}(N_Xnew_X1(1,i)+1:length(X_new{1,i}),:); % moving % saperate 
       [n1,d1] = size(X_new{1,i});
       a1=diag(cov(X2));    
       ss = sqrt((median(a1))/2);   
       sm = 50;  
       X=[X1;X2];
      [niw1] = Gauss_initi_p(d,X1,sm,ss); % the initial guass information for the fixed model
      [niw2] = Gauss_initi_p(d,X2,sm,ss); % the initial guass information for the moving model
%       [niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster
%       niw.S0= niw1.S0+niw2.S0;
%       niw.mu0= niw1.mu0+niw2.mu0;
      niw=niw2;
      [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X,niw2,niw1,niw);
%      [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss(X2);
      [X1moving{1,i},X1fixed{1,i},X2moving{1,i},X2fixed{1,i}] = Partiton(dpmm,X_new{1,i},X1) ;
      X_new{1,i}= [X1fixed{1,i};X1moving{1,i}]; % moving is the seperate
      N_Xnew_X1(1,i)=length(X1fixed{1,i});
   end
  end
A1= [X1fixed{1,1};X1moving{1,1}]; % arm 
B1= [X2fixed{1,1};X2moving{1,1}];  %hat
b1 = X2fixed{1,1}; %united
b2 = X2moving{1,1}; % seperate
a1 = X1fixed{1,1}; % united arm
a2 = X1moving{1,1}; % seperate


%%%%%%%%%% 
% X1 X2 is body
% b1 b2  is hat
% A1 is arm
% �ֳ�������
tformb = pcregistercpd(pointCloud(b1),pointCloud(b2));
movingRegb = pctransform(pointCloud(b1),tformb);
figure
subplot(1,2,1)
pcshow(pointCloud(b1));
subplot(1,2,2)
pcshow(pointCloud(b2));

pcshowpair(pointCloud(b1),pointCloud(b2),'MarkerSize',50);
legend('b1','b2');
pcshowpair(movingRegb,pointCloud(b2),'MarkerSize',50)

ptCloud=pointCloud(b1);
pcwrite(ptCloud,'hat_fixed.ply');

ptCloud1=pointCloud(b2);
pcwrite(ptCloud1,'hat_moving.ply');


ptCloud2=pointCloud(c1);
pcwrite(ptCloud2,'body_fixed.ply');

ptCloud3=pointCloud(c2);
pcwrite(ptCloud3,'body_moving.ply');

ptCloud4=pointCloud(a1);
pcwrite(ptCloud4,'arm_fixed.ply');

ptCloud5=pointCloud(a2);
pcwrite(ptCloud5,'arm_moving.ply');
a1=diag(cov(b1));   
ss = sqrt((median(a1))/2);   
sm = 50;  
X=[b1;b2];
[niw1] = Gauss_initi_p(d,b1,sm,ss); % the initial guass information for the fixed model
[niw2] = Gauss_initi_p(d,b2,sm,ss); % the initial guass information for the moving model
[niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster
niw.S0= niw1.S0+niw2.S0;
niw.mu0= niw1.mu0+niw2.mu0;
%  niw = niw2;
[dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X,niw1,niw2,niw);
[b1moving,b1fixed,b2moving,b2fixed] = Partiton(dpmm,B1,b1);
subplot(1,2,1)
pcshow(pointCloud(b1fixed));
subplot(1,2,2)
pcshow(pointCloud(b2fixed));