function [XR_s,XR_re] = outliers_detect(XR)
    %check if there are outliers
        XR_s = cell2mat(XR{1,1});
        XR_t = cell2mat(XR{2,1});
        XR_un =XR_s; % source
        XR_re = [];
        flag=1;

    while flag
        Std_st = zeros(3,2);
        Sk_st = zeros(3,2);
%        figure;
        for i=1:3
%         subplot(1,3,i)
            Xr1=XR_s(:,i);
            Xr2=XR_t(:,i);
%             h1=histfit(Xr1);
%             hold on
%             h2=histfit(Xr2);
            std1=std(Xr1);
            std2=std(Xr2);
            sk1=skewness(Xr1);
            sk2=skewness(Xr2);
            Std_st(i,:)=[std1,std2];
            Sk_st(i,:)=[sk1,sk2];
        end
            Std_st_delta = Std_st(:,1)-Std_st(:,2);
            if length(find(Std_st_delta(:,1)>0))<2
              XR_re = []; 
               break;
            else
            Std_st_delta_abs = abs(Std_st(:,1)-Std_st(:,2));
            [a1,b1]=max(Std_st_delta_abs); % b1 is index/ dimensions
%               a1=Std_st_delta_abs(1,1);b1=1;
                        if a1>0.001
                            %0.001 <0.0154boxing
                                if Sk_st(b1,1)<0 
                                 [a2,b2]= min(XR_s(:,b1)); % b2 is the index of points
                                 XR_re= [XR_re;XR_un(b2,:)];
                                         if size(XR_re,1)~=1
                                                 if   abs(XR_re(size(XR_re,1),1)-XR_re(size(XR_re,1)-1,1))<0.05
                                                     %0.05
                                                             XR_un(b2,:)=[];
                                                 else
                                                      XR_re(size(XR_re,1),:)=[];
                                                 end
                                         else
                                                    XR_un(b2,:)=[];       
                                         end
                                else
                                  break;
                                     [a2,b2]= max(XR_s(:,b1)); % b2 is the index of points
                                     XR_re= [XR_re;XR_un(b2,:)]; 
                                     XR_un(b2,:)=[];  
                                end
                                    XR_s=XR_un;
                        else
                              flag=0;
                              break;
                        end
            end
    end
end

