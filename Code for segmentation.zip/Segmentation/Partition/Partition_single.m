% function [dpmm,XR] = Partition_single(X1)
function [dpmm,XR] = Partition_single(X1,sm,iteration)
%     X = [X1;X2];
     t=size(X1,2);
     X=X1(:,1:t);
     X2=X1(:,1:t);
%%             Determine the parameters
      [n,d] = size(X);
    a1=diag(cov(X2));   
     ss = sqrt((median(a1))/2); 
%       ss = 0.1;                                                           
%       sm = 10;  
% if niw1=niw2=niw,partition of the final transformed model groups one cluster
% if niw1~=niw2~=niw, partition groups two clusters
      [niw1] = Gauss_initi_p(d,X2,sm,ss); % the initial guass information for the fixed model
      [niw2] = Gauss_initi_p(d,X2,sm,ss); % the initial guass information for the moving model
      [niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster
%       niw1=niw;
%       niw2=niw;
%   niw.S0= (niw1.S0+niw2.S0)/2;
%   niw.mu0= (niw1.mu0+niw2.mu0)/2;
% niw=niw2;
%%     Achieve the clusters through DPMM  
[dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X,niw1,niw2,niw,iteration);
%      [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss(X);
% [X1moving,X1fixed,X2moving,X2fixed] = Partiton(dpmm,X,X1) ;
 [XR] = Partiton_Single01(dpmm,X1);
end

