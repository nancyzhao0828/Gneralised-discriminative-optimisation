function [Xr,X2d,X1d] =Mainfunction(Xx,Xy,sm,num_gibbs) 
     
      [dpmm1,XP1] = Partition_single(Xy); % target
      if dpmm1.K==1
          X2d=XP1;  %X2d
          [dpmm2,XP2] = Partition_single(Xx);  % source 
          X1d=XP2; %X1d
          Xr{1,1}=[];
          Xr{2,1}=[];
              for j = 1: length(XP2)
                   Label(j,1) = length(unique(XP2{j,1}(:,4))); 
              end
               if length(unique(Label))==1
                   Xr=[];
                   String='partition is finished!';
                   disp(String);
               else
                 String='partition continues ... !';
                 disp(String);
                 index=find(Label(:,1)>1);
                 T=tabulate(XP2{index,1}(:,4));
                  [a1,b1]=min(T(:,3));
                           if T(b1,3)<10 ||  T(b1,2)<10
                                 A=XP2{index,1}(find(XP2{index,1}(:,4)==T(b1,1)),:);
                                 [a,b]=ismember(A,XP2{index,1},'rows');
                                 XP2{index,1}(b,:)=[];
                                 XP2(cellfun(@isempty,XP2))=[];
                                     if index==1
                                       XP2{2,1}=[(XP2{2,1});A];
                                       Xr{2,1}=XP2{2,1};
                                     else
                                       XP2{1,1}=[(XP2{1,1});A];
                                       Xr{2,1}=XP2{1,1};
                                     end
                               else
                                  String=['Xr{2,1}{' ,num2str(j), ',1} should be divided again !']; 
                                  disp(String);
                                  X1d={XP2{index,1}};
                                  X2d=XP1;
                                  Xr{1,1}=[];                             
                           end
               end
    else
          clear XP1 dpmm1
          [dpmm,Xr] =Partition_whole(Xx,Xy,sm,num_gibbs); %sm 50
              k_c = dpmm.K;
              k_n = length(Xr);
              X2d = cell(k_c,1);
              X1d = cell(k_c,1);
              XR_C =Xr{k_n,1}; % the partition result of X2
%               figure;
              for j = 1: length(Xr{2,1})
                       label = length(unique(Xr{2,1}{j,1}(:,4))); 
                       T=tabulate(Xr{2,1}{j,1}(:,4));
                        [a1,b1]=min(T(:,3));
                         if label>1
                           if T(b1,3)<5 ||  T(b1,2)<5
                             A=Xr{2,1}{j,1}(find(Xr{2,1}{j,1}(:,4)==T(b1,1)),:);
                             [a,b]=ismember(A,XR_C{j,1},'rows');
                             XR_C{j,1}(b,:)=[];
                             XR_C(cellfun(@isempty,XR_C))=[];
                                 if j==1
                                   XR_C{2,1}=[(XR_C{2,1});A];
                                   Xr{2,1}=XR_C;
                                 else
                                   XR_C{1,1}=[(XR_C{1,1});A];
                                   Xr{2,1}=XR_C; 
                                 end
                           else
                              String=['Xr{2,1}{' ,num2str(j), ',1} should be divided again !']; 
                              disp(String);
                              label_r(j,1) = j;
                              X2d{j,1} = Xr{2,1}{j,1};
                              X1d{j,1} = Xr{1,1}{j,1};
%                               subplot(1,2*k_c,2*j-1)
%                               pcshow(pointCloud(X2d{j,1}(:,1:3)));
%                               subplot(1,2*k_c,2*j)
%                               pcshow(pointCloud(X1d{j,1}(:,1:3)));
                           end
                         else
                              String='Partition is finished !'; 
                              disp(String);
                         end
                         clear T;
              end
                     X1d(cellfun(@isempty,X1d))=[];
                     X2d(cellfun(@isempty,X2d))=[];
                     if ~isempty(X1d)&& ~isempty(X2d)
                             if  length(unique(cellfun(@isempty,X2d)))==length(X2d)
                                    label_r= label_r(find(label_r~=0),1);
                                     Xr{2,1}{label_r,1}=[];
                                     Xr{1,1}{label_r,1}=[];
                                     Xr{1,1}(cellfun(@isempty,Xr{1,1}))=[];
                                     Xr{2,1}(cellfun(@isempty,Xr{2,1}))=[];
                                     XRC1=cell2mat(XR_C);
                                     Xr2=cell2mat(Xr{2,1});
                                     A=ismember(XRC1,Xr2,'rows');
                                     X2d1=XRC1(find(A(:,1)==0),:);
                                     for i=1:length(XR_C)
                                          if length(X2d1) == length(XR_C{i,1})
                                             X2d={XR_C{i,1}};
                                          end
                                     end        
                             else
                                     if unique(cellfun(@isempty,X2d))==0
                                          Xr{1,1}=[];
                                          Xr{2,1}=[];
                                     else
                                         String='partition finished!';
                                         disp(String);
                                     end
                             end   
                     end

      end
 
end

