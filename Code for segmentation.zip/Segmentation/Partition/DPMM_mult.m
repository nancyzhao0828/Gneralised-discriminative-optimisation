function [dpmm, dpmm_time] = DPMM_mult()
%% Dirichlet Process Mixture Model for Categorical Data
% 
% G ~ DP(a,H)
% H is a Dirichlet

%clear all; close all; 
rng('default');

%% load data
load nips_data.mat

%% DPMM parameters

dd = size(term_doc,1);  %num of words
NN = size(term_doc,2);  %num of docs
K = 2;                  %num of init clusters
alpha = 1;              %alpha parameter

num_gibbs = 100;

% construct data
xx = num2cell(term_doc,1);  %each cell is a document
%% Dirichlet prior

hh.dd = dd;       % Dirichlet(hh.aa/hh.dd,...,hh.aa/hh.dd)
hh.aa = 10000;     

%% DPMM algorithm

%init z (alternatively, can use k-means)
zz = ceil(rand(1,NN)*K);

%init dpmm
fprintf('initializing dpmm...\n');

% initialize finite mixture
mult = mult_init(hh); %init multinomial struct
dpmm = dpmm_init(K,alpha,mult,xx,zz);

record_K = zeros(num_gibbs,1);
dpmm_time = zeros(num_gibbs,1);

for iter=1:num_gibbs
   
   fprintf('gibbs iter: %d\n', iter);
   record_K(iter) = dpmm.K;   
   
   tic;
   for ii = 1:NN
       k = dpmm.z(ii);       
       %remove xi statistics from component zi       
       dpmm.nk(k) = dpmm.nk(k) - 1;       
       dpmm.mm{k} = del_item(dpmm.mm{k}, dpmm.X{ii});

       if (dpmm.nk(k) == 0)
           %delete empty component
           dpmm.mm(k) = [];
           dpmm.K = dpmm.K - 1;
           dpmm.nk(k) = [];          
           idx = find(dpmm.z>k);      
           dpmm.z(idx) = dpmm.z(idx) - 1;  %re-label component
       end
       
       log_pzi = log([dpmm.nk; dpmm.alpha]);  %p(zi=k|z_mi,alpha)       
       for kk=1:dpmm.K+1          
          %log p(zi=k|z_mi,x,alpha,beta) ~ log p(zi=k|z_mi,alpha) + log p(x_i|x_kmi, beta)
          log_pzi(kk) = log_pzi(kk) + log_predictive(dpmm.mm{kk}, dpmm.X{ii});
       end
       %sample zi ~ P(zi=k|z_mi,x,alpha,beta)
       pzi = exp(log_pzi - max(log_pzi)); %numerical stability
       pzi = pzi/sum(pzi);       
       
       u = rand;
       k = find(u < cumsum(pzi),1,'first');
       
       if (k==dpmm.K+1)
           %create a new cluster
           dpmm.mm{k+1} = dpmm.mm{k}; %warm init
           dpmm.K = dpmm.K + 1;
           dpmm.nk= [dpmm.nk; 0];
       end
       
       %add xi statistics to component z_i=knew
       dpmm.z(ii) = k;
       dpmm.nk(k) = dpmm.nk(k) + 1;
       dpmm.mm{k} = add_item(dpmm.mm{k}, dpmm.X{ii});
       
   end 
   dpmm_time(iter) = toc;
end

%% generate plots
display_clusters(dpmm, words);
figure; plot(record_K)

end

function [dpmm] = dpmm_init(K,alpha,mult,X,z)

dpmm.K = K;
dpmm.N = size(X,2);
dpmm.alpha = alpha;
dpmm.mm = cell(1,K+1);  %cell of structs!
dpmm.X = X;
dpmm.z = z;
dpmm.nk = zeros(K,1);

%init mixture components
for kk = 1:K+1
    dpmm.mm{kk} = mult;
end

%add data items to mixture components
for i = 1:dpmm.N    
    k = z(i);
    dpmm.mm{k} = add_item(dpmm.mm{k},X{i});
    dpmm.nk(k) = dpmm.nk(k) + 1;
end

end

function [mult] = add_item(mult, xi)
if issparse(xi)
  [ii,jj,mi] = find(xi);
  mm = sum(mi);
  mult.nn = mult.nn + 1;
  mult.mi = mult.mi + xi;
  mult.mm = mult.mm + mm;
  mult.Z0 = mult.Z0 + gammaln(mm+1) - sum(gammaln(mi+1));
elseif isscalar(xi)
  fprintf('here');
  mult.nn = mult.nn + 1;
  mult.mi(xi) = mult.mi(xi) + 1;
  mult.mm = mult.mm + 1;
else
  error('data item type unknown.');
end

end

function [mult] = del_item(mult, xi)

if issparse(xi)
  [ii,jj,mi] = find(xi);
  mm = sum(mi);
  mult.nn = mult.nn - 1;
  mult.mi = mult.mi - xi;
  mult.mm = mult.mm - mm;
  mult.Z0 = mult.Z0 - gammaln(mm+1) + sum(gammaln(mi+1));
elseif isscalar(xi)
  fprintf('here');    
  mult.nn = mult.nn - 1;
  mult.mi(xi) = mult.mi(xi) - 1;
  mult.mm = mult.mm - 1;
else
  error('data item type unknown.');
end

end

function [mult] = mult_init(hh)
%create a multinomial struct with no data items
% pi ~ Dirichlet(hh.aa/hh.dd,...,hh.aa/hh.dd)

mult.dd = hh.dd;
mult.aa = hh.aa/hh.dd;
mult.mi = sparse(hh.dd,1);
mult.mm = 0;
mult.nn = 0;
mult.Z0 = 0;

end

function ll = log_predictive(mult,xi)
% log predictive probability of xx given other data items in the component
% log p(xi|x_1,...,x_n)

if issparse(xi)
  [ii,jj,mi] = find(xi);
  mm = sum(mi);
  ll = gammaln(mm+1) - sum(gammaln(mi+1)) ...
       + gammaln(mult.aa*mult.dd+mult.mm) - gammaln(mult.aa*mult.dd+mult.mm+mm) ...
       + full(sum(gammaln(mult.aa+mult.mi+xi) - gammaln(mult.aa+mult.mi)));
elseif isscalar(xi)
  ll = log((mult.aa+mult.mi(xi))/(mult.aa*mult.dd+mult.mm));
else
  error('data item type unknown.');
end

end

function display_clusters(dpmm, words)
% show clusters
for kk=1:dpmm.K
  fprintf(1,'cluster %d\n',kk);    
  mult = struct(dpmm.mm{kk});
  [ii,jj,mi]=find(mult.mi);
  [mi,l] = sort(mi);
  for ll=length(mi):-1:max(1,length(mi)-10)
    fprintf(1,'%d\t %s\n',mi(ll),words{ii(l(ll))}); %word counts, top words
  end
  fprintf(1,'\n');
end

end


%% notes
%init using k-means or DP-means
