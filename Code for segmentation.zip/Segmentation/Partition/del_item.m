function [gauss] = del_item(gauss, xi)

xi = xi(:);
gauss.n = gauss.n - 1;
gauss.rr = gauss.rr - 1;    
gauss.nu0 = gauss.nu0 - 1;
gauss.Sigma = cholupdate(gauss.Sigma,xi,'-');
gauss.mu = gauss.mu - xi;

end

