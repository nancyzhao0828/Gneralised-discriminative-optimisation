function [dpmm] = dpmm_init01(K,alpha,Gauss, X, z)

dpmm.K = K;
dpmm.N = size(X,1);
dpmm.alpha = alpha;
dpmm.gm = cell(1,K+1);  %cell of structs!
dpmm.X = X;
dpmm.z = z;
dpmm.nk = zeros(K,1);

%init mixture components
for kk = 1:K+1
    if kk==1||kk==2
    dpmm.gm{kk} = Gauss{kk,1};
    else
    dpmm.gm{kk} = Gauss{3,1};
    end
%  dpmm.gm{kk} = Gauss;
end

%add data items to mixture components            
for i = 1:dpmm.N    
    k = z(i);
    dpmm.gm{k} = add_item(dpmm.gm{k},X(i,:));
    dpmm.nk(k) = dpmm.nk(k) + 1;
end

end

