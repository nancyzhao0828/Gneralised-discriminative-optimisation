function [dpmm,X1p1,X1p2,X1p3] = Partition_single_partition(X1,a1)
%     X = [X1;X2];
     X=X1;
     X2=X1;
%%             Determine the parameters
      [n,d] = size(X);
%      a1=diag(cov(X1));   
     ss = sqrt((median(a1))/2); 
%       ss = 0.1;                                                           
      sm = 30;  
% if niw1=niw2=niw,partition of the final transformed model groups one cluster
% if niw1~=niw2~=niw, partition groups two clusters
      [niw1] = Gauss_initi_p(d,X1,sm,ss); % the initial guass information for the fixed model
      [niw2] = Gauss_initi_p(d,X2,sm,ss); % the initial guass information for the moving model
%       [niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster
%   niw.S0= (niw1.S0+niw2.S0)/2;
%   niw.mu0= (niw1.mu0+niw2.mu0)/2;
niw=niw2;
%%     Achieve the clusters through DPMM  
 [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X,niw1,niw2,niw);
%  [X1moving,X1fixed,X2moving,X2fixed] = Partiton(dpmm,X,X1) ;
 [X1p1,X1p2,X1p3] = Partiton_Single01(dpmm,X);
end

