figure
subplot(1,2,1)
pcshow(pointCloud(X2d{1,1}(:,1:3)));
subplot(1,2,2)
figure
pcshow(pointCloud(X1d{1,1}(:,1:3)));

figure
subplot(1,2,1)
XR1=cell2mat(Xr{1,1});
pcshow(pointCloud(XR1(:,1:3)));

subplot(1,2,2)
XR2=cell2mat(Xr{2,1});
pcshow(pointCloud(XR2(:,1:3)));


Mu1=mean(XR1);
Mu2=mean(XR2);
delta_XR1=XR1(:,1:3)-ones(length(XR1),1)*Mu1(:,1:3);
Normm_XR1= diag(cov(delta_XR1'));

delta_XR2=XR2(:,1:3)-ones(length(XR2),1)*Mu2(:,1:3);
Normm_XR2= diag(cov(delta_XR2'));
figure
histfit(Normm_XR2)
hold on
histfit(Normm_XR1)
legend('XR2','XR1');


figure
XR11 =cell2mat(X1d);
Pt1=[XR1;XR11];
pcshow(pointCloud(Pt1(:,1:3)))

figure;
subplot(1,3,1)
Xr1=XR3(:,1);
std1=std(Xr1);
Xr2=XR2(:,1);
std2=std(Xr2);
sk1=skewness(Xr1);
sk2=skewness(Xr2);
 h1=histfit(Xr1);
 hold on
 h2=histfit(Xr2);
 subplot(1,3,2)
 Xr1=XR3(:,2);
Xr2=XR2(:,2);
std1=std(Xr1);
std2=std(Xr2);
sk1=skewness(Xr1);
sk2=skewness(Xr2);
 h1=histfit(Xr1);
 hold on
 h2=histfit(Xr2);
 subplot(1,3,3)
Xr1=XR3(:,3);
Xr2=XR2(:,3);
std1=std(Xr1);
std2=std(Xr2);
sk1=skewness(Xr1);
sk2=skewness(Xr2);

 h1=histfit(Xr1);
 hold on
 h2=histfit(Xr2);

 x=1:1:length(Xr2);
 y=Xr2;
 [fitresult, gof] = fit( x',y,'Gauss2')
 