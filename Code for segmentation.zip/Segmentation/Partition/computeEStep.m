function [ P1, Pt1, Px, negativeLogLikelihood ] = computeEStep( X, Y, sigma2, w )
% The elements m, n of the matrix P are defined as:
%
%                      exp(C1*(Xn-Ym)^2)
% P(m,n) = ----------------------------------------,
%            sum-over-k(exp(C1*(Xn-Yk)^2)) + C2
%
% where C1 = -1/(2*sigma2), M is the number of points in Y, N is the number
% of points in X and D is the dimensionality of points (ex D=3 in case of 3
% dimensional points),
% and   C2 = ( (M*w)/(N*(1-w)) )*((2*pi*sigma2)^(D/2))
%
% The outputs are: P1 = P*1, Pt1 = P'*1, Px = P*X,
%  where 1 is a column vector of all ones.


D = size(X, 2);
M = size(Y, 1);
N = size(X, 1);

% Compute C2 as given in above equation
c   = power(2*pi*sigma2, D/2) *( w /(1-w) *M/N );
if(isSimMode())
    % Compute elements of P matrix
    pMatrix = zeros(M, N, 'like', X);
    for col = 1 : D
        pMatrix = pMatrix + (X(:,col)' - Y(:,col)).^2;
    end
    pMatrix     = exp(pMatrix*(-1/(2*sigma2)));
    
    % Compute Pt1, P1, Px
    pMatrixColSum  = sum(pMatrix);
    Pt1         = (pMatrixColSum./(pMatrixColSum +c))';
    pMatrix     = pMatrix./(pMatrixColSum +c);
    P1          = sum(pMatrix, 2);
    
    Px  = zeros(M, D, 'like', X);
    for col = 1 : D
        Px(:, col)  = pMatrix*X(:, col);
    end
    negativeLogLikelihood  = -sum(log(pMatrixColSum +c)) + D*N*log(sigma2)/2;
else
    % Codegen
    P1  = zeros(M,1, 'like', X);
    Px  = zeros(M, D, 'like', X);
    Pt1 = zeros(N, 1, 'like', X);
    
    for j = 1 : N
        pMatrixCol = (X(j,1) - Y(:,1)).^2;
        for col = 2 : D
            pMatrixCol = pMatrixCol + (X(j,col) - Y(:,col)).^2;
        end
        
        pMatrixCol = exp(pMatrixCol.*(-1/(2*sigma2)));
        pMatrixColSum =  sum(pMatrixCol);
        
        pMatrixCol = pMatrixCol./(c+pMatrixColSum);
        P1 = P1 + pMatrixCol;
        Px = Px + pMatrixCol*X(j, :);
        Pt1(j) = pMatrixColSum;
    end
    
    negativeLogLikelihood  = cast(-sum(log(Pt1 + c)) + D*N*log(sigma2)/2, 'like', X);
    Pt1 = Pt1./(Pt1+c);
end
end
