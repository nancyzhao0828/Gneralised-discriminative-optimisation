clc;
clear;
%%%%%%%%%%%%%%%  dataset
 fixed =pcread('C:\Users\zy080\Documents\MATLAB\BayesianCPD\Partition\p000069.ply');
 moving =pcread('C:\Users\zy080\Documents\MATLAB\BayesianCPD\Partition\p000089.ply');
 movingDownsampled = pcdownsample(moving,'gridAverage',0.03);
 fixedDownsampled = pcdownsample(fixed,'gridAverage',0.03);
 X1 = fixedDownsampled.Location;
 X2=movingDownsampled.Location;  % seperate
 
 %% assigning labels
 % source data
 [bids_X1, E_X1, Ne_X1] = find_delaunay_boundary03_fig1(double(X1),0.1);
 l1=length(bids_X1); 
 X1L = X1;
 for i=1:l1
     X1L(bids_X1{1,i},4)=i;
 end
 % target data
 [bids_X2, E_X2, Ne_X2] = find_delaunay_boundary03_fig1(double(X2),0.1);
 l2=length(bids_X2);
 X2L =X2;
 for i=1:l2
      X2L(bids_X2{1,i},4)=i;
 end
 
%% partition
 % partition for X1
 X=[X1;X2];
 [dpmm_X1,X1R] = Partition_single(X);
 %%%%%% determine the label 
[ valueX1p1,IndexX1p1]=ismember(X1p1,X1);
[ valueX1p2,IndexX1p2]=ismember(X1p2,X1);
%X1p1 is body   X1p2 is hat +arm
% partion for X2
[dpmm_X2,X2p1,X2p2] = Partition_single(X2);
[ valueX2p1,IndexX2p1]=ismember(X2p1,X2);
[ valueX2p2,IndexX2p2]=ismember(X2p2,X2);

%% determine wheather be divided entirely
k=dpmm_X2.K;
X2p1L=X2p1;
X2p1L(:,4)=X2L(IndexX2p1(:,1),4);
X2p1l=length(unique(X2p1L(:,4)));
if X2p1l>k
  disp('X2p1 is not splited entirely');  
  Sd ='X2p1';
end
X2p2L=X2p2;
X2p2L(:,4)=X2L(IndexX2p2(:,1),4);
X2p2l=length(unique(X2p2L(:,4)));
if X2p2l>k
  disp('X2p2 is not splited entirely');  
  Sd = 'X2p2';
end
% X2p1 is body X2p2 is hat+arm

%% figure
figure
subplot(2,2,1)
pcshow(pointCloud(X1p1)); title('arm+hat\_X1(unite)');
subplot(2,2,2)
pcshow(pointCloud(X2p1)); title('arm+hat\_X2(seperate)');
subplot(2,2,3)
pcshow(pointCloud(X1p2)); title('body\_X1(unite)');
subplot(2,2,4)
pcshow(pointCloud(X2p2)); title('body\_X2()');

%% determine the corresponding relation
mu_X1p1 =mean(X1p1);%1
mu_X2p1 =mean(X2p1);%3
mu_X1p2 =mean(X1p2);%2
mu_X2p2 =mean(X2p2);%4
SM_m1=[{X1p1};{X1p2};{X2p1L};{X2p2L}];
NP1={'X1p1';'X1p2';'X2p1';'X2p2'};
[an1,bn1]=ismember(Sd,NP1); %bn1
MuP1=[mu_X1p1;mu_X1p2;mu_X2p1;mu_X2p2];
[DP1] = Partition_corresponding(k,MuP1);


%% determine the next partition to be divided
[w,q]=find(bn1==DP1); % w is row, q is column
% the next part in source should be deivided 
Nd1=NP1{DP1(w,1),1};
Xd_T=cell2mat(SM_m1(DP1(w,1),1)); % target
Xd_S=cell2mat(SM_m1(bn1,1)); % source


%% partition again
            %  a1=diag(cov(Xd_S(:,1:3)));
            %  [dpmm_X2p1,Xd_Sd] = Partition_single(Xd_S(:,1:3));
            %  [dpmm_X1p1,Xd_Td] = Partition_single(Xd_T);
            %  k2=dpmm_X2p1.K;
            %  % determine the label
            %  valueXd_Sd=cell(1,k2);
            %  IndexXd_Sd=cell(1,k2);
            %  Ll=zeros(k2,1); % just for source
            %  for l=1:k2
            %  [ valueXd_Sd{1,l},IndexXd_Sd{1,l}]=ismember(Xd_Sd{1,l},Xd_S(:,1:3));
            %  Xd_Sd{1,l}(:,4)=Xd_S(IndexXd_Sd{1,l}(:,1),4);
            %  Ll(l,1)=length(unique(Xd_Sd{1,l}(:,4)));
            %  end
  [Ll,Xd_Sd,Xd_Td] = partitionagain(Xd_S(:,1:3),Xd_T);
 %% figure
  figure;
for i=1: k2
subplot(2,2*k2,2*i-1)
pcshow(pointCloud(Xd_Td{1,i})); title('united');
subplot(2,2*k2,2*i)
pcshow(pointCloud(Xd_Sd{1,i}(:,1:3))); title('seperate');
end
Xd2 = {Xd_Td;Xd_Sd};
 %% determine the next partition area
 bn2=find(Ll>2);
 % determine the corresponding relation
 Meanv=zeros(k2,3*k2);
 for j=1:length(Xd2)
    for i=1:k2
       Meanv(j,3*i-2:3*i)=mean(Xd2{j,1}{1,i}(:,1:3));
    end
 end
 MuP2=(reshape(Meanv',3,4))';
 [DP2] = Partition_corresponding(k2,MuP2);
 bn3=bn2*2; %(target+source=2)
 
 %% determine the next partition to be divided
[w,q]=find(bn3==DP2); % w is row, q is column
% the next part in target should be deivided
Xd_Tdd=Xd_Td{1,DP2(w,1)}; % target
Xd_Sdd=Xd_Sd{1,bn2}; % source

%% partition again
 [Ll1,Xd_Sd3,Xd_Td3] = partitionagain(Xd_Sdd,Xd_Tdd);
%% figure
 figure;
for i=1: k2
subplot(2,2*k2,2*i-1)
pcshow(pointCloud(Xd_Td3{1,i})); title('united');
subplot(2,2*k2,2*i)
pcshow(pointCloud(Xd_Sd3{1,i}(:,1:3))); title('seperate');
end

%% finish partition, start stitching
% determine the label of  target cloud 
f=[1,k2];
f(bn2)=[];
% Xd_Sd3{1,1},Xd_Sd3{1,2} ,Xd_Sd{1,f},SM_m1(4,1)
%                                 pcshow(pointCloud(Xd_Sd3{1,1}(:,1:3)));
%                                 hold on
%                                 pcshow(pointCloud(Xd_Sd3{1,2}(:,1:3)));
%                                 hold on
%                                 pcshow(pointCloud(Xd_Sd{1,f}(:,1:3)));
%                                 hold on
%                                 pcshow(pointCloud(SM_m1{4,1}(:,1:3)));
S=[{Xd_Sd3{1,1}(:,1:3)};{Xd_Sd3{1,2}(:,1:3)};{Xd_Sd{1,f}(:,1:3)};{SM_m1{4,1}(:,1:3)}];
SL=[unique(Xd_Sd3{1,1}(:,4))';unique(Xd_Sd3{1,2}(:,4))';unique(Xd_Sd{1,f}(:,4))';unique(SM_m1{4,1}(:,4))'];
sl=unique(SL,'row');
sll=length(sl);
Pm=zeros(sll,k2);
for i=1:sll
    Pm(i,:)= find(SL(:,2)==sl(i,2));
end
% start stitching
Ssti=cell(sll,1);
for i=1:sll
    Ssti{i,1}=[S{Pm(i,1),1};S{Pm(i,2),1}];
    subplot(1,sll,i)
    pcshow(pointCloud(Ssti{i,1}));
    ptCloudC1=pointCloud(Ssti{i,1});
    str = ['source',num2str(i)];
    pcwrite(ptCloudC1,str, 'PLYFormat', 'ascii');
end
% determine the stitching parts in source
% stitching for 2 parts :sll
% need to be find the corresponding relation
f=[1,k2];
f(DP2(w,1))=[];
% Xd_Td{1,f},Xd_Td3{1,1},Xd_Td3{1,2},SM_m1(2,1)
T=[{Xd_Td3{1,2}(:,1:3)};{Xd_Td3{1,1}(:,1:3)};{Xd_Td{1,f}(:,1:3)};{SM_m1{2,1}(:,1:3)}];
Tsti=cell(sll,1);
for i=1:sll
    Tsti{i,1}=[T{Pm(i,1),1};T{Pm(i,2),1}];
    subplot(1,sll,i)
    pcshow(pointCloud(Tsti{i,1}));
    ptCloudC1=pointCloud(Tsti{i,1});
    str = ['target',num2str(i)];
    pcwrite(ptCloudC1,str, 'PLYFormat', 'ascii');
end



 
 
 
 
 
 
 %% figure
 figure
 subplot(2,3,1)
pcshow(pointCloud(X1p1p1)); title('hat1\_X1(fixed)');
subplot(2,3,2)
pcshow(pointCloud(X2p1p1)); title('hat1\_X2(moving)');
subplot(2,3,3)
pcshow(pointCloud(X1p1p2)); title('hat2\_X1(fixed)');
subplot(2,3,4)
pcshow(pointCloud(X2p1p2)); title('arm\_X2(moving)');
subplot(2,3,5)
pcshow(pointCloud(X1p1p3)); title('arm\_X1(fixed)');
subplot(2,3,6)
pcshow(pointCloud(X2p1p3)); title('hat2\_X2(moving)');
%%%%%%%%%%%%%%%%%% mean
mu_X1p1p1 =mean(X1p1p1);
mu_X1p1p2 =mean(X1p1p2);
mu_X1p1p3 =mean(X1p1p3);
mu_X2p1p1 =mean(X2p1p1);
mu_X2p1p2 =mean(X2p1p2);
mu_X2p1p3 =mean(X2p1p3);
MuP1=[mu_X1p1p1;mu_X1p1p2;mu_X1p1p3;mu_X2p1p1;mu_X2p1p2;mu_X2p1p3];
DistanceP1 =zeros(6,6);
for i=1:6
    for j=1:6
       DistanceP1(i,j)=norm(MuP1(i,:)-MuP1(j,:)); 
    end
end
DistanceP1 (1:3,1:3)=100*ones(3,3);
DistanceP1 (4:6,4:6)=100*ones(3,3);
[value1,index1P]= min(min(DistanceP1));
index1P1=find(DistanceP1(index1P,:)==value1);
DistanceP1(index1P,:)=100;
DistanceP1(:,index1P)=100;
DistanceP1(:,index1P1)=100;
DistanceP1(index1P1,:)=100;
[value2P,index2P]= min(min(DistanceP1));
index2P1=find(DistanceP1(index2P,:)==value2P);
DistanceP1(index2P,:)=100;
DistanceP1(:,index2P)=100;
DistanceP1(:,index2P1)=100;
DistanceP1(index2P1,:)=100;
[value3,index3]= min(min(DistanceP1));
index3p=find(DistanceP1(index3,:)==value3);
DP=[index1P,index1P1;index2P,index2P1;index3,index3p];

                % % %%%%%%%%%%%%%%%%%%%%%% eig vector
                % % tr_X1p1p1 =trace(cov(X1p1p1));%19
                % % tr_X1p1p2 =trace(cov(X1p1p2));%17
                % % tr_X1p1p3 =trace(cov(X1p1p3)); %42
                % % tr_X2p1p1 =trace(cov(X2p1p1)); %31
                % % tr_X2p1p2 =trace(cov(X2p1p2)); %84
                % % tr_X2p1p3 =trace(cov(X2p1p3)); %17

%%%% combine  the partion parts
%%%%%% needs to figure out the combination parts


C1 = [X1p1p1;X1p1p2];
C2 = [X2p1p1;X2p1p3];
figure
subplot(1,2,1)
pcshow(pointCloud(C1))
subplot(1,2,2)
pcshow(pointCloud(C2))

B1=[X1p1p3;X1p2];
B2=[X2p1p2;X2p2];
figure
subplot(1,2,1)
pcshow(pointCloud(B1))
subplot(1,2,2)
pcshow(pointCloud(B2))

ptCloudC1=pointCloud(C1);
pcwrite(ptCloudC1,'hat_fixed.ply');
ptCloudC2=pointCloud(C2);
pcwrite(ptCloudC2,'hat_moving.ply');
ptCloudB1=pointCloud(B1);
pcwrite(ptCloudB1,'body_fixed.ply');
ptCloudB2=pointCloud(B2);
pcwrite(ptCloudB2,'body_moving.ply');

