function [niw] = Gauss02(d,ss,sm,niw1,niw2)
% Dtermine the parameters of initial guass   
niw.d  = d;                                                            % the dimensions of data
niw.mu0 = (niw1.mu0+niw2.mu0 )/2;
niw.k0 = 1;              %how strongly we believe in m0 prior
niw.S0 = 2*ss^2*eye(d);  %prior mean for Sigma
niw.nu0 = d+1;  %3       %how strongly we believe in S0 prior (dof) nu0>D-1
niw.ss = sm^2/ss^2;      %cluster spread               % ??????
niw.rr = 1/niw.ss;       %1/cluster spread                % ??????
niw.SS = niw.nu0*niw.S0; %nu0 * S0      
end