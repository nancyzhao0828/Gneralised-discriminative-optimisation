function [DP1] = Partition_corresponding(k,MuP1)
 DistanceP1 =zeros(2*k,2*k);
for i=1:2*k
    for j=1:2*k
       DistanceP1(i,j)=norm(MuP1(i,:)-MuP1(j,:)); 
    end
end
DistanceP1 (1:k,1:k)=100*ones(k,k);
DistanceP1 (2*k-1:2*k,2*k-1:2*k)=100*ones(k,k);
k1=1;
flag=1;
index1P=zeros(1,k);
index1P1=zeros(1,k);
while flag
[value1P,index1P(1,k1)]= min(min(DistanceP1));
index1P1(1,k1)=find(DistanceP1(index1P(1,k1),:)==value1P);
DistanceP1(index1P(1,k1),:)=100;DistanceP1(:,index1P(1,k1))=100;
DistanceP1(:,index1P1(1,k1))=100;DistanceP1(index1P1(1,k1),:)=100;
k1=k1+1;
if k1>k
    flag=0;
end
end
DP1=[index1P',index1P1'];
end

