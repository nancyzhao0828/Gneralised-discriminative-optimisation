function [mu,sigma] = rand_sample(gauss)
% [mu, sigma] = rand(qq)
% generates random mean mu and covariance sigma from the posterior of
% component parameters given data items in component.

CC = cholupdate(gauss.Sigma,gauss.mu/sqrt(gauss.rr),'-')\eye(gauss.d);

sigma = iwishrnd(CC,gauss.nu0,CC);
mu = mvnrnd(gauss.mu'/gauss.rr, sigma/gauss.rr)';

end
