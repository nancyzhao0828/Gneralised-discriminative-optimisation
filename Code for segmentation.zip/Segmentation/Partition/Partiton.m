function [X1moving,X1fixed,X2moving,X2fixed] = Partiton(dpmm,X,X1)
    % the output is the binary classification.
    z=dpmm.z;
%     figure(1)
    Index1=find(z==1);
    Index2=find(z==2);
%     hold on
%     plot3(X(Index1,1),X(Index1,2),X(Index1,3),'r.');
%     hold on
%     plot3(X(Index2,1),X(Index2,2),X(Index2,3),'m.');
%     title('the partitions in the whole model');
    X1p=X(Index1,:); % finger
    X2p=X(Index2,:); %palm

    N = length(X);
    N1= length(X1);
    X11=X(1:N1,:); % fixed
    X22=X(N1+1:N,:); % moving

    [lo21,iIndex21]=ismember(X22,X1p,'rows');%moving
    iIndex21(iIndex21==0)=[];
    X1moving = X1p(iIndex21,:); % finger in moving model
    [lo11,iIndex11]=ismember(X11,X1p,'rows');%fixed
    iIndex11(iIndex11==0)=[];
    X1fixed = X1p(iIndex11,:); % finger in fixed model  
    [lo22,iIndex22]=ismember(X22,X2p,'rows');
    iIndex22(iIndex22==0)=[];
    X2moving = X2p(iIndex22,:); % palm in moving model
    [lo12,iIndex12]=ismember(X11,X2p,'rows');
    iIndex12(iIndex12==0)=[];
    X2fixed = X2p(iIndex12,:); % palm in fixed model
%     figure(2)
%     scatter3(X2fixed(:,1),X2fixed(:,2),X2fixed(:,3),'m.');
%     hold on
%     scatter3(X1fixed(:,1),X1fixed(:,2),X1fixed(:,3),'y.');
%     title('the partition in the fixed model');
%     figure(3)
%     scatter3(X2moving(:,1),X2moving(:,2),X2moving(:,3),'m.');
%     hold on
%     scatter3(X1moving(:,1),X1moving(:,2),X1moving(:,3),'y.');
%    title('the partition in the moving model');
end

