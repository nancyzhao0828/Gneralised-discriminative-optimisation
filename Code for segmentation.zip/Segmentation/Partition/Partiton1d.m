function [X1moving,X1fixed,X2moving,X2fixed] = Partiton1d(dpmm,X,X1)
    % the output is the binary classification.
    z=dpmm.z;
    figure(1)
    Index1=find(z==1);
    Index2=find(z==2);
%     hold on
%     bar(X(Index1,:));
%     hold on
%     bar(X(Index2,:));
%     title('the partitions in the whole model');
    X1p=X(Index1,:); % finger
    X2p=X(Index2,:); %palm

    N = length(X);
    N1= length(X1);
    X11=X(1:N1,:); % fixed
    X22=X(N1+1:N,:); % moving

    [lo21,iIndex21]=ismember(X22,X1p,'rows');%moving
    iIndex21(iIndex21==0)=[];
    X1moving = X1p(iIndex21,:); % finger in moving model
    [lo11,iIndex11]=ismember(X11,X1p,'rows');%fixed
    iIndex11(iIndex11==0)=[];
    X1fixed = X1p(iIndex11,:); % finger in fixed model  
    [lo22,iIndex22]=ismember(X22,X2p,'rows');
    iIndex22(iIndex22==0)=[];
    X2moving = X2p(iIndex22,:); % palm in moving model
    [lo12,iIndex12]=ismember(X11,X2p,'rows');
    iIndex12(iIndex12==0)=[];
    X2fixed = X2p(iIndex12,:); % palm in fixed model
%     figure(2)
%     bar(X2fixed(:,1));
%     hold on
%     bar(X1fixed(:,1));
%     title('the partition in the fixed model');
%     figure(3)
%     bar(X2moving(:,1));
%     hold on
%     bar(X1moving(:,1));
%    title('the partition in the moving model');
end

