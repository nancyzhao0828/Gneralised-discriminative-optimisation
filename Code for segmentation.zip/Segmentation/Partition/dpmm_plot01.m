function [] = dpmm_plot01(dpmm)

cmap = hsv(dpmm.K);

for kk = 1:dpmm.K
  [mu sigma] = rand_sample(dpmm.gm{kk});
%   plotellipse01(mu,sigma,'color',cmap(kk,:),'linewidth',2);
%   hold on
  ii = find(dpmm.z==kk);
  d=length(mu);
  if (d > 2)
    [x_coeff, x_score] = pca(dpmm.X);
    x_pca = x_score(:,1:3);
    xx = x_pca(ii,:);
    plot3(xx(:,1),xx(:,2),xx(:,3),'.','color',cmap(kk,:),'markersize',10); hold on;
    xlabel('PC 1'); ylabel('PC 2'); zlabel('PC 3'); title('PCA Plot');       
  else
    xx = dpmm.X(ii,:);
    if size(xx,2)==1
        plot(xx); hold on;
    else
    plot(xx(:,1),xx(:,2),'.','color',cmap(kk,:),'markersize',10); hold on;
    xlabel('X1'); ylabel('X2');
%     plot3(xx(:,1),xx(:,2),xx(:,3),'.','color',cmap(kk,:),'markersize',10); hold on;
%     xlabel('PC 1'); ylabel('PC 2'); zlabel('PC 3'); title('PCA Plot');   
    end
  end
end

end

