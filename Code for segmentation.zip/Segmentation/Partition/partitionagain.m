function [Ll,Xd_Sd,Xd_Td] = partitionagain(Xd_S,Xd_T)
  a1=diag(cov(Xd_S(:,1:3)));
 [dpmm_X2p1,Xd_Sd] = Partition_single(Xd_S(:,1:3));
 [dpmm_X1p1,Xd_Td] = Partition_single(Xd_T);
 k2=dpmm_X2p1.K;
 % determine the label
 valueXd_Sd=cell(1,k2);
 IndexXd_Sd=cell(1,k2);
 Ll=zeros(k2,1); % just for source
 for l=1:k2
 [ valueXd_Sd{1,l},IndexXd_Sd{1,l}]=ismember(Xd_Sd{1,l},Xd_S(:,1:3));
 Xd_Sd{1,l}(:,4)=Xd_S(IndexXd_Sd{1,l}(:,1),4);
 Ll(l,1)=length(unique(Xd_Sd{1,l}(:,4)));
 end
end

