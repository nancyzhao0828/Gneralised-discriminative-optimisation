function ll = log_predictive(gauss,xi)
% log predictive probability of xx given other data items in the component
% log p(xi|x_1,...,x_n)
xi = xi(:);
ll =   ZZ(gauss.d,gauss.n+1,gauss.rr+1,gauss.nu0+1,cholupdate(gauss.Sigma,xi),gauss.mu+xi) ...
     - ZZ(gauss.d,gauss.n  ,gauss.rr  ,gauss.nu0  ,           gauss.Sigma    ,gauss.mu);
end


