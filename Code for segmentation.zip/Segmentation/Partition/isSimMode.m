function flag = isSimMode()
flag = isempty(coder.target);
end