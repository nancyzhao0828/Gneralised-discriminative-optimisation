% %%               Import data
%     handData = load('hand3d.mat');
%     moving = handData.moving;
%     fixed = handData.fixed;
%     movingDownsampled = pcdownsample(moving,'gridAverage',0.03);
%     fixedDownsampled = pcdownsample(fixed,'gridAverage',0.03);
% %%             CPD algorithm
%     tform = pcregistercpd(movingDownsampled,fixedDownsampled);
%     movingReg = pctransform(movingDownsampled,tform);
%     [~, dists] = knnsearch(movingReg.Location, fixedDownsampled.Location);
%     rmsewhole = sqrt(mean(dists(:)));
%     figure
%     pcshowpair(movingReg,fixedDownsampled,'MarkerSize',40);
%%             Combine data   
clc;
clear;
 fixed =pcread('C:\Users\zy080\Documents\MATLAB\BayesianCPD\Partition\p000084.ply');
 moving =pcread('C:\Users\zy080\Documents\MATLAB\BayesianCPD\Partition\p000087.ply');
%  X1=fixed.Location;
%  [Y1,PS1] = mapminmax(X1'); % normalize the data in [-1 1]
%  X1=Y1';
%  X2=moving.Location;
%  [Y2,PS2] = mapminmax(X2');
%   X2=Y2';
% movingDownsampled = pcdownsample(pointCloud(X2),'gridAverage',0.03);
% fixedDownsampled = pcdownsample(pointCloud(X1),'gridAverage',0.03);
 movingDownsampled = pcdownsample(moving,'gridAverage',0.03);
 fixedDownsampled = pcdownsample(fixed,'gridAverage',0.03);
X1=fixedDownsampled.Location;
% [Y1,PS1] = mapminmax(X1'); % normalize the data in [-1 1]
% X1=Y1';
X2=movingDownsampled.Location;
% [Y2,PS2] = mapminmax(X2');
% X2=Y2';
X=[X1;X2];
% [Y,PS1] = mapminmax(X'); % normalize the data in [-1 1]
%%             Determine the parameters
      [n,d] = size(X);
      ss = 0.1;                                                           
      sm = 30;  
% if niw1=niw2=niw,partition of the final transformed model groups one cluster
% if niw1~=niw2~=niw, partition groups two clusters
      [niw1] = Gauss_initi_p(d,X1,sm,ss); % the initial guass information for the fixed model
      [niw2] = Gauss_initi_p(d,X2,sm,ss); % the initial guass information for the moving model
      [niw] = Gauss01(d,ss,sm); % the intial guass for unknown cluster
%%     Achieve the clusters through DPMM  
 [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss01(X,niw1,niw2,niw);
%        [dpmm, dpmm_posterior, dpmm_time] = DPMM_gauss(X);
%%     Achieve the registration through Partition
      [rmse,Moving] = Registration_P(dpmm,X,X1);
%%    Check the partition of the transformed model 
      X2_new = Moving.Location;
      X_new = [X1; X2_new];
      [n_new,d_new] = size(X_new);
      [niw2_new] = Gauss_initi_p(d_new,X2_new,sm,ss); % the initial guass information for the moving model
      [niw_new] = Gauss01(d_new,ss,sm); % the intial guass for unknown cluster
%%     Achieve the clusters through DPMM  
%       [dpmm_transformed, dpmm_posterior_transformed, dpmm_time_transformed] = DPMM_gauss01(X_new,niw1,niw2_new,niw_new);
      [dpmm_transformed, dpmm_posterior_transformed, dpmm_time_transformed] = DPMM_gauss(X_new);