function [r2,r3,r4,R_C1_keep] = Colorf(Color_O)
    for i=1:size(Color_O,1)
            c01=single(Color_O(i,:));
            c01_min=min(c01)/256;
            c01_max=max(c01)/256;
            c01_median=median(c01)/256;
            r2(i,:)=c01_max/c01_min;
            r3(i,:)=c01_median/c01_min;
            r4(i,:)=Color_O(i,1)-Color_O(i,2);
            R_C1_keep(i,:)=round(r3(i,:))/round(r2(i,:));
    end
end

