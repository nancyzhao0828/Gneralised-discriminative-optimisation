function [pt1_xyz] =Ffeature(PT1)
  pt1_xyz.xm=min(PT1(:,1));
  pt1_xyz.xM=max(PT1(:,1));
  pt1_xyz.yM=max(PT1(:,2));
  pt1_xyz.ym=min(PT1(:,2));
  pt1_xyz.zM=max(PT1(:,3));
  pt1_xyz.zm=min(PT1(:,3));
end

