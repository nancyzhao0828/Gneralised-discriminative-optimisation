function [re,p03] = p0_refine(p03)
    pm=mean(p03);

for i=1:length(p03)
    d(i,1)=sum((p03(i,:)-pm).^2,2);
end
d2=find(d>1);
p1=p03;
p03(d2,:)=[];
re=p1(d2,:);
end

