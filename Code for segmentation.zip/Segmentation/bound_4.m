function [Outliers1,F_matrix,PT2] = bound_4(pt_o1_y1_2_1,Bid_2_1,ra,beta,note1,note2)
    pt1_InstrLocation=pt_o1_y1_2_1.Location;
%     ct1_InstrLocation=pt_o1_y1.Color;
    for i=1:length(Bid_2_1)
         PT1=pt1_InstrLocation(Bid_2_1{1,i},:);  % boundary data
    end
    [Instr_index_re,p0] = bound_2(pt_o1_y1_2_1,Bid_2_1);
    re=[];
%     [re,p0] = p0_refine(p0);
%     pt1c=ct1_InstrLocation(Bid{1,1},:);
    PT2=[pt1_InstrLocation(Instr_index_re,:);re];  % Rough Partition related to boundary
%     CT2=ct1_InstrLocation(Instr_index_re,:);
    [ normals, curvature ] = findPointNormals(PT1, 3);
    contour(normals);
    if beta==1
    pt2=PT1(1:ra,:);% contour normals
    else
    pt2=PT1(ra:end,:);    
    end
    
    plot3(pt2(:,1),pt2(:,2),pt2(:,3),'r.');
    hold on
    plot3(PT2(:,1),PT2(:,2),PT2(:,3),'b.');
    pcshow(pointCloud(pt2))             % boundary picked
    pcshowpair(pointCloud(pt2),pointCloud(PT2))
    Idx= find((PT2(:,1)<=max(pt2(:,1)))&(PT2(:,2)<=max(pt2(:,2)))); % narrow the partition
    pcshowpair(pointCloud(PT2(Idx,:)),pointCloud(pt2));
    pm=PT2(Idx,:);% 1455 -> 415
    pm1=PT2;
    pm1(Idx,:)=[]; %1040          keep Organ 1
    Pm=pointCloud(pm);
%     cm=CT2(Idx,:);
%     Pm.Color=cm;
    [a01,a02]=max(pt2(:,1));
    [b01,b02]=min(pt2(:,1));
    plot(pm(:,1),pm(:,2),'b.');
    hold on
    plot(pt2(:,1),pt2(:,2),'r.');
    hold on
    plot(pt2(a02,1),pt2(a02,2),'yo');
    hold on
    plot(pt2(b02,1),pt2(b02,2),'ys');
    %% fitting 
    if note1==1
    fitobject = fit(pt2(:,1),pt2(:,2),'poly1');
    p1=fitobject.p1;
    p2=fitobject.p2;
    else
    p1=(pt2(b02,2)-pt2(a02,2))/(pt2(b02,1)-pt2(a02,1));
    p2= pt2(a02,2)-p1*pt2(a02,1);
    end
    A_matrix=zeros(length(pm),6); 
    A_matrix(:,1:3)=pm;
   [~,index2]= ismember(pt2,pm,'rows');
   A_matrix(index2,4)=1;
   A_matrix(:,5)=p1*A_matrix(:,1)+p2;
   hold on
    plot(A_matrix(:,1),A_matrix(:,5),'yo');
   if note2==1
       rr=1;
   else
       rr=-1;
   end
   A_matrix(:,6)=rr*sign(A_matrix(:,2)-A_matrix(:,5));
   index=find(A_matrix(:,6)==-1);
  hold on
  plot(A_matrix(index,1),A_matrix(index,2),'y+');
  F_matrix=unique([A_matrix(index,1:3);pt2;pm1],'rows'); %1431
  [~, index1]=ismember(F_matrix,PT2,'rows');
  Outliers1=PT2;
  Outliers1(index1,:)=[]; %24
%   [out,bid,ou1] = partition_repeat02(pointCloud(Outliers1),0.004); 
  
  
%   B_matrix=A_matrix;
%   B_matrix(index,:)=[];
%   B_matrix(:,7)=abs(B_matrix(:,2)-B_matrix(:,5));
%   C_matrix=sortrows(B_matrix,7,'descend');
%   index_=find(C_matrix(:,4)==1);
%   D_matrix=C_matrix(min(index_):max(index_),:);
%   iindex_=find(D_matrix(:,4)==0);
%   [~,ptt]=ismember(D_matrix(iindex_,1:3),C_matrix(:,1:3),'rows');
%   tp=[index_;ptt];
%   hold on
%   plot(C_matrix(tp,1),C_matrix(tp,2),'g*')
%   C_matrix(tp,:)=[];
%   Outliers1=C_matrix(:,1:3);
    hold on
  plot(Outliers1(:,1),Outliers1(:,2),'ms'); 
%   [~,Iindex]=ismember(Outliers1,PT2,'rows');
%   PT2(Iindex,:)=[];
end


% idx = dbscan(pm,0.015,2);
% indxPt=find(idx==1);
% B = rmoutliers(pm,'gesd');
% [~,indxPt]=ismember(B,pm,'rows');
% 
% pcshowpair(pointCloud(pm(indxPt,:)),pointCloud(pm))
% 
% 
% 
% 
%  [dpmmP,XRP] = Partition_single(PT2(Idx,:),100,20);
%  
% for i=1:length(XRP)
%             [~,indxP{i,1}]=ismember(XRP{i,1},pm,'rows'); % repeat
%             LP(i,1)=length(indxP{i,1});
% end
% 
%  Location_OP1=pm(indxP{1,1},:);
%  Location_OP2=pm(indxP{2,1},:);
% pcshowpair(pointCloud(Location_OP1),pointCloud(Location_OP2));
% 
% % index=
% % [bids_X3_, E_X2_, Ne_X2_] = find_delaunay_boundary03_fig1(double(PT2(Idx,:)),0.004);
% 
% 
% pcshow(pointCloud(pt2))
% PT=pt2;
% [~,indx1]=ismember(pt2,pm,'rows');
% [sm,lindex]=max(pt2(:,1));
% sm=pt2(lindex,:);
% sk=10;
% Idx_knn = knnsearch(pm,sm,'k',sk);
% Idx=Idx_knn';
% t=0;
% hold on
% %Idx = rangesearch(X,Y,r)
% % %     while(flag)
% for t=0:58
%             [~,pick]=ismember(Idx,indx1);
% %              if 
%              a1=(unique(pick)==0);
%              PT=[PT;pm(Idx,:)];
%              sm=mean(pm(Idx,:));
%              hold on
%              plot3(sm(1,1),sm(1,2),sm(1,3),'r+');
%              D=zeros(length(pt2),1);
%              for i=1:length(pt2)
% %                  D(i,1)=(sm(1,1)-PT1(i,1)).^2+(sm(1,2)-PT1(i,2)).^2+(sm(1,3)-PT1(i,3)).^2;
%              D(i,1)=(sm(1,3)-pt2(i,3)).^2;
%              end
%              [a0,b0]=max(D);
%              plot3(pt2(b0,1),pt2(b0,2),pt2(b0,3),'rs'); %
%              hold on
%              sm1=4*(pt2(b0,:)+sm)/6;
% %              hold on
% %              plot3(sm1(1,1),sm1(1,2),sm1(1,3),'ro');
% %              for j=1:length(PT1)
% %                D1(i,1)=(sm1(1,1)-PT1(i,1)).^2+(sm1(1,2)-PT1(i,2)).^2+(sm1(1,3)-PT1(i,3)).^2;
% %              end
% %              [a1,b1]=min(D1);
% %              plot3(PT1(b1,1),PT1(b1,2),PT1(b1,3),'rs'); %
%              Idx_knn = knnsearch(pm,sm1,'k',sk);
%              Idx=Idx_knn';
%            Dt=sum((ones(length(Idx),1)*sm1-pm(Idx,:)).^2,2);
%            app=max(Dt);
%            Dt1=abs(sum((pm(Idx(end-1),:)-pm(Idx(end),:)).^2,2));
%            Dt2=abs(sum((pm(Idx(end-2),:)-pm(Idx(end-1),:)).^2,2));
%              sk=sk+2;
%              t=t+1;
% %              [~,indx1]=ismember(PT,PT2,'rows');
% %             else
% %                 flag=0;
% %             end
% %     end
%      hold on
%      pcshow(pointCloud(PT))
%      aa=unique(PT,'rows');
% end
% 
% pcshow(pointCloud(PT1));
%  hold on
% pcshow(pointCloud(PT2));