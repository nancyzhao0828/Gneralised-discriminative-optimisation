ptCloud=pcread('E:\BaiduNetdiskDownload\Coding\Medicaldata\dataset\1085_Dataset9.ply');
figure
pcshow(ptCloud); %123200
%% normalized data
modelFull =ptCloud.Location';
modelFull = bsxfun(@minus,modelFull,min(modelFull,[],2));
modelFull = bsxfun(@minus,modelFull,max(modelFull,[],2)/2);
modelFull = modelFull / max(abs(modelFull(:)));
%% remove some points
Location_O=modelFull' ;
Color_O=ptCloud.Color;
iindex=find(Color_O(:,3)==0);
Location_O(iindex,:)=[];
Color_O(iindex,:)=[];
pt=pointCloud(Location_O);
pt.Color=Color_O;
 pcshow(pt);
%%%%%%%%%%%%%%%% Color_based partition
[Color_O1,I1,J1]=unique(Color_O,'rows');
[r2,r3,r4,R_C1_keep] = Colorf(Color_O);
[rc1,ci,cj]=unique(R_C1_keep);
for k=1:length(rc1)
       IJC{k,1} = find(rc1(k,1)==R_C1_keep(:,1));
end
Par=[];
P_index=[];
for p=1:length(rc1)
   if length(IJC{p,1})<10
      Par=[Par;IJC{p,1}];  
      P_index=[P_index;p];
   end
end
l2=linspace(1,length(IJC),length(IJC));
l2(1,P_index)=100;
P_index_left=find(l2(:)~=100);
for i=1:length(P_index_left)
        flg(i,1)=length(IJC{P_index_left(i,1),1});
        Location_i=Location_O(IJC{P_index_left(i,1),1},:);
        Color_i=Color_O(IJC{P_index_left(i,1),1},:);
        ptcloud_i=pointCloud(Location_i);
        ptcloud_i.Color=Color_i;
        PT{i,1}=ptcloud_i;
       subplot(1,length(P_index_left),i);
       pcshow(ptcloud_i);
end
% seperate into two groups
 [m1,n1]=sort(flg); % less to more
 pt_n1=PT{n1(end),1};
 pt_n2=PT{n1(end-1),1};
 PT{n1(end),1}={};
 PT(cellfun(@isempty,PT))=[];
 PT{end,1}={};
 PT(cellfun(@isempty,PT))=[];
 Location_n3= Location_O(Par,:);
 Color_n3= Color_O(Par,:);
 for i=1:length(PT)
     Location_n3=[PT{i,1}.Location;Location_n3];
     Color_n3 =[PT{i,1}.Color;Color_n3];
 end
 pt_n3=pointCloud(Location_n3);
 pt_n3.Color=Color_n3;
 figure
subplot(1,3,1) 
pcshow(pt_n1); % contain 80570 
subplot(1,3,2)
pcshow(pt_n2); % contain 38767 
subplot(1,3,3) 
pcshow(pt_n3); %3863
%% Partition starts!
%pt_n1
Locationl1=0.8*single(pt_n1.Color)/256;+0.2*(pt_n1.Location);
[nnp1,ip1,jp1]=unique(Locationl1,'rows');
[nnc1,ic1,jc1]=unique(pt_n1.Color,'rows');
[ptn1_01,ptn1_02,ptn1_03,indx_P1] = Position_Split(nnp1,nnc1,20,3);%30,5%20,3
for k=1:length(indx_P1)
for j =1:length(indx_P1{k,1})
       IJC_nn1{k,1}{j,1} = find(indx_P1{k,1}(j,1)==jp1(:,1));
end
end
for k=1:length(IJC_nn1)
    IJC_NN1{k,1}=cell2mat( IJC_nn1{k,1});
end
figure
for i=1:length(IJC_NN1)
    subplot(1,length(IJC_NN1),i);
    ptn1_{i,1}=pointCloud(pt_n1.Location(IJC_NN1{i,1},:));
    ptn1_{i,1}.Color=pt_n1.Color(IJC_NN1{i,1},:);
    [rn1_1{i,1},rn2_1{i,1},rn3_1{i,1}, R_C1_keep_1{i,1}] = Colorf(ptn1_{i,1}.Color);
    merge_cri1(i,1)=mean(rn2_1{i,1});
    pcshow(ptn1_{i,1});
end
clear IJC_nn1 IJC_NN1
    [a1,b1]=max(merge_cri1);
    ptn1_Instr=ptn1_{b1,1};
    ptn1_{b1,1}=[];
    ptn1_(cellfun(@isempty,ptn1_))=[];
    orlocation=[];
    orcolor=[];
for i=1:length(ptn1_)
    orlocation=[ptn1_{i,1}.Location;orlocation];
    orcolor=[ptn1_{i,1}.Color;orcolor];
end
ptn1_organ=pointCloud(orlocation);
ptn1_organ.Color=orcolor;
figure
subplot(1,2,1)
pcshow(ptn1_organ);%79368 %79653
subplot(1,2,2)
pcshow(ptn1_Instr);%1509%917
%pt_n2
Locationl2=0.2*single(pt_n2.Color)/256;+0.8*(pt_n2.Location);
[nnp2,ip2,jp2]=unique(Locationl2,'rows');
[nnc2,ic2,jc2]=unique(pt_n2.Color,'rows');
[ptn2_01,ptn2_02,ptn2_03,indx_P2] = Position_Split(nnp2,nnc2,50,20);
for k=1:length(indx_P2)
for j =1:length(indx_P2{k,1})
       IJC_nn2{k,1}{j,1} = find(indx_P2{k,1}(j,1)==jp2(:,1));
end
end
for k=1:length(IJC_nn2)
    IJC_NN2{k,1}=cell2mat( IJC_nn2{k,1});
end
figure
for i=1:length(IJC_NN2)
    subplot(1,length(IJC_NN2),i);
    ptn2_{i,1}=pointCloud(pt_n2.Location(IJC_NN2{i,1},:));
    ptn2_{i,1}.Color=pt_n2.Color(IJC_NN2{i,1},:);
    [rn1_2{i,1},rn2_2{i,1},rn3_2{i,1}, R_C1_keep_2{i,1}] = Colorf(ptn2_{i,1}.Color);
    merge_cri2(i,1)=mean(rn2_2{i,1});
    pcshow(ptn2_{i,1});
end
 [a2,b2]=max(merge_cri2);
 ptn2_Instr=ptn2_{b2,1};
 ptn2_{b2,1}=[];
 ptn2_(cellfun(@isempty,ptn2_))=[];
 orlocation=[];
 orcolor=[];
for i=1:length(ptn2_)
    orlocation=[ptn2_{i,1}.Location;orlocation];
    orcolor=[ptn2_{i,1}.Color;orcolor];
end
ptn2_organ=pointCloud(orlocation);
ptn2_organ.Color=orcolor;
figure
subplot(1,2,1)
pcshow(ptn2_organ);%24258
subplot(1,2,2)
pcshow(ptn2_Instr);%14509

Organ=[ptn1_organ.Location;ptn2_organ.Location;pt_n3.Location];
pt_Organ=pointCloud(Organ);
pt_Organ.Color=[ptn1_organ.Color;ptn2_organ.Color;pt_n3.Color];
pcshow(pt_Organ); %107774

Instr=[ptn1_Instr.Location;ptn2_Instr.Location];
pt_Instr=pointCloud(Instr);
pt_Instr.Color=[ptn1_Instr.Color;ptn2_Instr.Color];
pcshow(pt_Instr) %15426
pcshowpair(pt_Organ,pt_Instr);

[labels, numClusters] = pcsegdist(pt_Instr, 0.06);
pcshow(pt_Instr.Location,labels)
colormap(hsv(numClusters))
t_labels=tabulate(labels);
[t1,t2]=sort(t_labels(:,2),'descend'); % t2 is label, t1 is number
index_instr1=find((labels==t2(1,1))|(labels==t2(2,1)));
ptinstrument=pt_Instr.Location;
ptinstrument(index_instr1,:)=[];
ctinstrument=pt_Instr.Color;
ctinstrument(index_instr1,:)=[];
pt_Instr01=pointCloud(pt_Instr.Location(index_instr1,:));
pt_Instr01.Color=pt_Instr.Color(index_instr1,:);
pcshow(pt_Instr01);%14853

pt_Organ01=pointCloud([ptinstrument;pt_Organ.Location]);
pt_Organ01.Color=[ctinstrument;pt_Organ.Color];
pcshow(pt_Organ01);%108347





%% fine_partion
%      [X2L] = Assigining_labels02(double(pt_Instr.Location),1,0.015); 
%  load('C:\Users\zy080\Documents\MATLAB\Medicaldata\data_outline\bids_x2.mat');
% load('bids.mat');
[bids_X2_, E_X2_, Ne_X2_] = find_delaunay_boundary03_fig1(double(pt_Instr01.Location),0.01);
[Bid1,Bid2,Bid1_] = bound_(bids_X2_);
[Instr_index_re_,p0_Instr] = bound_2(pt_Instr01,Bid1_);
Bidd0=unique([Instr_index_re_;cell2mat(Bid1_')]);%96
pti_lo=pt_Instr01.Location;
cti_lo=pt_Instr01.Color;
pti_lo(Bidd0,:)=[];
cti_lo(Bidd0,:)=[];
PT_instr=pointCloud(pti_lo);
PT_instr.Color=cti_lo;
 pcshow(PT_instr) %18000 %18367 %14848
 flag=1;
  %%
  % PT_Organ; PT_instr
  Pti_Lo = PT_instr;
while flag
        if length(bids_X2_)~=2
            flag=1;
        [Pti_Lo,bids_X2_,Bid3,Bid4] = partition_repeat(Pti_Lo,0.004);
        else
            flag=0;
        end
end
pppti1=Pti_Lo.Location(Bid3,:);
pppti2=Pti_Lo.Location(Bid4,:);
[Instr_n] = bound_3(pppti1,pppti2,Pti_Lo.Location);
P_instr=pointCloud(Pti_Lo.Location(Instr_n,:));
P_instr.Color=Pti_Lo.Color(Instr_n,:);
pcshow(P_instr); %14724

[~,index_instr]=ismember(P_instr.Location,pt_Instr01.Location,'rows');
ptt=pt_Instr01.Location;
ptt(index_instr,:)=[];
ctt=pt_Instr01.Color;
ctt(index_instr,:)=[];
Organ=[pt_Organ01.Location;ptt];
pt_Organ=pointCloud(Organ);
pt_Organ.Color=[pt_Organ01.Color;ctt];
pcshow(pt_Organ);%108476

%% Organ
   PT_O=pt_Organ.Location;
    x_O=PT_O(:,1);
    xm_O=mean(x_O);
    index_O1=find(x_O>xm_O);
    index_O2=find(x_O<=xm_O);
    pt_O1=pt_Organ.Location(index_O1,:);
    ct_O1=pt_Organ.Color(index_O1,:);
    pt_O2=pt_Organ.Location(index_O2,:);
    ct_O2=pt_Organ.Color(index_O2,:);
    figure;
    subplot(1,2,1)
    pcshow(pointCloud(pt_O1))
    subplot(1,2,2)
    pcshow(pointCloud(pt_O2))
    pt_O1_y=pt_O1(:,2);
    GMModel_O1= fitgmdist(pt_O1_y,2);
    MmO1=GMModel_O1.mu;
%     index_O1_y=find(((min(MmO1)+sqrt(GMModel_O1.Sigma(:,:,1)))<=pt_O1_y)&(pt_O1_y<=(max(MmO1)+sqrt(GMModel_O1.Sigma(:,:,2)))));
    index_O1_y=find((min(MmO1)<=pt_O1_y)&(pt_O1_y<=(max(MmO1)+sqrt(GMModel_O1.Sigma(:,:,2)))));
    pt_O1_y1=pt_O1(index_O1_y,:);
    ct_O1_y1=ct_O1(index_O1_y,:);
    PT_O1_Y1=pointCloud(pt_O1_y1);
    PT_O1_Y1.Color=ct_O1_y1;
    figure;
  pcshow(PT_O1_Y1);%32389
  pt_O1_y1_=PT_O1_Y1.Location(:,1);
  GMModel_O1= fitgmdist(pt_O1_y1_,2);
  MmO1=GMModel_O1.mu;
  index_O1_y=find(((min(MmO1)+sqrt(GMModel_O1.Sigma(:,:,1)))<=pt_O1_y1_)&(pt_O1_y1_<=(max(MmO1)+sqrt(GMModel_O1.Sigma(:,:,2)))));
  pt_O1_y1_2=PT_O1_Y1.Location(index_O1_y,:);
  ct_O1_y1_2=PT_O1_Y1.Color(index_O1_y,:);
  PT_O1_Y1_=pointCloud(pt_O1_y1_2);
  PT_O1_Y1_.Color=ct_O1_y1_2;
   figure;
  pcshow(PT_O1_Y1_);%13193
  index_O2_y=find(pt_O1_y1_>=(max(MmO1)+sqrt(GMModel_O1.Sigma(:,:,2))));
  pt_O1_y1_3=PT_O1_Y1.Location(index_O2_y,:);
  ct_O1_y1_3=PT_O1_Y1.Color(index_O2_y,:);
  PT_O1_Y2_=pointCloud(pt_O1_y1_3);
  PT_O1_Y2_.Color=ct_O1_y1_3;
  figure;
  pcshow(PT_O1_Y2_);
  index_O3_y=find(pt_O1_y1_<=(min(MmO1)+sqrt(GMModel_O1.Sigma(:,:,1))));
  pt_O1_y1_4=PT_O1_Y1.Location(index_O3_y,:);
  ct_O1_y1_4=PT_O1_Y1.Color(index_O3_y,:);
  PT_O1_Y3_=pointCloud(pt_O1_y1_4);
  PT_O1_Y3_.Color=ct_O1_y1_4;
  figure;
  pcshow(PT_O1_Y3_);
  
   figure;
   pcshow(PT_O1_Y1_);
   hold on
   pcshow(PT_O1_Y2_);
   hold on
   pcshow(PT_O1_Y3_);
 
    pt_O2_y=pt_O2(:,2);
    GMModel_O2= fitgmdist(pt_O2_y,2);
    MmO2=GMModel_O2.mu;
    index_O2_y=find(((min(MmO2)+sqrt(GMModel_O2.Sigma(:,:,2)))<=pt_O2_y)&(pt_O2_y<=(max(MmO2)-sqrt(GMModel_O2.Sigma(:,:,1)))));
    pt_O2_y1=pt_O2(index_O2_y,:);
    ct_O2_y1=ct_O2(index_O2_y,:);
    PT_O2_Y1=pointCloud(pt_O2_y1);
    PT_O2_Y1.Color=ct_O2_y1;
    figure;
 pcshow(PT_O2_Y1); %10457
%% PT_O1_Y1_
    [pt_o1_y1_,Bid,OU1] = partition_repeat02(PT_O1_Y1_,0.004); 
    [PT_O1_Y2,Outliers1,F_matrix3] =Bound_PTO1Y1(pt_o1_y1_,Bid);%60 200 0 0
%     figure;
%     pcshowpair(PT_O1_Y1_,pointCloud([OU1;Outliers1]));
     [pt_o1_y2,Bid_,OU1_] = partition_repeat02(PT_O1_Y2,0.004); 
     [PT_O1_Y3,Outliers1_,F_matrix1_,p0] = Bound_PTO1Y2(pt_o1_y2,Bid_); %150;374;1;1
     figure;
     pcshowpair(PT_O1_Y2,pointCloud([Outliers1_;p0;OU1_]));
  %% PT_O1_Y2_    
    [pt_o1_y2_,Bid2,OU2] = partition_repeat02(PT_O1_Y2_,0.004); 
    [PT_O1_Y4,Outliers2,F_matrix4] =Bound_PTO1Y1(pt_o1_y2_,Bid2);% 1 60 1 1
%     figure;
%     pcshowpair(PT_O1_Y2_,pointCloud([OU2;Outliers2]));
%     figure
%     pcshowpair(PT_O1_Y4,pointCloud([OU2;Outliers2]));
    [pt_o1_y4_,Bid2_,OU2_] = partition_repeat02(PT_O1_Y4,0.004); 
    [PT_O1_Y5,Outliers2_,F_matrix2_,p02] = Bound_PTO1Y2(pt_o1_y4_,Bid2_); %20,120,1,0
%     figure;
%     pcshowpair(PT_O1_Y4,pointCloud([Outliers2_;p02;OU2_]));
    
    %%   PT_O1_Y3_
     [pt_o1_y3_,Bid3,OU3] = partition_repeat02(PT_O1_Y3_,0.003); 
     pt_O1_y3=pt_o1_y3_.Location(:,1);
    GMModel_O3= fitgmdist(pt_O1_y3,2);
    MmO3=GMModel_O3.mu;
    index_O1_y=find((pt_O1_y3<=(max(MmO3)+sqrt(GMModel_O3.Sigma(:,:,2)))));
    pt_O1_y=pt_o1_y3_.Location(index_O1_y,:);
    ct_O1_y=pt_o1_y3_.Color(index_O1_y,:);
    PT_O1_Y31=pointCloud(pt_O1_y);
    PT_O1_Y31.Color=ct_O1_y;
         figure;
  pcshowpair(PT_O1_Y3_,PT_O1_Y31);
    index_O1_y3=find(pt_O1_y3>(max(MmO3)+sqrt(GMModel_O3.Sigma(:,:,2))));
    pt_O1_y32=pt_o1_y3_.Location(index_O1_y3,:);
    ct_O1_y32=pt_o1_y3_.Color(index_O1_y3,:);
    PT_O1_Y32=pointCloud(pt_O1_y32);
    PT_O1_Y32.Color=ct_O1_y32;
  figure;
  pcshowpair(pt_o1_y3_,PT_O1_Y32);
  [ptCloud132,inlierIndices,outlierIndices] = pcdenoise(PT_O1_Y32); 
  [labels, numClusters] = pcsegdist(ptCloud132, 0.03);
  pcshow(ptCloud132.Location,labels)
  colormap(hsv(numClusters))
  t_labels=tabulate(labels);
  [t1,t2]=sort(t_labels(:,2),'descend'); % t2 is label, t1 is number
  Outlier_index=find((labels~=t2(1))&(labels~=t2(2))&(labels~=t2(3))&(labels~=t2(4)));
  Outlier132=pointCloud(ptCloud132.Location(Outlier_index,:));
  Outlier132.Color=ptCloud132.Color(Outlier_index,:);
  Outlier132_=pointCloud(PT_O1_Y32.Location(outlierIndices',:));
  Outlier132_.Color=PT_O1_Y32.Color(outlierIndices',:);
  Outliers3=[Outlier132.Location;Outlier132_.Location];
  
     O_f01=[OU1;Outliers1;OU1_;Outliers1_;p0;OU2;Outliers2;OU2_;Outliers2_;p02;OU3;Outliers3];
    figure;
    pcshowpair(pointCloud(O_f01),PT_O1_Y1);  
%     pcshow(pointCloud(O_f01));
  
  
  
  
  
%     figure;pcshowpair(PT_O1_Y32,ptCloud132);
%     [PT_O1_Y5,Outliers3,F_matrix5] =Bound_PTO1Y1(pt_o1_y3_,Bid3);
%     figure;
%     pcshowpair(PT_O1_Y3_,pointCloud(OU3));
%%  most complex part
%      [pt_o1_y3,Bid_2,OU1_2] = partition_repeat02(PT_O1_Y3,0.004); 
%      [Outliers1_2,F_matrix1_2] =Bound_PTO1Y3(pt_o1_y3,Bid_2);
%      figure;
%      pcshowpair(pt_o1_y3,pointCloud(Outliers1_2));
%     O_f01=[OU1;Outliers1;OU1_;Outliers1_;p0;OU1_2;Outliers1_2];
%     figure;
%     pcshowpair(pointCloud(O_f01),PT_O1_Y1);     
    
     
%% PT_O2_Y1
% GMM rough partition
[pt_o2_y1,Bid2,OU2] = partition_repeat02(PT_O2_Y1,0.005); 
pt1_InstrLocation=pt_o2_y1.Location;
pt_O2_y=pt1_InstrLocation(:,2);
GMModel_O1= fitgmdist(pt1_InstrLocation(:,2),2);
 MmO1=GMModel_O1.mu;
index_O1_y=find(((min(MmO1))<=pt_O2_y)&(pt_O2_y<=(max(MmO1)-sqrt(GMModel_O1.Sigma(:,:,1)))));
 pt_O2_y1=pointCloud(pt1_InstrLocation(index_O1_y,:));
 pt_O2_y1.Color=pt_o2_y1.Color(index_O1_y,:);
 figure
 subplot(1,2,1)
 pcshowpair(pt_O2_y1,pointCloud(pt1_InstrLocation));
 subplot(1,2,2)
 pcshow(pt_O2_y1);

 %% fine partition (breakthrough)
[pt_O2_y1_,Bid2_,OU2_] = partition_repeat02(pt_O2_y1,0.003); 

figure
pcshowpair(pt_O2_y1_,pointCloud(OU2_));
[F_matrix2,Outliers2] = Bound_PTO2Y1(pt_O2_y1_,Bid2_);%450 465 0 0
pt11=pt1_InstrLocation;
pt11(index_O1_y,:)=[];
pt_O2_y2=pointCloud(pt11);
figure
pcshow(pt11);
[labels, numClusters] = pcsegdist(pt_O2_y2, 0.03);
pcshow(pt11,labels)
colormap(hsv(numClusters))
t=tabulate(labels);
[t1,t2]=sort(t(:,2),'descend'); % t2 is label, t1 is number
outlierst_index=find((labels~=t2(1))&(labels~=t2(2)));
outlierst=pt11(outlierst_index,:);
F_matrix3 =pt11;
F_matrix3(outlierst_index,:)=[];

Of_02=[OU2;OU2_;Outliers2;outlierst];
pcshowpair(pointCloud(Of_02),PT_O2_Y1);  

Organ_outliers=[Of_02;O_f01];
%%
figure;
pcshowpair(pointCloud(Organ_outliers),pt_Organ);
[~,index_Oo]=ismember(Organ_outliers,pt_Organ.Location,'rows');
pt_Instr=[P_instr.Location;pt_Organ.Location(index_Oo,:)];
pt_Instrc=[P_instr.Color;pt_Organ.Color(index_Oo,:)];
Ptcloud_instr =pointCloud(pt_Instr);
Ptcloud_instr.Color=pt_Instrc;

pt_Organf0=pt_Organ.Location;
pt_Organc0=pt_Organ.Color;
pt_Organf0(index_Oo,:)=[];
pt_Organc0(index_Oo,:)=[];

Ptcloud_organ=pointCloud(pt_Organf0);
Ptcloud_organ.Color=pt_Organc0;
pcshow(Ptcloud_organ);
% pcshow(pt_Organc0);
pt_Organc01=single(pt_Organc0)/255;
[rn2,rn3,rn4,R01] = Colorf(pt_Organc01);
index1=find((rn4<0.05)&(round(pt_Organc01(:,1))==0));
hold on
pcshow(Ptcloud_organ.Location(index1,:))
pt_Instr=[pt_Instr;Ptcloud_organ.Location(index1,:)];
pt_Instrc=[pt_Instrc;Ptcloud_organ.Color(index1,:)];
Ptcloud_instr =pointCloud(pt_Instr);
Ptcloud_instr.Color=pt_Instrc;

ptorgan=Ptcloud_organ.Location;
ptorgan(index1,:)=[];
ctorgan=Ptcloud_organ.Color;
ctorgan(index1,:)=[];

pt_Instr=[pt_Instr;Ptcloud_organ.Location(index1,:)];
pt_Instrc=[pt_Instrc;Ptcloud_organ.Color(index1,:)];
Ptcloud_instr =pointCloud(pt_Instr);
Ptcloud_instr.Color=pt_Instrc;

Ptcloud_organ=pointCloud(ptorgan);
Ptcloud_organ.Color=ctorgan;

figure
subplot(1,2,1)
pcshow(Ptcloud_organ);
subplot(1,2,2)
pcshow(Ptcloud_instr);

% ptCloudOut = pcdenoise(Ptcloud_instr);
[ptCloud132,inlierIndices,outlierIndices] = pcdenoise(Ptcloud_instr);
ptCloudOrgan=pointCloud([Ptcloud_instr.Location(outlierIndices,:);Ptcloud_organ.Location]);
ptCloudOrgan.Color=[Ptcloud_instr.Color(outlierIndices,:);Ptcloud_organ.Color];
figure
subplot(1,3,1)
pcshow(ptCloudOrgan);
subplot(1,3,2)
pcshow(ptCloud132);
subplot(1,3,3)
pcshow(ptCloud);

Outliersf=[outlier10;outliers20;outliers30];
pcshowpair(ptCloud132,pointCloud(Outliersf))
ptcloudinstru=ptCloud132.Location;
ctcloudinstru=ptCloud132.Color;
[~,index08]=ismember(Outliersf,ptcloudinstru,'rows');
ptcloudinstru(index08,:)=[];
ct=ctcloudinstru(index08,:);
ctcloudinstru(index08,:)=[];
ptCloud_instru=pointCloud(ptcloudinstru);
ptCloud_instru.Color=ctcloudinstru;
 pcshow(ptCloud_instru);
 
 ptCloud_organ=pointCloud([Outliersf;ptCloudOrgan.Location]);
 ptCloud_organ.Color=[ptCloudOrgan.Color;ct];
pcshow(ptCloud_organ);
figure
subplot(1,2,1)
pcshow(ptCloud_organ);
subplot(1,2,2)
pcshow(ptCloud_instru);