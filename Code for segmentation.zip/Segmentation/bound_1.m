function [Instr_n] = bound_1(pt_Instr,Bid1,Bid2)
pt1_InstrLocation=pt_Instr.Location;
  PT1=pt1_InstrLocation(Bid1,:);
  PT2=pt1_InstrLocation(Bid2,:);
  [pt1_xyz] =Ffeature(PT1);
 Instr1_index= find((pt1_xyz.xm<=pt1_InstrLocation(:,1))&(pt1_InstrLocation(:,1)<=pt1_xyz.xM)&(pt1_xyz.ym<=pt1_InstrLocation(:,2))&(pt1_InstrLocation(:,2)<pt1_xyz.yM)&(pt1_xyz.zm<=pt1_InstrLocation(:,3))&(pt1_InstrLocation(:,3)<=pt1_xyz.zM));
  [pt2_xyz] =Ffeature(PT2);
  Instr2_index= find((pt2_xyz.xm<=pt1_InstrLocation(:,1))&(pt1_InstrLocation(:,1)<=pt2_xyz.xM)&(pt2_xyz.ym<=pt1_InstrLocation(:,2))&(pt1_InstrLocation(:,2)<pt2_xyz.yM)&(pt2_xyz.zm<=pt1_InstrLocation(:,3))&(pt1_InstrLocation(:,3)<=pt2_xyz.zM));
  Instr_n=[Instr1_index;Instr2_index];
end

