function [pt_o1_y1,Bid,OU,bids_X] = partition_repeat02(PT_O1_Y1_2,s)
        PT_O1=PT_O1_Y1_2;%7349
%         s=0.004;
        OU=[];
        flag=1;
        while(flag)
                [pt_o1_y1,Outlier0,Bid3,Bid4,bids_X] = Repeat_P2(PT_O1_Y1_2,s);%8804
                OU=[OU;Outlier0];%191
                if (length(bids_X)~=2)&&(length(bids_X)~=1)
                    flag=1;
                    PT_O1_Y1_2=pt_o1_y1;
                else
                    flag=0;
                end
        end
       
        if length(Bid3)<=length(Bid4)
            Bid={Bid3};
        else
            Bid={Bid4};
        end
end

