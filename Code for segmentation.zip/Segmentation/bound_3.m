function [Instr_n] = bound_3(A1,A2,pt1_InstrLocation)
%   PT1=pt1_InstrLocation(Bid1,:);
%   PT2=pt1_InstrLocation(Bid2,:); 
%[Instr_n_O1_Y1] = bound_3(��,pppti2_O1_Y1,PT_O1_Y1.Location)
  [pt1_xyz] =Ffeature(A1);
 Instr1_index= find((pt1_xyz.xm<=pt1_InstrLocation(:,1))&(pt1_InstrLocation(:,1)<=pt1_xyz.xM)&(pt1_xyz.ym<=pt1_InstrLocation(:,2))&(pt1_InstrLocation(:,2)<pt1_xyz.yM)&(pt1_xyz.zm<=pt1_InstrLocation(:,3))&(pt1_InstrLocation(:,3)<=pt1_xyz.zM));
  [pt2_xyz] =Ffeature(A2);
  Instr2_index= find((pt2_xyz.xm<=pt1_InstrLocation(:,1))&(pt1_InstrLocation(:,1)<=pt2_xyz.xM)&(pt2_xyz.ym<=pt1_InstrLocation(:,2))&(pt1_InstrLocation(:,2)<pt2_xyz.yM)&(pt2_xyz.zm<=pt1_InstrLocation(:,3))&(pt1_InstrLocation(:,3)<=pt2_xyz.zM));
  Instr_n=unique([Instr1_index;Instr2_index]);
end