function [pt011,pt012,pt013,pt014,flag01,flag02,flag03,flag04] = Color_Split(pt01,Sm,Number)
%Color
    Color_OP1=pt01.Color;
    Location_OP1=pt01.Location;
    [U_Color_OP1,I,J]=unique(Color_OP1,'rows'); %60555 = > 31109
    SC=single(U_Color_OP1);
    [dpmmC_p1,XRC_p1] = Partition_single(SC,Sm,Number);
    for i=1:length(XRC_p1)
        [~,indxC_p1{i,1}]=ismember(XRC_p1{i,1},SC,'rows'); % non-repeat
        LC_p1(i,1)=length(indxC_p1{i,1});
    end
    for j=1:length(LC_p1)
        for k=1:LC_p1(j,1)
           IJC_p1_{j,1}{k,1} =find(indxC_p1{j,1}(k,1)==J(:,1));
        end
    IJC_p1{j,1}=cell2mat(IJC_p1_{j,1}); % repeat
    end
    if length(LC_p1)==2
        Location_OP11=Location_OP1(IJC_p1{1,1},:); %32784
        pt011=pointCloud(Location_OP11);
        pt011.Color=Color_OP1(IJC_p1{1,1},:);
        Color_OP11=pt011.Color;
        Location_OP12=Location_OP1(IJC_p1{2,1},:); %27771
        pt012=pointCloud(Location_OP12);
        pt012.Color=Color_OP1(IJC_p1{2,1},:);
        Color_OP12=pt012.Color;
        figure
        subplot(1,2,1);
        pcshow(pt011);
        subplot(1,2,2);
        pcshow(pt012);
        pt013=[];
        pt014=[];
         [flag01] = Criterial_split(pt011);
         [flag02] = Criterial_split(pt012);
         flag03=100;
         flag04=100;
    end
    if length(LC_p1)==3
            Location_OP11=Location_OP1(IJC_p1{1,1},:); %32784
            pt011=pointCloud(Location_OP11);
            pt011.Color=Color_OP1(IJC_p1{1,1},:);
            Color_OP11=pt011.Color;
            Location_OP12=Location_OP1(IJC_p1{2,1},:); %27771
            pt012=pointCloud(Location_OP12);
            pt012.Color=Color_OP1(IJC_p1{2,1},:);
            Color_OP12=pt012.Color;
            Location_OP13=Location_OP1(IJC_p1{3,1},:); %27771
            pt013=pointCloud(Location_OP13);
            pt013.Color=Color_OP1(IJC_p1{3,1},:);
            Color_OP13=pt013.Color;
             pt014=[];
            figure
            subplot(1,3,1);
            pcshow(pt011);
            subplot(1,3,2);
            pcshow(pt012);
            subplot(1,3,3);
            pcshow(pt013);
            [flag01] = Criterial_split(pt011);
            [flag02] = Criterial_split(pt012);
            [flag03] = Criterial_split(pt013);
            flag04=100;
    end
    if length(LC_p1)==4
            Location_OP11=Location_OP1(IJC_p1{1,1},:); %32784
            pt011=pointCloud(Location_OP11);
            pt011.Color=Color_OP1(IJC_p1{1,1},:);
            Color_OP11=pt011.Color;
            Location_OP12=Location_OP1(IJC_p1{2,1},:); %27771
            pt012=pointCloud(Location_OP12);
            pt012.Color=Color_OP1(IJC_p1{2,1},:);
            Color_OP12=pt012.Color;
            Location_OP13=Location_OP1(IJC_p1{3,1},:); %27771
            pt013=pointCloud(Location_OP13);
            pt013.Color=Color_OP1(IJC_p1{3,1},:);
            Color_OP13=pt013.Color;
            Location_OP14=Location_OP1(IJC_p1{4,1},:); %27771
            pt014=pointCloud(Location_OP14);
            pt014.Color=Color_OP1(IJC_p1{4,1},:);
            Color_OP14=pt014.Color;
            figure
            subplot(1,4,1);
            pcshow(pt011);
            subplot(1,4,2);
            pcshow(pt012);
            subplot(1,4,3);
            pcshow(pt013);
            subplot(1,4,4);
            pcshow(pt014);
            [flag01] = Criterial_split(pt011);
            [flag02] = Criterial_split(pt012);
            [flag03] = Criterial_split(pt013);
            [flag04] = Criterial_split(pt014);
    end
end

