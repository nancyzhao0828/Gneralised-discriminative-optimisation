function [X2__,index_,index1_] = label_criterial02(X2)
    [bids_X2_, E_X2_, Ne_X2_] = find_delaunay_boundary03_fig1(double(X2(:,1:3)),0.01);
    l2=length(bids_X2_);
    X2L_ =X2;  
    kl=size(X2L_,2)+1;
     for i=1:l2
          X2L_(bids_X2_{1,i},kl)=i;
     end
     index1=find(X2L_(:,4)~=0);
     index2=find(X2L_(:,4)==0);
     X3L=X2L_(index1,1:4);
     X4L=X2L_(index2,1:4);
     X3L_=cell(1,l2);
     Range=cell(l2,1);
     for i=1:l2
     X3L_{1,i}=X3L(find(X3L(:,4)==i),:);
     Range{i,1}=[min(X3L_{1,i}(:,1)),min(X3L_{1,i}(:,2)),min(X3L_{1,i}(:,3));max(X3L_{1,i}(:,1)),max(X3L_{1,i}(:,2)),max(X3L_{1,i}(:,3))];
     end
     range=zeros(l2,3);
    for  k=1:l2
       range(k,:)= abs(Range{k,1}(2,:)-Range{k,1}(1,:));
    end
    for j=1:3
        [a,b(j,1)]=max(range(:,j));
    end
    Refer =mode(b);
    Range1=cell2mat(Range);
    for k=1:3
      if  (Range{1,1}(1,k)>Range{Refer,1}(1,k))&&(Range{1,1}(2,k)<Range{Refer,1}(2,k))
          Range1(:,k)=[];
          AP(:,k)=100;
      else
          % calculate the area
         AP(:,k)=(Range{1,1}(2,k)-Range{Refer,1}(1,k))/(Range{Refer,1}(2,k)-Range{1,1}(1,k));
      end
    end
   [ index_f,b_f] =min(AP);
   b_xmin=min(Range1(:,b_f)); 
   b_xmax=max(Range1(:,b_f)); 
   Mu_=zeros(l2,3);
   c1=find(X2L_(:,b_f)==b_xmin);
   Mu_(1,:)=X2(c1(1),1:3);
   c2=find(X2L_(:,b_f)==b_xmax);
   Mu_(2,:)=X2(c2(1),1:3);

    

        
    
    
    

%      for k=1:l2
%          for j=1:length(X4L)
%                    if  (Range{1,k}(1,1)<=X4L(j,1))&&(X4L(j,1)<=Range{1,k}(2,1))&&(Range{1,k}(1,2)<=X4L(j,2))&&(X4L(j,2)<=Range{1,k}(2,2))&&(Range{1,k}(1,3)<=X4L(j,3))&&(X4L(j,3)<=Range{1,k}(2,3))
%                        X4L(j,4)=k;
%                    end   
%         end
%      end
     
%      Mu_=zeros(length(bids_X2_),3);
%      for i=1:length(bids_X2_)
%          Mu_(i,:)=mean(X2_(bids_X2_{1,i},1:3));
%      end
     D1_=pdist2(X2(:,1:3),ones(length(X2),1)*Mu_(1,:));
     D2_=pdist2(X2(:,1:3),ones(length(X2),1)*Mu_(2,:));
     D_delta_=D1_(:,1)-D2_(:,1);
     index_=find(D_delta_(:,1)<0);
     index1_=find(D_delta_(:,1)>=0);
     % the criterial is invalid for the  near seprations
     X2__=X2(index_,1:3);
     X2__(:,4)=1;  % according to the D_delta, assigning the label
     X2__(:,5)=X2L_(index_,end);  % original label 
end

