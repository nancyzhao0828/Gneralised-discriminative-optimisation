function [F_matrix,Outliers1] = Bound_PTO2Y1(pt_O2_y1_,Bid2_)
pt112_InstrLocation=pt_O2_y1_.Location;
pm=pt112_InstrLocation;
for i=1:length(Bid2_)
     PT112=pt112_InstrLocation(Bid2_{1,i},:);  % boundary data
end
% pcshow(PT112)
[ normals, curvature] = findPointNormals(PT112, 4);
contour(normals);
disp('Please select the key boundary !');
    prompt = 'The beta will be %d: ';
    beta= input(prompt);
    if beta==1
    disp('Please select the key points for normals !');
    prompt = 'The key point will be %d: ';
    ra = input(prompt);    
    pt2=PT112(1:ra,:);% contour normals
    elseif beta==0
    disp('Please select the key points for normals !');
    prompt = 'The key point will be %d: ';
    ra = input(prompt);    
    pt2=PT112(ra:end,:);  
    else
    disp('Please select the key points for normals !');
    prompt = 'The ra will be %d: ';
    ra = input(prompt);
    prompt = 'The rb will be %d: ';
    rb = input(prompt);
    pt2=PT112(ra:rb,:);
    end
    figure
pcshowpair(pointCloud(pt2),pt_O2_y1_);  
figure
    [a01,a02]=max(pt2(:,1));
    [b01,b02]=min(pt2(:,1));
    plot(pm(:,1),pm(:,2),'b.');
    hold on
    plot(pt2(:,1),pt2(:,2),'r.');
    hold on
    plot(pt2(a02,1),pt2(a02,2),'yo');
    hold on
    plot(pt2(b02,1),pt2(b02,2),'ys');
    disp('Please select the way of fitting !');
    prompt = 'The note1 value will be %d: ';
    note1= input(prompt);
    if note1==1
    fitobject = fit(pt2(:,1),pt2(:,2),'poly1');
    p1=fitobject.p1;
    p2=fitobject.p2;
    else
    p1=(pt2(b02,2)-pt2(a02,2))/(pt2(b02,1)-pt2(a02,1));
    p2= pt2(a02,2)-p1*pt2(a02,1);
    end        
A_matrix=zeros(length(pm),6); 
A_matrix(:,1:3)=pm;
[~,index2]= ismember(pt2,pm,'rows');
A_matrix(index2,4)=1;
A_matrix(:,5)=p1*A_matrix(:,1)+p2;
hold on
plot(A_matrix(:,1),A_matrix(:,5),'yo');
disp('Please select the range of non-outliers !');
prompt = 'The note2 value will be %d: ';
note2= input(prompt);
if note2==1
       rr=1;
else
       rr=-1;
end
A_matrix(:,6)=rr*sign(A_matrix(:,2)-A_matrix(:,5));
index=find(A_matrix(:,6)==-1);
hold on
plot(A_matrix(index,1),A_matrix(index,2),'y+');
F_matrix=unique([A_matrix(index,1:3);pt2],'rows'); %1431
[~, index1]=ismember(F_matrix,pm,'rows');
Outliers1=pm;
Outliers1(index1,:)=[]; %24
figure;
pcshowpair(pointCloud(Outliers1),pointCloud(pm));
end

