function [re,p03] = p0_refine01(p03)
    pm=mean(p03);

for i=1:length(p03)
    d(i,1)=sum((p03(i,:)-pm).^2,2);
end

[a0,b0]=min(d);
[a1,b1]=max(d);
D=d;
D([b0;b1],:)=[];
Dm=mean(D);
d3=find(d>10*Dm);
p1=p03;
p03(d3,:)=[];
re=p1(d3,:);
end

