function [pt01,pt02,pt03,indxP] = Position_Split(Location_O,Color_O,Sm,Number)
%Position
    [dpmmP,XRP] = Partition_single(Location_O,Sm,Number);
    for i=1:length(XRP)
            [~,indxP{i,1}]=ismember(XRP{i,1},Location_O,'rows'); % repeat
            LP(i,1)=length(indxP{i,1});
    end
    if length(XRP)==2
            Location_OP1=Location_O(indxP{1,1},:);
            pt01=pointCloud(Location_OP1);
            Color_OP1=Color_O(indxP{1,1},:); %60555
            pt01.Color=Color_OP1;
            Location_OP2=Location_O(indxP{2,1},:);
            Color_OP2=Color_O(indxP{2,1},:); %62645
            pt02=pointCloud(Location_OP2);
            pt02.Color=Color_OP2;
            figure
            subplot(1,2,1)
            pcshow(pt01);
            subplot(1,2,2)
            pcshow(pt02);
            figure
            pcshowpair(pt01,pt02);
            pt03=[];
%              [a01] = Criterial_split(pt01);
%              [a02] = Criterial_split(pt02);
%              a03=0;
    elseif length(XRP)==3
            Location_OP1=Location_O(indxP{1,1},:);
            pt01=pointCloud(Location_OP1);
            Color_OP1=Color_O(indxP{1,1},:); %60555
            pt01.Color=Color_OP1;
            Location_OP2=Location_O(indxP{2,1},:);
            Color_OP2=Color_O(indxP{2,1},:); %62645
            pt02=pointCloud(Location_OP2);
            pt02.Color=Color_OP2;
            Location_OP3=Location_O(indxP{3,1},:);
            Color_OP3=Color_O(indxP{3,1},:); %62645
            pt03=pointCloud(Location_OP3);
            pt03.Color=Color_OP3;
            figure
            subplot(1,3,1)
            pcshow(pt01);
            subplot(1,3,2)
            pcshow(pt02);
            subplot(1,3,3)
            pcshow(pt03);
             figure
            pcshow(pt01);
            hold on
            pcshow(pt02);
            hold on
            pcshow(pt03);
%              [a01] = Criterial_split(pt01);
%              [a02] = Criterial_split(pt02);
%              [a03] = Criterial_split(pt03);
    else
           Location_OP1=Location_O(indxP{1,1},:);
            pt01=pointCloud(Location_OP1);
            Color_OP1=Color_O(indxP{1,1},:); %60555
            pt01.Color=Color_OP1;
            Location_OP2=Location_O(indxP{2,1},:);
            Color_OP2=Color_O(indxP{2,1},:); %62645
            pt02=pointCloud(Location_OP2);
            pt02.Color=Color_OP2;
            Location_OP3=Location_O(indxP{3,1},:);
            Color_OP3=Color_O(indxP{3,1},:); %62645
            pt03=pointCloud(Location_OP3);
            pt03.Color=Color_OP3;
            Location_OP4=Location_O(indxP{4,1},:);
            Color_OP4=Color_O(indxP{4,1},:); %62645
            pt04=pointCloud(Location_OP4);
            pt04.Color=Color_OP4;
            figure
            subplot(1,4,1)
            pcshow(pt01);
            subplot(1,4,2)
            pcshow(pt02);
            subplot(1,4,3)
            pcshow(pt03);
            subplot(1,4,4)
            pcshow(pt04);
             figure
            pcshow(pt01);
            hold on
            pcshow(pt02);
            hold on
            pcshow(pt03);
            hold on
            pcshow(pt04);
%              [a01] = Criterial_split(pt01);
%              [a02] = Criterial_split(pt02);
%              [a03] = Criterial_split(pt03);
%              [a04] = Criterial_split(pt04);
    end

end

