function [Instr_index_re,p0] = bound_2(pt_Instr,Bid_)
pt1_InstrLocation=pt_Instr.Location;
Instr_index_re=[];
for i=1:length(Bid_)
     PT1=pt1_InstrLocation(Bid_{1,i},:);
     [pt1_xyz] =Ffeature(PT1);
     Instr1_index= find((pt1_xyz.xm<=pt1_InstrLocation(:,1))&(pt1_InstrLocation(:,1)<=pt1_xyz.xM)&(pt1_xyz.ym<=pt1_InstrLocation(:,2))&(pt1_InstrLocation(:,2)<pt1_xyz.yM));
     Instr_index_re=[ Instr1_index;Instr_index_re];
end
p0=pt1_InstrLocation;
p0(Instr_index_re,:)=[];
end

