function [ Bid1,Bid2,A] = bound_(bids_X2_)
% select the longest boundary  Bid1  and the second longer boundary Bid2
% A is the left boundary points 
 for i=1:length(bids_X2_)
       D_instr(i,1)=length(bids_X2_{1,i});
 end
  [Di,Dj]=sort(D_instr);
  Bid1=[bids_X2_{1,Dj(end)}];
  if Di(end-1)>50
  Bid2=[bids_X2_{1,Dj(end-1)}];
  else
  Bid2=[];
  end
bids_X2_{1,Dj(end)}=[];
if Di(end-1)>50
bids_X2_{1,Dj(end-1)}=[];
end
  A=bids_X2_;
  A=A(~cellfun('isempty',A));
end

