function [X2__,index_,index1_] = label_criterial(X2_)
    [bids_X2_, E_X2_, Ne_X2_] = find_delaunay_boundary03_fig1(double(X2_(:,1:3)),0.015);
    l2=length(bids_X2_);
    X2L_ =X2_;
   
     for i=1:l2
          X2L_(bids_X2_{1,i},4)=i;
     end
     Mu_=zeros(length(bids_X2_),3);
     for i=1:length(bids_X2_)
         Mu_(i,:)=mean(X2_(bids_X2_{1,i},1:3));
     end
     D1_=pdist2(X2_(:,1:3),ones(length(X2_),1)*Mu_(1,:));
     D2_=pdist2(X2_(:,1:3),ones(length(X2_),1)*Mu_(2,:));
     D_delta_=D1_(:,1)-D2_(:,1);
     index_=find(D_delta_(:,1)<0);
     index1_=find(D_delta_(:,1)>=0);
     % the criterial is invalid for the  seprations
     X2__=X2_(index_,1:3);
     X2__(:,4)=1;  % according to the D_delta, assigning the label
     X2__(:,5)=X2L_(index_,end);  % original label 
end

