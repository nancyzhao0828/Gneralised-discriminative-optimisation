function [W] = label_criterial2(X2__,X2_,X2,W,index1_)
              if length (unique(X2__(:,5)))>2
                     String='need to be boundary again'; %X2(index,1:3);
                     disp(String);  
                     [ad1,as1]=ismember(X2_(index1_,1:3),X2,'rows');
                     as_eff1 =as1(:,1); 
                     W(as_eff1,2)=2;
             else
                   [ad,as]=ismember(X2__(:,1:3),X2,'rows');
                   as_eff =as(:,1);
                   W(as_eff,2)=1;
            %        X2_(index_,:)=[];
                   [ad1,as1]=ismember(X2_(index1_,1:3),X2,'rows');
                   as_eff1 =as1(:,1); 
                   W(as_eff1,2)=2;
              end
end

