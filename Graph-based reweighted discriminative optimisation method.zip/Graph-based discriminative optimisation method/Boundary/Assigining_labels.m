function [X2L] = Assigining_labels(X2,flag)
    % assinging labels based on partitions for target data
    X3=X2;
    X2L =X2;
    if flag==1
        [X2L] = label_criterial03(X2);
        else
         [X2_,index_,index1] = label_criterial02(X2);    
         if length (unique(X2_(:,5)))>2
            String='need to be boundary again'; %X2(index,1:3);
            disp(String);
            if unique(X2_(:,4))==1
            W(index1,2)=2; %body
            else
            W(index1,2)=1;   
            end
            [X2__,index_,index1_] = label_criterial(X2_);
            [W] = label_criterial2(X2__,X2_,X2,W,index1_);
         else
           [ad,as]=ismember(X2_(:,1:3),X3,'rows');
           as_eff =as(:,1);
           W(as_eff,2)=1;
           W(index1,2)=2;
         end
         X2L(:,4)=W(:,2);  
    end
end

