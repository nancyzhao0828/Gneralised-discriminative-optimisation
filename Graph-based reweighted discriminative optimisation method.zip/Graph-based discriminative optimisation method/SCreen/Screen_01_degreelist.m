% Get the segree list of car model
clc;clear;
cd 'E:\BaiduNetdiskDownload\Dataset\MOdelNet40_ply_dataset\ModelNet40_ply_downsampling_5120\car'
cd 'train'
path=pwd;       
file = dir(fullfile(path,'*.ply'));    
filenames = {file.name}';
filelength = size(filenames,1);
model_P = cell (1,filelength);
UW = cell(1,filelength);
TB = cell(1,filelength);
for idx = 1 : filelength               
    filedir = strcat(path, filenames(idx));
    ptcloud=pcread(filenames{idx});
    D1=ptcloud.Location; %N*3
    modelFull = D1';
    modelFull = bsxfun(@minus,modelFull,min(modelFull,[],2));
    modelFull = bsxfun(@minus,modelFull,max(modelFull,[],2)/2);
    modelFull = modelFull / max(abs(modelFull(:)));
    model_P{1,idx} = modelFull;
    [bids_X2_, E_X2_, Ne_X2_] = find_delaunay_boundary03_fig1(double(modelFull'),0.1);
    close;
    G1=graph(Ne_X2_+Ne_X2_');
    UW{1,idx}=degree(G1);
    TB{1,idx}=sortrows(tabulate(UW{1,idx}),2);
end
i=1;
l=i;
while (i~=length(TB)+1)
    if length(TB{1,i})<=9
        i=i+1;
        continue;  
    else
        TB_car{1,l}=TB{1,i};
        UW_car{1,l}=UW{1,i};
        TB_index_car(:,l)=TB{1,i}(end-9:end,1);
        model_P_Car{1,l}=model_P{1,i};
        l=i;
        i=i+1;
    end
end
index11=ismember(TB_index_car',zeros(10,6)','rows');
    k=find(1==index11);
    for j=1:length(k)
     model_P_Car{1,k(j)}=[];
     UW_car{1,k(j)}=[];
     TB_car{1,k(j)}=[];
    end
model_P_Car(cellfun(@isempty,model_P_Car))=[];
UW_car(cellfun(@isempty,UW_car))=[];
TB_car(cellfun(@isempty,TB_car))=[];
TB_index_car(:,index11)=[];
