function [C,B,Correction_matrix] = Screen_01(TB_index_airplane)
    TB_index1=TB_index_airplane;%626,375,112,242
    TB_index=TB_index1(4:end,:);
    Correction_matrix=zeros(length(TB_index),length(TB_index));
    for i=1:length(TB_index)
        for j=1:length(TB_index)
            Correction_matrix(i,j)=1-pdist2(TB_index(:,i)',TB_index(:,j)','hamming');% similarity
        end
    end
    B=Correction_matrix;
    B(boolean(eye(length(Correction_matrix))))=-100;
    C=cell(length(B),1);
    for i=1:length(C)
        C{i,1}=find(B(i,:)>0.8);
    end
end