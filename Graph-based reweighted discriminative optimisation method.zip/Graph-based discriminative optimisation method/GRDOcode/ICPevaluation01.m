function [iRSRDO,MSERDO,Runtime,Xgt,Xgts] = ICPevaluation01(Rtest1,Xtest0,iRSRDO,MSERDO,model_test)
%    maxIter = 1000;
%    stopThres = 0.001;
%    DM.Xmodel=single(DM.Xmodel);
    starttime_RDO = tic;
    [tform,movingReg] = pcregistericp(pointCloud(Xtest0'),pointCloud(model_test'));%moving,fixed
    Runtime  = toc(starttime_RDO);
%     T_matrix = (tform.T);
    T_matrix = invSim3(tform.T);
    if size(model_test,2)>3
%    Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*DM.Xmodel,Rtest1(1:3,4));% groundtruth
     Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*model_test,Rtest1(1:3,4));% groundtruth
     Xgts = bsxfun(@plus,T_matrix(1:3,1:3)*model_test,T_matrix(1:3,4));% groundtruth
   else
%    Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*DM.Xmodel',Rtest1(1:3,4));% groundtruth  
     Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*model_test',Rtest1(1:3,4));% groundtruth
     Xgts = bsxfun(@plus,T_matrix(1:3,1:3)*model_test',T_matrix(1:3,4));% groundtruth
    end
%     Xgts = invSim3(T_matrix)*[model_test;ones(length(model_test),1)'];
%     Xgts = Xgts(1:3,:);
    E_Tp=transMatToParam({T_matrix});
    G_Tp=transMatToParam({Rtest1});
    translation = E_Tp(4:6);
    translation_gt = G_Tp(4:6);
    rotation = E_Tp(1:3);
    rotation_gt = G_Tp(1:3);
    %% Rotation Error
    Re = sqrt(mean((rotation-rotation_gt).^2)); 
    %% Translation Error
    Te = sqrt(mean((translation-translation_gt).^2)); 
    %% Recall Rate
    Mse = immse(Xgt',Xgts');
%    if size(DM.Xmodel,2)>3
%    Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*DM.Xmodel,Rtest1(1:3,4));% groundtruth
%    else    
%    Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*DM.Xmodel',Rtest1(1:3,4));% groundtruth   
%    end
%    Xgts1 = Xstep{end}{1,1};
%    XgtsCHANG = XstepCHANG{end}{1,1};
   [irsRDO, mseRDO,judgement ] = isRegisterSuccessful( Xgt', Xgts');
   iRSRDO=[iRSRDO;irsRDO];
   MSERDO=[MSERDO;mseRDO];
end