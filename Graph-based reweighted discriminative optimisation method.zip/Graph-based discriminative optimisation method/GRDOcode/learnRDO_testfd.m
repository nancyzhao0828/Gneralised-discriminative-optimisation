function [DM,error,Y,R] = learnRDO_testfd(Xmodel,X,Y,nMap,sigmaSq,gridStep)
%  function [DM,error,Y,R,SD1,SDW1] = learnDOnewnewWUN(Xmodel,X,Y,nMap,sigmaSq,gridStep)
%LEARNDO Summary of this function goes here
%   Detailed explanation goes here

fprintf('Training DO with %d maps\n',nMap)
fprintf('#data: %d \n',length(X))

D1 = cell(1,nMap);
% D1 = cell(1,nMap);
error = inf(nMap,1);
% error1 = inf(nMap,1);
Xori = X;% data
Yori = Y;
Yorimat = reshape(cell2mat(Yori),[numel(Yori{1}) length(Yori)]);%numel: number of elements in an array
Ymat = Yorimat;
% sigmaSq = 0.3; 
[pcmptFeat,normals] = precomputeFeature(Xmodel,sigmaSq,gridStep);
% [ normals ] = findPointNormals(Xmodel',6,[0 0 0]);
Ygoal = transMatToParam(Yori);
Yinit = zeros(6,length(X));% the parameters are initialized to 0
Y = Yinit;

R=cell(nMap,1);
% It means the iterations;
fprintf('It: %d, err: %f\n',0,norm(Ygoal-Y,'fro').^2/length(X))
Ykm=0.1*eye(6);
ykm=zeros(6);
lameda=1e-4;
% Y1=zeros(6);
% flag=1;
% itMap = 1;
% rotMat0 = paramToTransMatnew(Y);
% rotMat_g = paramToTransMatnew(Ygoal);
% for i=1:length(rotMat0)
% %     X0= rotMat0{i,1}(1:3,1:3)*Xmodel+rotMat0{i,1}(1:3,4)'*Xmodel;
%     X0_1= rotMat0{i,1}(1:3,1:3)*Xmodel;
%     X0_2= rotMat0{i,1}(1:3,4)'*Xmodel;
% %     Xg = rotMat_g{i,1}(1:3,1:3)*Xmodel+rotMat_g{i,1}(1:3,4)'*Xmodel;
%     Xg_1= rotMat_g{i,1}(1:3,1:3)*Xmodel;
%     Xg_2= rotMat_g{i,1}(1:3,4)'*Xmodel;
%     MSE_Rotation0(i,1)=immse(X0_1,Xg_1);
%     MSE_Translation0(i,1)=immse(X0_2,Xg_2);
% end
%  figure(1)
%  pcshowpair(pointCloud(X0'),pointCloud(Xg'));
%  figure(2)
%  Planedraw(rotMat_g);
%while(flag)
for itMap = 1:nMap
        for k=1:length(X)
            YY1=Ygoal(:,k);% groundtruth
            YY2=Y(:,k); % estimated
            rotMat22 = paramToTransMatnew(YY2);%%%%%%%%%%%%%%
            XX2=transCellnew(rotMat22,Xmodel,0);
            for j=1:6
               ykm(:,j)=YY1(:,1)-Ykm(:,j);%%%%%%%%%%%%%%%%%%
               rotMatkm = paramToTransMatnew(ykm(:,j));
               Xkm = transCellnew(rotMatkm,Xmodel,0);
               MSEkm2(k,j)=immseNAN(XX2',Xkm');%(6N)
            end
        end
         N = normalize(MSEkm2,2);
        for i=1:6
            [mu(i,1),sigma(i,1)]=normfit(N(:,i));
        end
        Mu=min(mu);
        Index=find(mu==Mu);
        for p=1:6
            Yy(p,1)=normpdf(mu(p,1),mu(Index,1),sigma(Index,1));
        end
        N2ory=0.5*(ones(6,1)-Yy).^itMap;
        MSEMSE=exp(N2ory);%(6)
%  MSEMSE=ones(6,1);
% mweight{itMap}=MSEMSE;
        A=pinv(diag(MSEMSE.^2))*lameda*length(X);
        featX = extFeat(X,pcmptFeat);
%         featX = computeFeature(Xmodel,X,sigmaSq,normals);
%   featX = computeFeature(Xmodel',X,sigmaSq,normals);
        B=featX*featX';
    % find difference between current estimates and goals
        featY = Y - Ygoal;
        C=featY*featX';
        D1{itMap} = sylvester(A,B,C);
        Y = Y - D1{itMap}*featX;   
%     DH{itMap} = D1{itMap}*featX;
%     DH_monoto{itMap} = diag(featY'*DH{itMap});
        rotMat = paramToTransMatnew(Y);
        R{itMap,1}=rotMat;
        X = transCellnew(rotMat,Xori,0);
%     for i=1:length(rotMat)
% %         X1{itMap} = rotMat{i,1}(1:3,1:3)*Xmodel+rotMat{i,1}(1:3,4)'*Xmodel;
%         X1_1= rotMat{i,1}(1:3,1:3)*Xmodel;
%         X1_2= rotMat{i,1}(1:3,4)'*Xmodel;
%         Xg_1= rotMat_g{i,1}(1:3,1:3)*Xmodel;
%         Xg_2= rotMat_g{i,1}(1:3,4)'*Xmodel;
%         MSE_Rotation(itMap,i)=immse(X1_1,Xg_1);
%         MSE_Translation(itMap,i)=immse(X1_2,Xg_2);
%             if itMap==1 % Rate_rotate=velocity
%             Rate_rotate(itMap,i)=(MSE_Rotation0(i,1)-MSE_Rotation(itMap,i));
%             Rate_trans(itMap,i)=(MSE_Translation0(i,1)-MSE_Translation(itMap,i)); 
%             else
%             Rate_rotate(itMap,i)=(MSE_Rotation(itMap-1,i)-MSE_Rotation(itMap,i));
%             Rate_trans(itMap,i)=(MSE_Translation(itMap-1,i)-MSE_Translation(itMap,i));
%             end
%     end
%     figure(3)
%     pcshowpair(pointCloud(X1{itMap}'),pointCloud(Xg'));
% % figure(4)
%     hold on 
%     Planedraw1(rotMat);
%     [Ry] = Painting(rotMat);
    error(itMap) = norm(Ygoal-Y,'fro')^2/length(X);
%     for i=1:1
%     Error_(itMap,i)=norm(Ygoal(:,i)-Y(:,i));
%     end
    fprintf('ItWDO: %d, err: %f\n',itMap,error(itMap))
    
%   if itMap~=1
%         if abs(error(itMap)-error(itMap-1))<10^(-3)
%             flag=0;
%         else
%             flag=1;
%         end
%    end
% itMap=itMap+1;
  
%     s=0;
%     if ~(itMap==1)
%         deltaD=D1{itMap}-D1{itMap-1};
%         for j=1:size(deltaD,2)
%             s = s+ norm(deltaD(:,j));
%             DD=s/size(deltaD,2);
%         end
%         if DD<10^(-4)
%             break;
%         end
%     end
end

% save data

DM = struct();
DM.Dmap = D1;
DM.runOrder = 1:length(D1);
DM.trainErr = error;
DM.Xmodel = Xmodel;
% DM.Dh = DH_monoto;
% DM.DH = DH;
DM.pcmptFeat = pcmptFeat;
DM.normals = normals;
end
