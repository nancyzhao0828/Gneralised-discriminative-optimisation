function [G1,SH,D_SH,TB_index_test,index_boundary,DT,model_P1] = Graphdraw02(model_P)
        model_P2=unique(model_P','rows');
        model_P1=model_P2';
        DT = delaunayTriangulation(model_P1(1:2,:)');% model_P_airplane{1,476}(1:2,:)
        % triplot(DT)
        DT_matrix=zeros(length(model_P),length(model_P));
        DTC=DT.ConnectivityList;
        for i=1:length(DTC)
            DT_matrix(DTC(i,1),DTC(i,2))=DT_matrix(DTC(i,1),DTC(i,2))+1;
            DT_matrix(DTC(i,1),DTC(i,3))=DT_matrix(DTC(i,1),DTC(i,3))+1;
            DT_matrix(DTC(i,2),DTC(i,3))=DT_matrix(DTC(i,2),DTC(i,3))+1;
            DT_matrix(DTC(i,2),DTC(i,1))=DT_matrix(DTC(i,2),DTC(i,1))+1;
            DT_matrix(DTC(i,3),DTC(i,1))=DT_matrix(DTC(i,3),DTC(i,1))+1;
            DT_matrix(DTC(i,3),DTC(i,2))=DT_matrix(DTC(i,3),DTC(i,2))+1;
        end
        tf = issymmetric(DT_matrix);
        G1=graph(DT_matrix);
        UW=degree(G1);
        TB=sortrows(tabulate(UW),2);
        a1=DT.ConnectivityList;
        SH=subgraph(G1,unique(a1));
        D_SH=degree(SH);
        TB_D_SH=sortrows(tabulate(D_SH),2);
        if length(TB_D_SH)<10
            a=10-length(TB_D_SH);
            TB_index_test=[zeros(a,1);TB_D_SH(:,1)];
        else
            TB_index_test=TB_D_SH(end-9:end,1);
        end
        [bids_X2_, E_X2_, Ne_X2_] = find_delaunay_boundary03_fig1(double(model_P1'),0.2);%0.4
        close;
        index_boundary=[];
        for i=1:length(bids_X2_)
            index_boundary=[bids_X2_{1,i};index_boundary];
        end
        close;
end

