function [iRSRDO,MSERDO,Runtime,Xgt,Xgts] = DOevaluation01(DM,Rtest1,Xtest1,MSERDO,iRSRDO,model_test)
   maxIter = 1000;
   stopThres = 0.001;
   DM.Xmodel=single(DM.Xmodel);
    starttime_RDO = tic;
   [RDOYout,Ystep,Xstep] = inferJX(DM,{Xtest1},maxIter,stopThres,model_test);%RDO
    Runtime  = toc(starttime_RDO);
    if size(model_test,2)>3
%    Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*DM.Xmodel,Rtest1(1:3,4));% groundtruth
     Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*model_test,Rtest1(1:3,4));% groundtruth
   else
%    Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*DM.Xmodel',Rtest1(1:3,4));% groundtruth  
     Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*model_test',Rtest1(1:3,4));% groundtruth  
   end
   Xgts = Xstep{end}{1,1};
%    if size(DM.Xmodel,2)>3
%    Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*DM.Xmodel,Rtest1(1:3,4));% groundtruth
%    else
%    Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*DM.Xmodel',Rtest1(1:3,4));% groundtruth   
%    end
%    Xgts1 = Xstep{end}{1,1};
%    XgtsCHANG = XstepCHANG{end}{1,1};
   [irsRDO, mseRDO,judgement ] = isRegisterSuccessful( Xgt', Xgts');
   iRSRDO=[iRSRDO;irsRDO];
   MSERDO=[MSERDO;mseRDO];
end