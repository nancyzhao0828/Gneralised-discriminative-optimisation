function [y] = vec(X)
%VEC 
y = X(:);

end

