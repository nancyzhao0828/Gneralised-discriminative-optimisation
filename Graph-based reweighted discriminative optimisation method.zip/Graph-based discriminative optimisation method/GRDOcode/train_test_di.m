clc;clear;
%%testing data
ptcloud_test=pcread('D:\BaiduNetdiskDownload\MOdelNet40_ply_dataset\MOdelNet40_ply_dataset\ModelNet40_ply_downsampling_5120\toilet\test\toilet_0378.ply');
load('D:\BaiduNetdiskDownload\MOdelNet40_ply_dataset\MOdelNet40_ply_dataset\ModelNet40_ply_downsampling_5120\toilet\matlab.mat') 
% load('D:\BaiduNetdiskDownload\MOdelNet40_ply_dataset\MOdelNet40_ply_dataset\ModelNet40_ply_downsampling_1024\bed\matlab.mat')
% load('D:\BaiduNetdiskDownload\MOdelNet40_ply_dataset\MOdelNet40_ply_dataset\ModelNet40_ply_downsampling_1024\bench\matlab.mat')
% load('D:\BaiduNetdiskDownload\MOdelNet40_ply_dataset\MOdelNet40_ply_dataset\ModelNet40_ply_downsampling_1024\bookshelf\matlab.mat')
% load('D:\BaiduNetdiskDownload\MOdelNet40_ply_dataset\MOdelNet40_ply_dataset\ModelNet40_ply_downsampling_1024\toilet\matlab.mat')
Model_P=model_P_toilet;%,model_P_bed,model_P_bench,model_P_bookshelf,model_P_toilet
% training data
% ptcloud_train=pcread('D:\BaiduNetdiskDownload\MOdelNet40_ply_dataset\MOdelNet40_ply_dataset\ModelNet40_ply_downsampling_1024\toilet\train\toilet_0323.ply');
% Normalization
P_test_L = ptcloud_test.Location;
modelFull_test = P_test_L';
modelFull_test = bsxfun(@minus,modelFull_test,min(modelFull_test,[],2));
modelFull_test = bsxfun(@minus,modelFull_test,max(modelFull_test,[],2)/2);
modelFull_test = modelFull_test / max(abs(modelFull_test(:)));
% P_train_L = ptcloud_train.Location;
% modelFull_train = P_train_L';
% modelFull_train = bsxfun(@minus,modelFull_train,min(modelFull_train,[],2));
% modelFull_train = bsxfun(@minus,modelFull_train,max(modelFull_train,[],2)/2);
% modelFull_train = modelFull_train / max(abs(modelFull_train(:)));
% modelFull_train = Model_P{1,114};
% 
modelFull_train = modelFull_test;% should be deleted
% [tform,movingReg] = pcregistercpd(pointCloud(modelFull_train'),pointCloud(modelFull_test'),'Transform','rigid');%moving fixed
% modelFull_train=movingReg.Location';

%% Training data
% [bids_X2_, E_X2_, Ne_X2_] = find_delaunay_boundary03_fig1(double(modelFull_train'),0.1);
% G1=graph(Ne_X2_+Ne_X2_');
% UW=degree(G1);
% TB=sortrows(tabulate(UW),2);
% index=find(UW==TB(end,1) | UW==TB(end-1,1));
% Model_Extracted_O = modelFull_train(:,index);
[G1,SH1,UW1,TB_index_train,BO_train,DT1] = Graphdraw02(modelFull_train);
index_ex3_= find((UW1==TB_index_train(end))|(UW1==TB_index_train(end-1)));
index_train = unique([BO_train;index_ex3_]);
Model_Extracted_O = modelFull_train(:,index_train);
% 
% 
% 
  figure
 
  pcshow(pointCloud(modelFull_train'));
    
  P1=pointCloud(modelFull_train');
  ptCloudOut1 = pcdownsample(P1,'random',0.42);
  ptCloudOut2 = pcdownsample(P1,'gridAverage',0.0525);
  ptCloudOut3 = pcdownsample(P1,'nonuniformGridSample',8);
  
  figure
  
  pcshow(pointCloud(Model_Extracted_O'));
  
  figure
  pcshow(ptCloudOut1);
  
  figure
  pcshow(ptCloudOut2);
  
  
  
  
  
  subplot(2,2,4)
  pcshow(ptCloudOut3);
  
    pcshowpair(pointCloud(Model_Extracted_O'),pointCloud(modelFull_train'));

    nTrain =3000; % number of training samples
% % generate train set
fprintf('Generating %d training data\n',nTrain);
% cells for saving generated data
Rtrain = cell(1,nTrain);
Xtrain = cell(1,nTrain);
Ytrain = cell(1,nTrain); % the inverse of the transformation matrix
for i = 1:nTrain   
    % setting for generate train set
    opt = struct( ...
        'vertex',modelFull_train, ... % the template point cloud for generating data D*N
        'nVertices',5120,... % number of points
        'rotation',90*(sqrt(rand())),... % angle for generating random rotation
        'translation',sign(randn(3,1)).*rand(3,1)*0.5,... % random translation
        'nOutlier',0,... % number of outliers
        'outlBd',1.5*[-1 1;-1 1;-1 1],... % boundaries of outliers
        'noiseSd',0.05,... % noise sd
        'rRmvPt',0); % percentage of incompleteness for model
    
    % generate train data
    [Xtrain{i},Rtrain{i},Ytrain{i}] = generateData_(opt,modelFull_train);
    
    % generate structured outliers
%     Xtrain{i} = [Xtrain{i} ...
%         bsxfun(@plus,randn(3,ceil(50+rand*00))/(4+5*rand),sign(rand(3,1)-0.5).*rand(3,1)*1.5)];
    Rtrain{i} = Rtrain{i}(1:3,:);
    Ytrain{i} = Ytrain{i}(1:3,:);
end
for k=1:length(Xtrain)
    Xtrain{1,k}=Xtrain{1,k}(1:3,:); %D*N
end

Model_Extracted_tr=cell(1,length(Xtrain));
for i=1:length(Xtrain)
% [bids_X2_0, E_X2_0, Ne_X2_0] = find_delaunay_boundary03_fig1(double(Xtrain{1,i}'),0.1);
% G1_0=graph(Ne_X2_0+Ne_X2_0');
% UW_0=degree(G1_0);
% TB_0=sortrows(tabulate(UW_0),2);
% index_0=find(UW_0==TB(end,1) | UW_0==TB(end-1,1));
[G2,SH2,UW2,TB_index_train2,BO_train2,DT2] = Graphdraw02(Xtrain{1,i});
index_ex2_= find((UW2==TB_index_train(end))|(UW2==TB_index_train(end-1)));
index_0 = unique([BO_train2;index_ex2_]);
Model_Extracted_tr{1,i} = Xtrain{1,i}(:,index_0);
end
%     figure
%     pcshowpair(pointCloud(Model_Extracted_tr'),pointCloud(Xtrain{1,1}'));
sigmaSq = 0.3; 
beta=0.1;
nMap=30;  
gridStep=0.1;
[pcmptFeat,normals] = precomputeFeature(modelFull_train,sigmaSq,gridStep);
[DMDO,trainErr] = learnDO(modelFull_train,Xtrain,Ytrain,nMap,pcmptFeat,normals);
[DMRDO,errorRDO] = learnDOnewnewWUN(modelFull_train,Xtrain,Ytrain,nMap,pcmptFeat,normals);% final
%
% [DMDO_test,error_DOtest] = learnDO_test(Model_Extracted_O,Model_Extracted_tr,Ytrain,0);
% [DMRDO_test,error_RDOtest] = learnRDO_test(Model_Extracted_O,Model_Extracted_tr,Ytrain,0);
%
[DMGRDO,error_RDOfdtest] = learnRDO_testfd(Model_Extracted_O,Model_Extracted_tr,Ytrain,30,sigmaSq,gridStep);
[DMGDO,error_DOfdtest] = learnDO_testfd(Model_Extracted_O,Model_Extracted_tr,Ytrain,30,sigmaSq,gridStep);
%% Testing data
% load('D:\BaiduNetdiskDownload\WDOnew\WDOnew\WDO01\DancingChildren\Rotation\Rotation0.mat')
Rtest = cell(1,75);
Xtest = cell(1,75);
Ytest = cell(1,75); 
for j=1:75
% generate train data
opt = struct( ...
    'vertex',modelFull_test, ... % the template point cloud for generating data D*M
    ... % note that for test here we use a different point cloud!
    'nVertices',5120,... % number of points
    'rotation',90*(sqrt(rand())),... % angle for generating random rotation
    'translation',sign(randn(3,1)).*rand(3,1)*0.5,... % random translation
    'nOutlier',0,... % number of outliers
    'outlBd',1.5*[-1 1;-1 1;-1 1],... % boundaries of outliers
    'noiseSd',0,... % noise sd
    'rRmvPt',0); % percentage of incompleteness for model
[Xtest{1,j},Rtest{1,j},Ytest{1,j}] = generateData_(opt,modelFull_test);
end
%% Generate the testing data  test data is different from training data
% [bids_X2_, E_X2_, Ne_X2_] = find_delaunay_boundary03_fig1(double(modelFull_test'),0.1);
% G1=graph(Ne_X2_+Ne_X2_');
% UW0=degree(G1);
% % TB=sortrows(tabulate(UW),2);
% index0=find(UW0==TB(end,1) | UW0==TB(end-1,1));
% Model_Extracted_t = modelFull_test(:,index0);
% close;
Model_Extracted_tr_test=cell(1,length(Xtest));
for k=1:length(Xtest)
    Xtest{1,k}=double(Xtest{1,k});
%     [bids_X2_0, E_X2_0, Ne_X2_0] = find_delaunay_boundary03_fig1(double( Xtest{1,k}'),0.1);
%     G1_0=graph(Ne_X2_0+Ne_X2_0');
%     UW_0=degree(G1_0);
%     TB_0=sortrows(tabulate(UW_0),2);
%     index_0=find(UW_0==TB(end,1) | UW_0==TB(end-1,1));
    [G3,SH3,UW3,TB_index_test,BO_test,DT3] = Graphdraw02(Xtest{1,k});
    index_ex1_= find((UW3==TB_index_train(end))|(UW3==TB_index_train(end-1)));
    index_test = unique([BO_test;index_ex1_]);
    Model_Extracted_tr_test{1,k} = Xtest{1,k}(:,index_test);
end
iRSDO0=[];MSEDO0=[];
iRSRDO0=[];MSERDO0=[];
iRSICP0=[];MSEICP0=[];
iRSCPD0=[];MSECPD0=[];
iRSNDT0=[];MSENDT0=[];
% iRSIRLS=[];MSEIRLS=[];
iRSGRDO0=[];MSEGRDO0=[];
iRSGDO0=[];MSEGDO0=[];
RuntimeDO0=zeros(1,75);  
RuntimeRDO0=zeros(1,75);
RuntimeICP0=zeros(1,75);
RuntimeCPD0=zeros(1,75);
RuntimeNDT0=zeros(1,75);
% RuntimeIRLS=zeros(1,75);
RuntimeGRDO0=zeros(1,75);
RuntimeGDO0=zeros(1,75);
XgtDO=cell(1,75);XgtsDO=cell(1,75);% groundtruth & transformation result
XgtRDO=cell(1,75);XgtsRDO=cell(1,75);
XgtICP=cell(1,75);XgtsICP=cell(1,75);
XgtCPD=cell(1,75);XgtsCPD=cell(1,75);
XgtNDT=cell(1,75);XgtsNDT=cell(1,75);
% XgtIRLS=cell(1,75);XgtsIRLS=cell(1,75);
XgtRDOfd=cell(1,75);XgtsRDOfd=cell(1,75);
XgtDOfd=cell(1,75);XgtsDOfd=cell(1,75);
% [pcmptFeat_test,normals_test] = precomputeFeature(Model_Extracted_t,sigmaSq,gridStep);
% [pcmptFeat_Test,normals_Test] = precomputeFeature(modelFull_test,sigmaSq,gridStep);
% [Ot_index] = matrix_cons(Model_Extracted_O,Model_Extracted_t);
for k=1:length(Xtest)
    Xtest{1,k}=single(Xtest{1,k});
    Ytest{1,k}=single(Ytest{1,k});
end
for k=1:75
    Xtest0=Xtest{1,k}(1:3,:);
    Xtest1=Model_Extracted_tr_test{1,k};
    Rtest1=Rtest{1,k};
    %% traditional DO & RDO
    [iRSDO0,MSEDO0,RuntimeDO0(1,k),XgtDO{1,k},XgtsDO{1,k}] = DOevaluation01(DMDO,Rtest1,Xtest0,MSEDO0,iRSDO0,modelFull_train);
    [iRSRDO0,MSERDO0,RuntimeRDO0(1,k),XgtRDO{1,k},XgtsRDO{1,k}] = DOevaluation01(DMRDO,Rtest1,Xtest0,MSERDO0,iRSRDO0,modelFull_train);
    %% complex feature & mapping
%     [iRSDO_test,MSEDO_test,RuntimeDO_test(1,k)] = DOevaluation01_test(DMDO_test,Rtest1,Xtest1,MSEDO_test,iRSDO_test,sigmaSq,Model_Extracted_t,modelFull_test,Ot_index);
%     [iRSRDO_test,MSERDO_test,RuntimeRDO_test(1,k)] = DOevaluation01_test(DMRDO_test,Rtest1,Xtest1,MSERDO_test,iRSRDO_test,sigmaSq);
    %% DO+test RDO+test
    [iRSGRDO0,MSEGRDO0,RuntimeGRDO0(1,k),XgtRDOfd{1,k},XgtsRDOfd{1,k}] = DOevaluation01(DMGRDO,Rtest1,Xtest1,MSEGRDO0,iRSGRDO0,modelFull_train);
    [iRSGDO0,MSEGDO0,RuntimeGDO0(1,k),XgtDOfd{1,k},XgtsDOfd{1,k}] = DOevaluation01(DMGDO,Rtest1,Xtest1,MSEGDO0,iRSGDO0,modelFull_train);
    %% simple feature & mapping
%     [iRSGRDO_,MSEGRDO_,RuntimeGRDO_(1,k)] = DOevaluation01_test_(DMGRDO,Rtest1,Xtest1,MSEGRDO_,iRSGRDO_,modelFull_test,pcmptFeat_test,Ot_index);
%     [iRSGDO_,MSEGDO_,RuntimeGDO_(1,k)] = DOevaluation01_test_(DMGDO,Rtest1,Xtest1,MSEGDO_,iRSGDO_,modelFull_test,pcmptFeat_test); 
%     [iRSRDOfd02_test_,MSERDOfd02_test_,RuntimeRDOfd02_test_(1,k)] = DOevaluation02_test_(DMGRDO,Rtest1,Xtest1,MSERDOfd02_test_,iRSRDOfd02_test_,modelFull_test);
%     [iRSDOfd02_test_,MSEDOfd02_test_,RuntimeDOfd02_test_(1,k)] = DOevaluation02_test_(DMGDO,Rtest1,Xtest1,MSEDOfd02_test_,iRSDOfd02_test_,modelFull_test); 
%     [iRSDO001,MSEDO001,RuntimeDO001(1,k)] = DOevaluation001_test_(DMGDO,Rtest1,Xtest1,MSEDO001,iRSDO001,modelFull_test,pcmptFeat_Test);
    %% ICP+CPD+NDT+IRLS
     [iRSICP0,MSEICP0,RuntimeICP0(1,k),XgtICP{1,k},XgtsICP{1,k}] = ICPevaluation01(Rtest1,Xtest0,MSEICP0,iRSICP0,modelFull_train);
     [iRSCPD0,MSECPD0,RuntimeCPD0(1,k),XgtCPD{1,k},XgtsCPD{1,k}] = CPDevaluation01(Rtest1,Xtest0,MSECPD0,iRSCPD0,modelFull_train);
     [iRSNDT0,MSENDT0,RuntimeNDT0(1,k),XgtNDT{1,k},XgtsNDT{1,k}] = NDTevaluation01(Rtest1,Xtest0,MSENDT0,iRSNDT0,modelFull_train);
%      [iRSIRLS,MSEIRLS,RuntimeIRLS(1,k),XgtIRLS{1,k},XgtsIRLS{1,k}] = IRLSevaluation01(Rtest1,Xtest0,MSEIRLS,iRSIRLS,modelFull_train);
end
mDO0=mean(MSEDO0);
mRuntimeDO0=mean(RuntimeDO0);
mRDO0=mean(MSERDO0);
mRuntimeRDO0=mean(RuntimeRDO0);
mICP0=mean(MSEICP0);
mRuntimeICP0=mean(RuntimeICP0);
mCPD0=mean(MSECPD0);
mRuntimeCPD0=mean(RuntimeCPD0);
mNDT0=mean(MSENDT0);
mRuntimeNDT0=mean(RuntimeNDT0);
% mIRLS=mean(MSEIRLS);
% mRuntimeIRLS=mean(RuntimeIRLS);

mGRDO0=mean(MSEGRDO0);
mRuntimeGRDO0=mean(RuntimeGRDO0);
mGDO0=mean(MSEGDO0);
mRuntimeGDO0=mean(RuntimeGDO0);

DOS0=find(iRSDO0~=1); 
RDOS0=find(iRSRDO0~=1);
ICPS0=find(iRSICP0~=1);
CPDS0=find(iRSCPD0~=1);
NDTS0=find(iRSNDT0~=1);
% IRLSS=find(iRSIRLS~=1);
GRDOS0=find(iRSGRDO0~=1);
GDOS0=find(iRSGDO0~=1);

RDO0_=1-length(DOS0)/length(iRSDO0);
RRDO0_=1-length(RDOS0)/length(iRSRDO0);
RICP0_=1-length(ICPS0)/length(iRSICP0);
RCPD0_=1-length(CPDS0)/length(iRSCPD0);
RNDT0_=1-length(NDTS0)/length(iRSNDT0);
% RIRLS_=1-length(IRLSS)/length(iRSIRLS);
RGRDO0_=1-length(GRDOS0)/length(iRSGRDO0);
GRDO0_=1-length(GDOS0)/length(iRSGDO0);


MSEDO1=MSEDO0;
MSEDO1(DOS0,:)=[];
mdo0=mean(MSEDO1);
MSERDO1=MSERDO0;
MSERDO1(RDOS0,:)=[];
mrdo0=mean(MSERDO1);
MSEICP1=MSEICP0;
MSEICP1(ICPS0,:)=[];
micp0=mean(MSEICP1);
MSECPD1=MSECPD0;
MSECPD1(CPDS0,:)=[];
mcpd0=mean(MSECPD1);
MSENDT1=MSENDT0;
MSENDT1(NDTS0,:)=[];
mndt0=mean(MSENDT1);
% MSEIRLS1=MSEIRLS;
% MSEIRLS1(IRLSS,:)=[];
% mirls=mean(MSEIRLS1);

MSEGRDO1=MSEGRDO0;
MSEGRDO1(GRDOS0,:)=[];
mgrdo0=mean(MSEGRDO1);
MSEGDO1=MSEGDO0;
MSEGDO1(GDOS0,:)=[];  
mgdo0=mean(MSEGDO1);
% load gong
% sound(y,Fs)
cd D:\BaiduNetdiskDownload\GRDO\train90N\Otherms