function [DM,error,Y,R] = learnDO(Xmodel,X,Y,nMap,pcmptFeat,normals)
%  function [DM,error,Y,R] = learnDO(Xmodel,X,Y,nMap,sigmaSq,gridStep)
%LEARNDO Summary of this function goes here
%   Detailed explanation goes here

fprintf('Training DO with %d maps\n',nMap)
fprintf('#data: %d \n',length(X))

D = cell(1,nMap);
error = inf(nMap,1);
Xori = X;% data
Yori = Y;
Yorimat = reshape(cell2mat(Yori),[numel(Yori{1}) length(Yori)]);%numel: number of elements in an array
Ymat = Yorimat;

% [pcmptFeat,normals] = precomputeFeature(Xmodel,sigmaSq,gridStep);
% pcmptFeat=DMRDONNWUN.pcmptFeat;
% normals=DMRDONNWUN.normals;
Ygoal = transMatToParam(Yori);
Yinit = zeros(6,length(X));% the parameters are initialized to 0
Y = Yinit;
R=cell(nMap,1);
% It means the iterations;
fprintf('It: %d, err: %f\n',0,norm(Ygoal-Y,'fro').^2/length(X))
% % [ normals ] = findPointNormals(Xmodel,3,[0 0 0]);
for itMap = 1:nMap

   featX = extFeat(X,pcmptFeat);
%     featX = computeFeature(Xmodel,X,sigmaSq,normals);
    featY = Y - Ygoal;
    D{itMap} = (featY*featX')/(featX*featX'+1e-4*length(X)*(eye(size(featX,1))));% Discriminative Optimization                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
    Y = Y - D{itMap}*featX;
%     DH{itMap} = D{itMap}*featX;
%     DH_monoto{itMap} = diag(featY'*DH{itMap});
    % convert to parameters to transformation matrices
    rotMat = paramToTransMatnew(Y);  
     R{itMap,1}=rotMat;
    % transform shapes
    X = transCellnew(rotMat,Xori,0);
%      [Ry] = Painting(rotMat);
    % compute and print error
    error(itMap) = norm(Ygoal-Y,'fro')^2/length(X);
    fprintf('It: %d, err: %f\n',itMap,error(itMap))
%     s=0;
%     if ~(itMap==1)
%         deltaD=D{itMap}-D{itMap-1};
%         for j=1:size(deltaD,2)
%          s = s+ norm(deltaD(:,j));
%          DD=s/size(deltaD,2);
%         end
%         if DD<10^(-4)
%            break;
%         end
%     end 
% end
% if itMap~=1
%     if abs(error(itMap)-error(itMap-1))<10^(-3)
%         flag=0;
%     else
%         flag=1;
%     end
% end
% itMap=itMap+1;
end


% save data

DM = struct();
DM.Dmap = D;
DM.runOrder = 1:length(D);
DM.trainErr = error;
DM.Xmodel = Xmodel;
% DM.Dh = DH_monoto;
% DM.DH = DH;
DM.pcmptFeat = pcmptFeat;
DM.normals = normals;
end

function x = addZero(x)
    x = [x zeros(size(x,1),1);zeros(1,size(x,1)+1)];
end
