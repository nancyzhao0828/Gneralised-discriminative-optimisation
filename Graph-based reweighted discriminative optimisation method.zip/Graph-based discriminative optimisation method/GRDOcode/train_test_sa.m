clc;clear;
% testing data
ptcloud_test=pcread('D:\BaiduNetdiskDownload\MOdelNet40_ply_dataset\MOdelNet40_ply_dataset\ModelNet40_ply_downsampling_1024\airplane\test\airplane_0627.ply');
% load('D:\BaiduNetdiskDownload\MOdelNet40_ply_dataset\MOdelNet40_ply_dataset\ModelNet40_ply_downsampling_1024\airplane\matlab.mat')  
% % load('D:\BaiduNetdiskDownload\MOdelNet40_ply_dataset\MOdelNet40_ply_dataset\ModelNet40_ply_downsampling_1024\bed\matlab.mat')
% % load('D:\BaiduNetdiskDownload\MOdelNet40_ply_dataset\MOdelNet40_ply_dataset\ModelNet40_ply_downsampling_1024\bench\matlab.mat')
% % load('D:\BaiduNetdiskDownload\MOdelNet40_ply_dataset\MOdelNet40_ply_dataset\ModelNet40_ply_downsampling_1024\bookshelf\matlab.mat')
% % load('D:\BaiduNetdiskDownload\MOdelNet40_ply_dataset\MOdelNet40_ply_dataset\ModelNet40_ply_downsampling_1024\car\matlab.mat')
% Model_P=model_P_airplane;%,model_P_bed,model_P_bench,model_P_bookshelf,model_P_Car
% training data
% ptcloud_train=pcread('D:\BaiduNetdiskDownload\MOdelNet40_ply_dataset\MOdelNet40_ply_dataset\ModelNet40_ply_downsampling_1024\airplane\train\airplane_0323.ply');
% Normalization
P_test_L = ptcloud_test.Location;
modelFull_test = P_test_L';
modelFull_test = bsxfun(@minus,modelFull_test,min(modelFull_test,[],2));
modelFull_test = bsxfun(@minus,modelFull_test,max(modelFull_test,[],2)/2);
modelFull_test = modelFull_test / max(abs(modelFull_test(:)));
% P_train_L = ptcloud_train.Location;
% modelFull_train = P_train_L';
% modelFull_train = bsxfun(@minus,modelFull_train,min(modelFull_train,[],2));
% modelFull_train = bsxfun(@minus,modelFull_train,max(modelFull_train,[],2)/2);
% modelFull_train = modelFull_train / max(abs(modelFull_train(:)));
modelFull_train = modelFull_test;
% modelFull_train = modelFull_test;% should be deleted
% [tform,movingReg] = pcregistericp(pointCloud(modelFull_test'),pointCloud(modelFull_train'));
% modelFull_test=movingReg.Location';

%% Training data
% [bids_X2_, E_X2_, Ne_X2_] = find_delaunay_boundary03_fig1(double(modelFull_train'),0.1);
% G1=graph(Ne_X2_+Ne_X2_');
% UW=degree(G1);
% TB=sortrows(tabulate(UW),2);
% index=find(UW==TB(end,1) | UW==TB(end-1,1));
% Model_Extracted_O = modelFull_train(:,index);
[G1,SH1,UW1,TB_index_train,BO_train,DT1] = Graphdraw02(modelFull_train);
index_ex3_= find((UW1==TB_index_train(end))|(UW1==TB_index_train(end-1)));
index_train = unique([BO_train;index_ex3_]);
Model_Extracted_O = modelFull_train(:,index_train);



%     figure
%     pcshowpair(pointCloud(Model_Extracted_O'),pointCloud(modelFull_train'));
nTrain = 3000; % number of training samples
% % generate train set
fprintf('Generating %d training data\n',nTrain);
% cells for saving generated data
Rtrain = cell(1,nTrain);
Xtrain = cell(1,nTrain);
Ytrain = cell(1,nTrain); % the inverse of the transformation matrix
for i = 1:nTrain   
    % setting for generate train set
    opt = struct( ...
        'vertex',modelFull_train, ... % the template point cloud for generating data D*N
        'nVertices',1024,... % number of points
        'rotation',45*(sqrt(rand())),... % angle for generating random rotation
        'translation',sign(randn(3,1)).*rand(3,1)*0.5,... % random translation
        'nOutlier',0,... % number of outliers
        'outlBd',1.5*[-1 1;-1 1;-1 1],... % boundaries of outliers
        'noiseSd',0,... % noise sd
        'rRmvPt',0); % percentage of incompleteness for model
    
    % generate train data
    [Xtrain{i},Rtrain{i},Ytrain{i}] = generateData(opt);
    
    % generate structured outliers
%     Xtrain{i} = [Xtrain{i} ...
%         bsxfun(@plus,randn(3,ceil(50+rand*150))/(4+5*rand),sign(rand(3,1)-0.5).*rand(3,1)*1.5)];
    Rtrain{i} = Rtrain{i}(1:3,:);
    Ytrain{i} = Ytrain{i}(1:3,:);
end
for k=1:length(Xtrain)
    Xtrain{1,k}=Xtrain{1,k}(1:3,:); %D*N
end

Model_Extracted_tr=cell(1,length(Xtrain));
for i=1:length(Xtrain)
% [bids_X2_0, E_X2_0, Ne_X2_0] = find_delaunay_boundary03_fig1(double(Xtrain{1,i}'),0.1);
% G1_0=graph(Ne_X2_0+Ne_X2_0');
% UW_0=degree(G1_0);
% TB_0=sortrows(tabulate(UW_0),2);
% index_0=find(UW_0==TB(end,1) | UW_0==TB(end-1,1));
[G2,SH2,UW2,TB_index_train2,BO_train2,DT2] = Graphdraw02(Xtrain{1,i});
index_ex2_= find((UW2==TB_index_train(end))|(UW2==TB_index_train(end-1)));
index_0 = unique([BO_train2;index_ex2_]);
Model_Extracted_tr{1,i} = Xtrain{1,i}(:,index_0);
end
%     figure
%     pcshowpair(pointCloud(Model_Extracted_tr'),pointCloud(Xtrain{1,1}'));
sigmaSq = 0.3; 
beta=0.1;
nMap=30;  
gridStep=0.05;
[pcmptFeat,normals] = precomputeFeature(modelFull_train,sigmaSq,gridStep);
[DMDO,trainErr] = learnDO(modelFull_train,Xtrain,Ytrain,nMap,pcmptFeat,normals);
[DMRDO,errorRDO] = learnDOnewnewWUN(modelFull_train,Xtrain,Ytrain,nMap,pcmptFeat,normals);% final
%
% [DMDO_test,error_DOtest] = learnDO_test(Model_Extracted_O,Model_Extracted_tr,Ytrain,30);
% [DMRDO_test,error_RDOtest] = learnRDO_test(Model_Extracted_O,Model_Extracted_tr,Ytrain,30);
%
[DMRDOfd_test,error_RDOfdtest] = learnRDO_testfd(Model_Extracted_O,Model_Extracted_tr,Ytrain,30,sigmaSq,gridStep);
[DMDOfd_test,error_DOfdtest] = learnDO_testfd(Model_Extracted_O,Model_Extracted_tr,Ytrain,30,sigmaSq,gridStep);
%% Testing data
% load('D:\BaiduNetdiskDownload\WDOnew\WDOnew\WDO01\DancingChildren\Rotation\Rotation60.mat')
Rtest = cell(1,75);
Xtest = cell(1,75);
Ytest = cell(1,75); 
for j=1:75
% generate train data
opt = struct( ...
    'vertex',modelFull_test, ... % the template point cloud for generating data D*M
    ... % note that for test here we use a different point cloud!
    'nVertices',1024,... % number of points
    'rotation',75,... % angle for generating random rotation
    'translation',sign(randn(3,1)).*rand(3,1)*0.5,... % random translation
    'nOutlier',0,... % number of outliers
    'outlBd',1.5*[-1 1;-1 1;-1 1],... % boundaries of outliers
    'noiseSd',0,... % noise sd
    'rRmvPt',0); % percentage of incompleteness for model
[Xtest{1,j},Rtest{1,j},Ytest{1,j}] = generateData(opt);
end
%% Generate the testing data  test data is different from training data
% [bids_X2_, E_X2_, Ne_X2_] = find_delaunay_boundary03_fig1(double(modelFull_test'),0.1);
% G1=graph(Ne_X2_+Ne_X2_');
% UW0=degree(G1);
% % TB=sortrows(tabulate(UW),2);
% index0=find(UW0==TB(end,1) | UW0==TB(end-1,1));
% Model_Extracted_t = modelFull_test(:,index0);
% close;
Model_Extracted_tr_test=cell(1,length(Xtest));
for k=1:length(Xtest)
    Xtest{1,k}=single(Xtest{1,k});
%     [bids_X2_0, E_X2_0, Ne_X2_0] = find_delaunay_boundary03_fig1(double( Xtest{1,k}'),0.1);
%     G1_0=graph(Ne_X2_0+Ne_X2_0');
%     UW_0=degree(G1_0);
%     TB_0=sortrows(tabulate(UW_0),2);
%     index_0=find(UW_0==TB(end,1) | UW_0==TB(end-1,1));
    [G3,SH3,UW3,TB_index_test,BO_test,DT3] = Graphdraw02(double(Xtest{1,k}));
    index_ex1_= find((UW3==TB_index_train(end))|(UW3==TB_index_train(end-1)));
    index_test = unique([BO_test;index_ex1_]);
    Model_Extracted_tr_test{1,k} = Xtest{1,k}(:,index_test);
end
iRSDO=[];MSEDO=[];
iRSRDO=[];MSERDO=[];
iRSICP=[];MSEICP=[];
iRSCPD=[];MSECPD=[];
iRSNDT=[];MSENDT=[];
iRSIRLS=[];MSEIRLS=[];
iRSGRDO=[];MSEGRDO=[];
iRSGDO=[];MSEGDO=[];
RuntimeDO=zeros(1,75);  
RuntimeRDO=zeros(1,75);
RuntimeICP=zeros(1,75);
RuntimeCPD=zeros(1,75);
RuntimeNDT=zeros(1,75);
RuntimeIRLS=zeros(1,75);
RuntimeGRDO=zeros(1,75);
RuntimeGDO=zeros(1,75);
XgtDO=cell(1,75);XgtsDO=cell(1,75);% groundtruth & transformation result
XgtRDO=cell(1,75);XgtsRDO=cell(1,75);
XgtICP=cell(1,75);XgtsICP=cell(1,75);
XgtCPD=cell(1,75);XgtsCPD=cell(1,75);
XgtNDT=cell(1,75);XgtsNDT=cell(1,75);
XgtIRLS=cell(1,75);XgtsIRLS=cell(1,75);
XgtRDOfd=cell(1,75);XgtsRDOfd=cell(1,75);
XgtDOfd=cell(1,75);XgtsDOfd=cell(1,75);
% [pcmptFeat_test,normals_test] = precomputeFeature(Model_Extracted_t,sigmaSq,gridStep);
% [pcmptFeat_Test,normals_Test] = precomputeFeature(modelFull_test,sigmaSq,gridStep);
% [Ot_index] = matrix_cons(Model_Extracted_O,Model_Extracted_t);
for k=1:length(Xtest)
    Xtest{1,k}=single(Xtest{1,k});
    Ytest{1,k}=single(Ytest{1,k});
end
for k=1:75
    Xtest0=Xtest{1,k}(1:3,:);
    Xtest1=Model_Extracted_tr_test{1,k};
    Rtest1=Rtest{1,k};
    %% traditional DO & RDO
    [iRSDO,MSEDO,RuntimeDO(1,k),XgtDO{1,k},XgtsDO{1,k}] = DOevaluation01(DMDO,Rtest1,Xtest0,MSEDO,iRSDO,modelFull_train);
    [iRSRDO,MSERDO,RuntimeRDO(1,k),XgtRDO{1,k},XgtsRDO{1,k}] = DOevaluation01(DMRDO,Rtest1,Xtest0,MSERDO,iRSRDO,modelFull_train);
    %% complex feature & mapping
%     [iRSDO_test,MSEDO_test,RuntimeDO_test(1,k)] = DOevaluation01_test(DMDO_test,Rtest1,Xtest1,MSEDO_test,iRSDO_test,sigmaSq,Model_Extracted_t,modelFull_test,Ot_index);
%     [iRSRDO_test,MSERDO_test,RuntimeRDO_test(1,k)] = DOevaluation01_test(DMRDO_test,Rtest1,Xtest1,MSERDO_test,iRSRDO_test,sigmaSq);
    %% DO+test RDO+test
    [iRSGRDO,MSEGRDO,RuntimeGRDO(1,k),XgtRDOfd{1,k},XgtsRDOfd{1,k}] = DOevaluation01(DMRDOfd_test,Rtest1,Xtest1,MSEGRDO,iRSGRDO,modelFull_train);
    [iRSGDO,MSEGDO,RuntimeGDO(1,k),XgtDOfd{1,k},XgtsDOfd{1,k}] = DOevaluation01(DMDOfd_test,Rtest1,Xtest1,MSEGDO,iRSGDO,modelFull_train);
    %% simple feature & mapping
%     [iRSGRDO_,MSEGRDO_,RuntimeGRDO_(1,k)] = DOevaluation01_test_(DMGRDO,Rtest1,Xtest1,MSEGRDO_,iRSGRDO_,modelFull_test,pcmptFeat_test,Ot_index);
%     [iRSGDO_,MSEGDO_,RuntimeGDO_(1,k)] = DOevaluation01_test_(DMGDO,Rtest1,Xtest1,MSEGDO_,iRSGDO_,modelFull_test,pcmptFeat_test); 
%     [iRSRDOfd02_test_,MSERDOfd02_test_,RuntimeRDOfd02_test_(1,k)] = DOevaluation02_test_(DMGRDO,Rtest1,Xtest1,MSERDOfd02_test_,iRSRDOfd02_test_,modelFull_test);
%     [iRSDOfd02_test_,MSEDOfd02_test_,RuntimeDOfd02_test_(1,k)] = DOevaluation02_test_(DMGDO,Rtest1,Xtest1,MSEDOfd02_test_,iRSDOfd02_test_,modelFull_test); 
%     [iRSDO001,MSEDO001,RuntimeDO001(1,k)] = DOevaluation001_test_(DMGDO,Rtest1,Xtest1,MSEDO001,iRSDO001,modelFull_test,pcmptFeat_Test);
    %% ICP+CPD+NDT+IRLS
     [iRSICP,MSEICP,RuntimeICP(1,k),XgtICP{1,k},XgtsICP{1,k}] = ICPevaluation01(Rtest1,Xtest0,MSEICP,iRSICP,modelFull_train);
     [iRSCPD,MSECPD,RuntimeCPD(1,k),XgtCPD{1,k},XgtsCPD{1,k}] = CPDevaluation01(Rtest1,Xtest0,MSECPD,iRSCPD,modelFull_train);
     [iRSNDT,MSENDT,RuntimeNDT(1,k),XgtNDT{1,k},XgtsNDT{1,k}] = NDTevaluation01(Rtest1,Xtest0,MSENDT,iRSNDT,modelFull_train);
     [iRSIRLS,MSEIRLS,RuntimeIRLS(1,k),XgtIRLS{1,k},XgtsIRLS{1,k}] = IRLSevaluation01(Rtest1,Xtest0,MSEIRLS,iRSIRLS,modelFull_train);
end
mDO=mean(MSEDO);
mRuntimeDO=mean(RuntimeDO);
mRDO=mean(MSERDO);
mRuntimeRDO=mean(RuntimeRDO);
mICP=mean(MSEICP);
mRuntimeICP=mean(RuntimeICP);
mCPD=mean(MSECPD);
mRuntimeCPD=mean(RuntimeCPD);
mNDT=mean(MSENDT);
mRuntimeNDT=mean(RuntimeNDT);
mIRLS=mean(MSEIRLS);
mRuntimeIRLS=mean(RuntimeIRLS);

mGRDO=mean(MSEGRDO);
mRuntimeGRDO=mean(RuntimeGRDO);
mGDO=mean(MSEGDO);
mRuntimeGDO=mean(RuntimeGDO);

DOS=find(iRSDO~=1); 
RDOS=find(iRSRDO~=1);
ICPS=find(iRSICP~=1);
CPDS=find(iRSCPD~=1);
NDTS=find(iRSNDT~=1);
IRLSS=find(iRSIRLS~=1);
GRDOS=find(iRSGRDO~=1);
GDOS=find(iRSGDO~=1);

RDO_=1-length(DOS)/length(iRSDO);
RRDO_=1-length(RDOS)/length(iRSRDO);
RICP_=1-length(ICPS)/length(iRSICP);
RCPD_=1-length(CPDS)/length(iRSCPD);
RNDT_=1-length(NDTS)/length(iRSNDT);
RIRLS_=1-length(IRLSS)/length(iRSIRLS);
RGRDO_=1-length(GRDOS)/length(iRSGRDO);
GRDO_=1-length(GDOS)/length(iRSGDO);


MSEDO1=MSEDO;
MSEDO1(DOS,:)=[];
mdo=mean(MSEDO1);
MSERDO1=MSERDO;
MSERDO1(RDOS,:)=[];
mrdo=mean(MSERDO1);
MSEICP1=MSEICP;
MSEICP1(ICPS,:)=[];
micp=mean(MSEICP1);
MSECPD1=MSECPD;
MSECPD1(CPDS,:)=[];
mcpd=mean(MSECPD1);
MSENDT1=MSENDT;
MSENDT1(NDTS,:)=[];
mndt=mean(MSENDT1);
MSEIRLS1=MSEIRLS;
MSEIRLS1(IRLSS,:)=[];
mirls=mean(MSEIRLS1);

MSEGRDO1=MSEGRDO;
MSEGRDO1(GRDOS,:)=[];
mgrdo=mean(MSEGRDO1);
MSEGDO1=MSEGDO;
MSEGDO1(GDOS,:)=[];
mgdo=mean(MSEGDO1);
% load gong
% sound(y,Fs)
