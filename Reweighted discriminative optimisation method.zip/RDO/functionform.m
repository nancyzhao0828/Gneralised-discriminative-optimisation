function [ttform] = functionform(DMDO,Xtest1)
maxIter = 100; stopThres = 0.001;sigmaSq = 0.03;
[DOYoutDO,YstepDO,XstepDO] = infer(DMDO,Xtest1,maxIter,stopThres);
% [DOYoutDONN,YstepDONN,XstepDONN] = infer(DMDONN,Xtest1,maxIter,stopThres,sigmaSq);
Tform.T=[[YstepDO{end}{1,1}(1:3,1:3);YstepDO{end}{1,1}(1:3,4)'],[0 0 0 1]'];
Tform.Dimensionality=3;
ttform=affine3d(Tform.T);
end

