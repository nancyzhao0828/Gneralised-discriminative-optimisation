function [DM,error] = learnDOnewnewWUN(Xmodel,X,Y,nMap,pcmptFeat,normals)
% function [DM,error] = learnDOnewnewWUN(Xmodel,X,Y,nMap,sigmaSq)
%LEARNDO Summary of this function goes here
%   Detailed explanation goes here

fprintf('Training DO with %d maps\n',nMap)
fprintf('#data: %d \n',length(X))

D = cell(1,nMap);
% D1 = cell(1,nMap);
error = inf(nMap,1);
% error1 = inf(nMap,1);
Xori = X;% data
Yori = Y;
Yorimat = reshape(cell2mat(Yori),[numel(Yori{1}) length(Yori)]);%numel: number of elements in an array
Ymat = Yorimat;

% [pcmptFeat,normals] = precomputeFeature(Xmodel,sigmaSq,gridStep);
% [ normals ] = findPointNormals(Xmodel,3,[0 0 0]);
Ygoal = transMatToParam(Yori);
Yinit = zeros(6,length(X));% the parameters are initialized to 0
Y = Yinit;


% It means the iterations;
fprintf('It: %d, err: %f\n',0,norm(Ygoal-Y,'fro').^2/length(X))
Ykm=0.1*eye(6);
ykm=zeros(6);
lameda=1e-4;
% Y1=zeros(6);
for itMap = 1:nMap
    for k=1:length(X)
        YY1=Ygoal(:,k);% groundtruth
        YY2=Y(:,k); % estimated
        %    rotMat21 = paramToTransMatnew(YY1);
        %    XX1=transCellnew(rotMat21,Xmodel,0);
        rotMat22 = paramToTransMatnew(YY2);%%%%%%%%%%%%%%
        XX2=transCellnew(rotMat22,Xmodel,0);
        for j=1:6
                   ykm(:,j)=YY1(:,1)-Ykm(:,j);%%%%%%%%%%%%%%%%%%
                   rotMatkm = paramToTransMatnew(ykm(:,j));
                   Xkm = transCellnew(rotMatkm,Xmodel,0);
            %        MSEkm(k,j)=immseNAN(XX1',Xkm');
%             ykm1(:,j)=YY2(:,1)+Ykm(:,j);
%             rotMatkm1 = paramToTransMatnew(ykm1(:,j));
%             Xkm1 = transCellnew(rotMatkm1,Xmodel,0);
            MSEkm2(k,j)=immseNAN(XX2',Xkm');
        end
    end
    N = normalize(MSEkm2,2);
    for i=1:6
        [mu(i,1),sigma(i,1)]=normfit(N(:,i));
    end
    Mu=min(mu);
    Index=find(mu==Mu);
    for p=1:6
        Yy(p,1)=normpdf(mu(p,1),mu(Index,1),sigma(Index,1));
    end
%     N2ory=8*(ones(6,1)-Yy).^itMap;%%%%%%%%%%%%%%%%%%%%%%%%none(negative and large is not good)
    N2ory=0.5*(ones(6,1)-Yy).^itMap;
    MSEMSE=exp(N2ory);
    A=pinv(diag(MSEMSE.^2))*lameda*length(X);
  featX = extFeat(X,pcmptFeat);
%     featX = computeFeature(Xmodel,X,sigmaSq,normals);
    B=2*featX*featX';
    % find difference between current estimates and goals
    featY = Y - Ygoal;
    C=2*featY*featX';
    D{itMap} = sylvester(A,B,C);
    Y = Y - D{itMap}*featX;
    DH{itMap} = D{itMap}*featX;
    DH_monoto{itMap} = diag(featY'*DH{itMap});
    
    rotMat = paramToTransMatnew(Y);
    
    X = transCellnew(rotMat,Xori,0);
    
    error(itMap) = norm(Ygoal-Y,'fro')^2/length(X);
    fprintf('ItWDO: %d, err: %f\n',itMap,error(itMap))
    
    s=0;
    if ~(itMap==1)
        deltaD=D{itMap}-D{itMap-1};
        for j=1:size(deltaD,2)
            s = s+ norm(deltaD(:,j));
            DD=s/size(deltaD,2);
        end
        if DD<10^(-4)
            break;
        end
    end
end

% save data

DM = struct();
DM.Dmap = D;
DM.runOrder = 1:length(D);
DM.trainErr = error;
DM.Xmodel = Xmodel;
DM.Dh = DH_monoto;
DM.DH = DH;
DM.pcmptFeat = pcmptFeat;
DM.normals = normals;
end


