% % load('\\bournemouth.ac.uk\data\Staff\Home\zhaoy\MATLAB\Newtestmodel2\GDO\Dancingchildren\DMDO.mat');
% % load('\\bournemouth.ac.uk\data\Staff\Home\zhaoy\MATLAB\Newtestmodel2\GDO\Dancingchildren\DMGDO.mat');
x1 = 1:1:30;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Training Error
% figure
% subplot(1,2,1)
% plot(x1,DMDO.trainErr,'o','MarkerFaceColor',[0.3010 0.7450 0.9330]);
% hold on
% plot(x1,zeros(1,30),'-','LineWidth',2);
% ylim([-0.05 0.5])
% title('DO Training Error')
% 
% subplot(1,2,2)
% plot(x1,DMGDONN.trainErr,'o','MarkerFaceColor',[0.9290 0.6940 0.1250]);
% hold on
% plot(x1,zeros(1,30),'-','LineWidth',2);
% ylim([-0.05 0.5])
% title('GDO Training Error');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Monotonicity of DH
figure
for q = 1:6
    subplot(2,3,q)
  for k=7*q-6:7*q % test number
      for i=1:length(DM01.Dh)% iteration number
          Dhh(k,i)=DM01.Dh{1,i}(k,1);
      end
      plot(x1,Dhh(k,:),'-.','LineWidth',2);
      ylim([-0.05 0.8]);
      hold on
      legendInfo{k}=['sample no. ', num2str(k)]; % or whatever is appropriate
  end
  legend(legendInfo{1,7*q-6:7*q})
  hold on
  plot(x1,zeros(1,30),'-','LineWidth',0.5);
  xlabel('Iterative number');
  set(gca,'XTick',[1:2:30]); 
  title ('The criteria to judge the monotonicity of DH (DO[Original+FPFH])');
end
figure
for q = 1:6
    subplot(2,3,q)
  for k=7*q-6:7*q % test number
      for i=1:length(DM02.Dh)% iteration number
          Dhh(k,i)=DM02.Dh{1,i}(k,1);
      end
      plot(x1,Dhh(k,:),'-.','LineWidth',2);
      ylim([-0.05 0.8]);
      hold on
      legendInfo{k}=['sample no. ', num2str(k)]; % or whatever is appropriate
  end
  legend(legendInfo{1,7*q-6:7*q})
  hold on
  plot(x1,zeros(1,30),'-','LineWidth',0.5);
  xlabel('Iterative number');
  set(gca,'XTick',[1:2:30]); 
  title ('The criteria to judge the monotonicity of DH (DO[FPFH])');
end
figure
for q = 1:6
    subplot(2,3,q)
  for k=7*q-6:7*q % test number
      for i=1:length(DM03.Dh)% iteration number
          Dhh(k,i)=DM03.Dh{1,i}(k,1);
      end
      plot(x1,Dhh(k,:),'-.','LineWidth',2);
      ylim([-0.05 0.8]);
      hold on
      legendInfo{k}=['sample no. ', num2str(k)]; % or whatever is appropriate
  end
  legend(legendInfo{1,7*q-6:7*q})
  hold on
  plot(x1,zeros(1,30),'-','LineWidth',0.5);
  xlabel('Iterative number');
  set(gca,'XTick',[1:2:30]); 
  title ('The criteria to judge the monotonicity of DH (GDO[Original+FPFH])');
end
%%%%%%%%%%%%%%%%%%%%%%%%%% the sum of the sample monotonicity
figure
DM01 = DMRDONNWUN;
SMDh01 = zeros(length(DM01.Dh),1);
% SMDh02 = zeros(length(DM02.Dh),1);
% SMDh03 = zeros(length(DM03.Dh),1);
% SMGDh = zeros(length(DMGDONN.Dh),1);
for iter = 1: length(DM01.Dh)
    SMDh01(iter,1) = sum(DM01.Dh{1,iter});
%     SMDh02(iter,1) = sum(DM02.Dh{1,iter});
%     SMDh03(iter,1) = sum(DM03.Dh{1,iter});
end
subplot(1,3,1)
plot(x1,SMDh01,'o','MarkerFaceColor',[0.3010 0.7450 0.9330],'MarkerSize',8);
ylim([-5,70]);
hold on
plot(x1,zeros(1,length(DM01.Dh)),'-.','LineWidth',2);
hold on
text(x1(end),SMDh01(end,1),'s','color','g');
legend('DO[Original+FPFH]');
subplot(1,3,2)
plot(x1,SMDh02,'o','MarkerFaceColor',[0.9290 0.6940 0.1250],'MarkerSize',8);
ylim([-5,70]);
hold on
plot(x1,zeros(1,length(DM02.Dh)),'-.','LineWidth',2);
legend('DO[FPFH]');
subplot(1,3,3)
plot(x1,SMDh03,'o','MarkerFaceColor',[0.4660, 0.6740, 0.1880],'MarkerSize',8);
ylim([-5,70]);
hold on
plot(x1,zeros(1,length(DM03.Dh)),'-.','LineWidth',2);
legend('GDO[Original+FPFH]');
