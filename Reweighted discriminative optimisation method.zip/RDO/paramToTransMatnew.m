function [E] = paramToTransMatnew(E)
%PROJTOROW turn multiple 6D vectors into transformation matrices
Eout = cell(size(E,2),1);
% Eout = zeros(4,4);
for i = 1:size(E,2)
    Eout{i} = [expMapSE3(E(:,i));[0,0,0,1]];
end
E = Eout;
end