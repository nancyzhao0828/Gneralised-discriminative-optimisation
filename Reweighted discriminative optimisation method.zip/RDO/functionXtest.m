function [Xtest1,moving] = functionXtest(ptCloudCurrent,gridSize)
moving = pcdownsample(ptCloudCurrent, 'gridAverage', gridSize);
modelFulltest=moving.Location';
modelFulltest = bsxfun(@minus,modelFulltest,min(modelFulltest,[],2));
modelFulltest = bsxfun(@minus,modelFulltest,max(modelFulltest,[],2)/2);
modelFulltest = modelFulltest / max(abs(modelFulltest(:)));
pcModeltest = pointCloud(modelFulltest');
%  pcModeltest = pcdownsample(pcModeltest,'gridAverage',0.13);
modelSmptest = pcModeltest.Location';
Xtest1={modelSmptest};
end

