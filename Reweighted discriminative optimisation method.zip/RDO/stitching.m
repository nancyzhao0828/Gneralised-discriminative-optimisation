clc;
clear;
dataFile = fullfile(toolboxdir('vision'), 'visiondata', 'livingRoom.mat');
load(dataFile);
ptCloudRef = livingRoomData{1};
ptCloudCurrent = livingRoomData{2};
[DMRDONNWUN,fixed] = DOfunction(ptCloudRef);



gridSize = 0.1;  
[Xtest1,moving] = functionXtest(ptCloudCurrent,gridSize);
% Moving = pointCloud((Xtest1{1,1})');
[ttformDO] = functionform(DMDO,Xtest1);
% [ttformRDONN] = functionform(DMRDONN,Xtest1);
% [ttformRDONNWD01] = functionform(DMRDONNWD01,Xtest1);
% [ttformRDONNWU] = functionform(DMRDONNWU,Xtest1);
[ttformRDONNWUN] = functionform(DMRDONNWUN,Xtest1);
ptCloudAlignedDO = pctransform(ptCloudCurrent,ttformDO);
% ptCloudAlignedRDONN = pctransform(ptCloudCurrent,ttformRDONN);
% ptCloudAlignedRDONNWD01 = pctransform(ptCloudCurrent,ttformRDONNWD01);
% ptCloudAlignedRDONNWU = pctransform(ptCloudCurrent,ttformRDONNWU);
ptCloudAlignedRDONNWUN = pctransform(ptCloudCurrent,ttformRDONNWUN);
mergeSize = 0.015;
ptCloudSceneDO = pcmerge(ptCloudRef, ptCloudAlignedDO, mergeSize);
% ptCloudSceneRDONN = pcmerge(ptCloudRef, ptCloudAlignedRDONN, mergeSize);
% ptCloudSceneRDONNWD01 = pcmerge(ptCloudRef, ptCloudAlignedRDONNWD01, mergeSize);
% ptCloudSceneRDONNWU = pcmerge(ptCloudRef, ptCloudAlignedRDONNWU, mergeSize);
ptCloudSceneRDONNWUN = pcmerge(ptCloudRef, ptCloudAlignedRDONNWUN, mergeSize);
figure
pcshowpair(ptCloudRef,ptCloudAlignedDO);
figure
pcshowpair(ptCloudRef,ptCloudAlignedRDONNWUN);
figure
 pcshowpair(ptCloudRef,ptCloudScene);
legend('ptCloudRef','ptCloudAlignedRDONNWUN');
figure
pcshowpair(ptCloudAlignedDO,ptCloudAlignedRDONNWUN);
% figure(1)
% subplot(2,2,1)
% pcshow(ptCloudRef)
% title('First input image','Color','w')
% drawnow
% 
% subplot(2,2,3)
% pcshow(ptCloudCurrent)
% title('Second input image','Color','w')
% drawnow
% 
% % Visualize the world scene.
% subplot(2,2,[2,4])
% pcshow(ptCloudSceneDO, 'VerticalAxis','Y', 'VerticalAxisDir', 'Down')
% title('Initial world scene')
% xlabel('X (m)')
% ylabel('Y (m)')
% zlabel('Z (m)')
% drawnow
% 
% % figure(2)
% % subplot(2,2,1)
% % pcshow(ptCloudRef)
% % title('First input image','Color','w')
% % drawnow
% % 
% % subplot(2,2,3)
% % pcshow(ptCloudCurrent)
% % title('Second input image','Color','w')
% % drawnow
% % 
% % % Visualize the world scene.
% % subplot(2,2,[2,4])
% % pcshow(ptCloudSceneRDONN, 'VerticalAxis','Y', 'VerticalAxisDir', 'Down')
% % title('Initial world scene')
% % xlabel('X (m)')
% % ylabel('Y (m)')
% % zlabel('Z (m)')
% % drawnow
% % 
% % figure(3)
% % subplot(2,2,1)
% % pcshow(ptCloudRef)
% % title('First input image','Color','w')
% % drawnow
% % 
% % subplot(2,2,3)
% % pcshow(ptCloudCurrent)
% % title('Second input image','Color','w')
% % drawnow
% % 
% % % Visualize the world scene.
% % subplot(2,2,[2,4])
% % pcshow(ptCloudSceneRDONNWD01, 'VerticalAxis','Y', 'VerticalAxisDir', 'Down')
% % title('Initial world scene')
% % xlabel('X (m)')
% % ylabel('Y (m)')
% % zlabel('Z (m)')
% % drawnow
% % 
% % figure(4)
% % subplot(2,2,1)
% % pcshow(ptCloudRef)
% % title('First input image','Color','w')
% % drawnow
% % 
% % subplot(2,2,3)
% % pcshow(ptCloudCurrent)
% % title('Second input image','Color','w')
% % drawnow
% % 
% % % Visualize the world scene.
% % subplot(2,2,[2,4])
% % pcshow(ptCloudSceneRDONNWU, 'VerticalAxis','Y', 'VerticalAxisDir', 'Down')
% % title('Initial world scene')
% % xlabel('X (m)')
% % ylabel('Y (m)')
% % zlabel('Z (m)')
% % drawnow
% 
% figure(5)
% % subplot(2,2,1)
% % pcshow(ptCloudRef)
% % title('First input image','Color','w')
% % drawnow
% % 
% % subplot(2,2,3)
% % pcshow(ptCloudCurrent)
% % title('Second input image','Color','w')
% % drawnow
% % 
% % % Visualize the world scene.
% % subplot(2,2,[2,4])
% % pcshow(ptCloudSceneRDONNWUN, 'VerticalAxis','Y', 'VerticalAxisDir', 'Down')
% % title('Initial world scene')
% % xlabel('X (m)')
% % ylabel('Y (m)')
% % zlabel('Z (m)')
% % drawnow
figure
subplot(2,1,1)
pcshow(ptCloudSceneDO, 'VerticalAxis','Y', 'VerticalAxisDir', 'Down')
subplot(2,1,2)
pcshow(ptCloudSceneRDONNWUN, 'VerticalAxis','Y', 'VerticalAxisDir', 'Down')