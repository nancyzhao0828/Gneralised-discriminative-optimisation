% function [DMDO,DMDON,fixed] = DOfunction(ptCloudRef)
function [DMRDONNWUN,fixed] = DOfunction(ptCloudRef)
% dataFile = fullfile(toolboxdir('vision'), 'visiondata', 'livingRoom.mat');
% load(dataFile);
% ptCloudRef = livingRoomData{1};
% ptCloudCurrent = livingRoomData{2};
gridSize = 0.1;
%training data
fixed = pcdownsample(ptCloudRef, 'gridAverage', gridSize);
% modelFull=fixed.Location';
% modelFull = bsxfun(@minus,modelFull,min(modelFull,[],2));
% modelFull = bsxfun(@minus,modelFull,max(modelFull,[],2)/2);
% modelFull = modelFull / max(abs(modelFull(:)));
% pcModel = pointCloud(modelFull');
% pcModel = pcdownsample(pcModel,'gridAverage',0.13);
pcModel = pcdownsample(fixed,'gridAverage',0.16);
modelFull=pcModel.Location';
modelFull = bsxfun(@minus,modelFull,min(modelFull,[],2));
modelFull = bsxfun(@minus,modelFull,max(modelFull,[],2)/2);
modelFull = modelFull / max(abs(modelFull(:)));
pcModel = pointCloud(modelFull');
modelSmp = pcModel.Location';
nTrain = 3000; % number of training samples

% generate train set
fprintf('Generating %d training data\n',nTrain);

% cells for saving generated data
Rtrain = cell(1,nTrain);
Xtrain = cell(1,nTrain);
Ytrain = cell(1,nTrain);

for i = 1:nTrain
    
    % ************ Be careful about these parameters! If set too high then
    % the alignment could away from correct pose!
    
    % setting for generate train set
    opt = struct( ...
        'vertex',modelSmp, ... % the template point cloud for generating data
        'nVertices',400+ceil(400*rand(1)),... % number of points
        'rotation',9*(sqrt(rand())),...
        'translation',[-rand(1)*0.01,-rand(1)*0.5,-rand(1)*0.1]',... % random translation
        'nOutlier',max(0,ceil((rand(1)-0.3)/0.7*300)),... % number of outliers
        'outlBd',1.5*[-1 1;-1 1;-1 1],... % boundaries of outliers
        'noiseSd',0.05*rand(),... % noise sd
        'rRmvPt',rand()*0.5+0.4); % percentage of incompleteness for model
    % sign(randn(3,1)).*
%     [0,-rand(1)*0.05,rand(1)*0.01]'
    % generate train data
%     [Xtrain{i},Rtrain{i},Ytrain{i}] = generateData(opt,tform);
      [Xtrain{i},Rtrain{i},Ytrain{i}] = generateData(opt);
    % generate structured outliers
%     Xtrain{i} = [Xtrain{i} ...
%         bsxfun(@plus,randn(3,ceil(50+rand*150))/(4+5*rand),sign(rand(3,1)-0.5).*rand(3,1)*1.5)];
    Rtrain{i} = Rtrain{i}(1:3,:);
    Ytrain{i} = Ytrain{i}(1:3,:);
end
% load('\\bournemouth.ac.uk\data\Staff\Home\zhaoy\MATLAB\SDMvsDO\Newtestmodel2\xinmodel002\Stitiching\MATLABTrainingdata2907.mat');
nMap = 30; % number of maps
sigmaSq = 0.03; % will be used for calculating feature function h
% gridStep = 0.05;
% beta=0.1;
% [DMDO,trainErr] = learnDO(modelSmp',Xtrain,Ytrain,nMap,sigmaSq);
% [DMRDONN,errornn] = learnDOnewnew(modelSmp',Xtrain,Ytrain,nMap,sigmaSq);
% [DMRDONNWD01,errornnwd01] = learnDOnewnewWD01(modelSmp',Xtrain,Ytrain,nMap,sigmaSq);
% [DMRDONNWU,errornnwu] = learnDOnewnewWU(modelSmp',Xtrain,Ytrain,nMap,sigmaSq);
% [DMRDONNWUN,errornnwun] = learnDOnewnewWUN(modelSmp',Xtrain,Ytrain,nMap,sigmaSq);
 gridStep=0.05;
% [DMDO,trainErr] = learnDO(modelSmp,Xtrain,Ytrain,nMap,sigmaSq,gridStep);
% [DMRDONN,errornn] = learnDOnewnew(modelSmp,Xtrain,Ytrain,nMap,sigmaSq,gridStep);
% [DMRDONNWD01,errornnwd01] = learnDOnewnewWD01(modelSmp,Xtrain,Ytrain,nMap,sigmaSq,gridStep);
% [DMRDONNWU,errornnwu] = learnDOnewnewWU(modelSmp,Xtrain,Ytrain,nMap,sigmaSq,gridStep);
[DMRDONNWUN,errornnwun] = learnDOnewnewWUN(modelSmp,Xtrain,Ytrain,nMap,sigmaSq,gridStep);
end

