 clc;
 clear;
 nMap = 30; % number of maps
 sigmaSq = 0.03; % will be used for calculating feature function h
 beta=0.1;
 gridStep=0.05;
nTrain = 3000; % number of training samples
load('C:\Users\zy080\Documents\MATLAB\RDO\RDO\Handtest\DM.mat')
load('C:\Users\zy080\Documents\MATLAB\RDO\RDO\Handtest\Trainingdata3000.mat')
% %  load('C:\Users\zy080\Documents\MATLAB\Dog\Child\dataset.mat')
%  modelFull = PCloud.Location';
% % remove mean and scale so that it fits in the box of [-1,1]^3
% modelFull = bsxfun(@minus,modelFull,min(modelFull,[],2));
% modelFull = bsxfun(@minus,modelFull,max(modelFull,[],2)/2);
% modelFull = modelFull / max(abs(modelFull(:)));
% % %
% pcModel = pointCloud(modelFull');
% pcModel = pcdownsample(pcModel,'gridAverage',0.12);
% modelSmp = pcModel.Location';
% % % Xmodel=modelSmp;
% % % [pcmptFeat,normals] = precomputeFeature(Xmodel,sigmaSq,gridStep);
% % % load('C:\Users\zy080\Documents\MATLAB\RDO\RDO\handTest\DM.mat')
% % % modelSmp=DMDO.Xmodel;
% % % pcmptFeat=DMDO.pcmptFeat;
% % % normals=DMDO.normals;
% Rtrain = cell(1,nTrain);
% Xtrain = cell(1,nTrain);
% Ytrain = cell(1,nTrain);
% for i = 1:nTrain
% 
% %   Be careful about these parameters! If set too high then
% %    the alignment could away from correct pose!
% 
% %    setting for generate train set
%      opt = struct( ...
%         'vertex',modelSmp, ... % the template point cloud for generating data
%         'nVertices',400+ceil(400*rand(1)),... % number of points
%         'rotation',60*(sqrt(rand())),... % angle for generating random rotation
%         'translation',sign(randn(3,1)).*rand(3,1)*0.3,... % random translation
%         'nOutlier',max(0,ceil((rand(1)-0.3)/0.7*300)),... % number of outliers
%         'outlBd',1.5*[-1 1;-1 1;-1 1],... % boundaries of outliers
%         'noiseSd',0.05*rand(),... % noise sd
%         'rRmvPt',rand()*0.5+0.4); % percentage of incompleteness for model
% 
% %     enerate train data
%     [Xtrain{i},Rtrain{i},Ytrain{i}] = generateData(opt);
%     Xtrain{i} = [Xtrain{i} ...
%         bsxfun(@plus,randn(3,ceil(50+rand*150))/(4+5*rand),sign(rand(3,1)-0.5).*rand(3,1)*1.5)];
% %     generate structured outliers
%     Rtrain{i} = Rtrain{i}(1:3,:);
%     Ytrain{i} = Ytrain{i}(1:3,:);
% end
% % % % clear Rtrain model modelFull PCloud
[DMDO,trainErr] = learnDO(modelSmp,Xtrain,Ytrain,nMap,sigmaSq,gridStep);
[DMRDONN,errornn] = learnDOnewnew(modelSmp,Xtrain,Ytrain,nMap,sigmaSq,gridStep);
[DMRDONNWD01,errornnwd01] = learnDOnewnewWD01(modelSmp,Xtrain,Ytrain,nMap,sigmaSq,gridStep);
[DMRDONNWU,errornnwu] = learnDOnewnewWU(modelSmp,Xtrain,Ytrain,nMap,sigmaSq,gridStep);
[DMRDONNWUN,errornnwun] = learnDOnewnewWUN(modelSmp,Xtrain,Ytrain,nMap,sigmaSq,gridStep);
clc;
clear;
% load('C:\Users\zy080\Documents\MATLAB\Dog\Child\matlabDM.mat')
load('C:\Users\zy080\Documents\MATLAB\RDO\RDO\Happytest\DM.mat')
load('C:\Users\zy080\Documents\MATLAB\RDO\RDO\Happytest\Outliers\Outliers500.mat')
iRSDO=[];MSEDO=[];
iRSRDO=[];MSERDO=[];
iRSRDO01=[];MSERDO01=[];
iRSRDO03=[];MSERDO03=[];
iRSRDOWD01=[];MSERDOWD01=[];
iRSRDOWD02=[];MSERDOWD02=[];
iRSRDOWD03=[];MSERDOWD03=[];
iRSRDOWD04=[];MSERDOWD04=[];
iRSRDOWD05=[];MSERDOWD05=[];
iRSRDOWU=[];MSERDOWU=[];
iRSRDOWUN=[];MSERDOWUN=[];
iRSRDOWUN01=[];MSERDOWUN01=[];
iRSRDOWU01=[];MSERDOWU01=[];
iRSRDOWU02=[];MSERDOWU02=[];
RuntimeRDO=zeros(1,75);
RuntimeDO=zeros(1,75);
RuntimeDO01=zeros(1,75);
RuntimeDO03=zeros(1,75);
RuntimeDOWD01=zeros(1,75);
RuntimeDOWD02=zeros(1,75);
RuntimeDOWD03=zeros(1,75);
RuntimeDOWU=zeros(1,75);
RuntimeDOWUN=zeros(1,75);
RuntimeDOWUN01=zeros(1,75);
RuntimeDOWU01=zeros(1,75);
RuntimeDOWU02=zeros(1,75);
RuntimeDOWD04=zeros(1,75);
RuntimeDOWD05=zeros(1,75);
for k=1:length(Xtest)
    Xtest{1,k}=single(Xtest{1,k});
    Ytest{1,k}=single(Ytest{1,k});
end
for k=1:75
    Xtest1=Xtest{1,k};
    Rtest1=Rtest{1,k};
    [iRSRDO,MSERDO,RuntimeRDO(1,k)] = DOevaluation01(DMRDONN,Rtest1,Xtest1,MSERDO,iRSRDO);
    [iRSDO,MSEDO,RuntimeDO(1,k)] = DOevaluation01(DMDO,Rtest1,Xtest1,MSEDO,iRSDO);
    [iRSRDOWD01,MSERDOWD01,RuntimeDOWD01(1,k)] = DOevaluation01(DMRDONNWD01,Rtest1,Xtest1,MSERDOWD01,iRSRDOWD01);
    [iRSRDOWU,MSERDOWU,RuntimeDOWU(1,k)] = DOevaluation01(DMRDONNWU,Rtest1,Xtest1,MSERDOWU,iRSRDOWU);
    [iRSRDOWUN,MSERDOWUN,RuntimeDOWUN(1,k)] = DOevaluation01(DMRDONNWUN,Rtest1,Xtest1,MSERDOWUN,iRSRDOWUN);
end
mRDO=mean(MSERDO);
mRuntimeRDO=mean(RuntimeRDO);
mDO=mean(MSEDO);
mRuntimeDO=mean(RuntimeDO);
mRDOWD01=mean(MSERDOWD01);
mRuntimeRDOWD01=mean(RuntimeDOWD01);
mRDOWDU=mean(MSERDOWU);
mRuntimeRDOWU=mean(RuntimeDOWU);
mRDOWDUN=mean(MSERDOWUN);
mRuntimeRDOWUN=mean(RuntimeDOWUN);
A1=find(iRSDO~=1); 
B=find(iRSRDOWD01~=1);
C=find(iRSRDOWU~=1);
D=find(iRSRDOWUN~=1);
E=find(iRSRDO~=1);
a=length(find(iRSDO~=1));
b=length(find(iRSRDOWD01~=1));
c=length(find(iRSRDOWU~=1));
d=length(find(iRSRDOWUN~=1));
e=length(E);
ra=1-a/length(iRSDO);
rb=1-b/length(iRSRDOWD01);
rc=1-c/length(iRSRDOWD01);
rd=1-d/length(iRSRDOWD01);
re=1-e/length(iRSDO);

%%%%% RDO WD01 WUN WU
MMDORDO=MSEDO-MSERDO;
rdr= length(find(MMDORDO>0))/length(MMDORDO);
MMDOWD = MSEDO-MSERDOWD01;
rdwd = length(find(MMDOWD>0))/length(MMDOWD);
MMDOWUN = MSEDO-MSERDOWUN;
rdwun = length(find(MMDOWUN>0))/length(MMDOWD);
MMDOWU = MSEDO-MSERDOWU;
rdwu = length(find(MMDOWU>0))/length(MMDOWD);