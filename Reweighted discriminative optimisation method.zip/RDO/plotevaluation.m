clc;
clear;
M=xlsread('C:\Users\zy080\Desktop\human.xlsx');
M(isnan(M(:,1)),:) = [];
[r,c] = size(M);
n = r/3;
for k =1 : 24
    SI = M( 1:3:3*k-2, :);
    SM = M(2:3:3*k-1, :);
    SC= M( 3:3:3*k, :);
end
n1 = n/4;
% Successful Registration Rate
% ISR = SI(1:6, :);
% ISN =SI(7:12, :);
% ISI = SI(13:18, :);
% ISO = SI (19:24, :);
% % MSE
% MSR = SM(1:6, :);
% MSN =SM(7:12, :);
% MSI = SM(13:18, :);
% MSO = SM(19:24, :); 
%Computation time
CSR = SC(1:6, :);
CSN =SC(7:12, :);
CSI = SC(13:18, :);
CSO = SC(19:24, :); 
ISR=SI(1:5,:);
MSR=SM(1:5,:);
CSR=SC(1:5,:);
% Rotation = [0 30 60 90 120 150];
Rotation = [0 15 30 45 60];
Noise =[0 0.02 0.04 0.06 0.08 0.1];
Outliers= [0 100 200 300 400 500];
Incomplete = [0 0.15 0.30 0.45 0.60 0.75];
%%%%%%%%%%%%%%% plot figure
%%%% Successful Registration Rate
figure(1)
ISR1=sort(ISR,'descend');
plot( Rotation, ISR1, '-.s','LineWidth', 5, 'MarkerSize',12);
set(gca,'FontSize',18)
ylim([0, 1.15])
legend({'DO','RDO','ICP','CPD','NDT','IRLS'},'FontSize',18, 'Location','north', 'NumColumns', 4);
figure(2)
ISN1=sort(ISN,'descend');
plot( Noise, ISN1, '-.s','LineWidth', 5, 'MarkerSize',12);
 set(gca,'FontSize',18)
 ylim([min(min(ISN1))-0.1,1.03])
legend({'DO','RDO','ICP','CPD','NDT','IRLS'},'FontSize',18, 'Location','north', 'NumColumns', 4);
figure(3)
ISO1=sort(ISO,'descend');
plot( Outliers, ISO1, '-.s','LineWidth', 5, 'MarkerSize',12);
set(gca,'FontSize',18)
ylim([min(min(ISO1))-0.1,1.01])
legend({'DO','RDO','ICP','CPD','NDT','IRLS'},'FontSize',18, 'Location','north', 'NumColumns', 4);
figure(4)
ISI1=sort(ISI,'descend');
plot( Incomplete, ISI1, '-.s','LineWidth', 5, 'MarkerSize',12);
set(gca,'FontSize',18)
ylim([min(min(ISI1)),1.08])
legend({'DO','RDO','ICP','CPD','NDT','IRLS'},'FontSize',18, 'Location','north', 'NumColumns', 4);
%%%%%%%% Mean Square Error
figure(1)
MSR1=sort(MSR);
plot( Rotation, MSR1, '-.s','LineWidth', 5, 'MarkerSize',12);
set(gca,'FontSize',18)
set(gca, 'YScale', 'log')
% ylim([0,0.7])
legend({'DO','RDO','ICP','CPD','NDT','IRLS'},'FontSize',18, 'Location','north', 'NumColumns', 4);
figure(2)
MSN1=sort(MSN);
plot( Noise, MSN1, '-.s','LineWidth', 5, 'MarkerSize',12);
 set(gca,'FontSize',18)
%  ylim([10^(-5),10^(-1)])
%  set(gca, 'YScale', 'log')
legend({'DO','RDO','ICP','CPD','NDT','IRLS'},'FontSize',18, 'Location','north', 'NumColumns', 4);
figure(3)
MSO1=sort(MSO);
plot( Outliers, MSO1, '-.s','LineWidth', 5, 'MarkerSize',12);
set(gca,'FontSize',18)
set(gca, 'YScale', 'log')
legend({'DO','RDO','ICP','CPD','NDT','IRLS'},'FontSize',18, 'Location','north', 'NumColumns', 4);
figure(4)
MSI1=sort(MSI);
plot( Incomplete, MSI1, '-.s','LineWidth', 5, 'MarkerSize',12);
set(gca,'FontSize',18)
set(gca, 'YScale', 'log')
% ylim([10^(-3.5),10^(-0.8)])
legend({'DO','RDO','ICP','CPD','NDT','IRLS'},'FontSize',18, 'Location','north', 'NumColumns', 4);
%%%%%%%% Computation Time
figure(1)
CSR1=sort(CSR);
plot( Rotation, CSR1, '-.s','LineWidth', 5, 'MarkerSize',12);
set(gca,'FontSize',18)
set(gca, 'YScale', 'log')
legend({'DO','RDO','ICP','CPD','NDT','IRLS'},'FontSize',18, 'Location','north', 'NumColumns', 4);
figure(2)
CSN1=sort(CSN);
plot( Noise, CSN1, '-.s','LineWidth', 5, 'MarkerSize',12);
 set(gca,'FontSize',18)
 ylim([10^(-5),10^(-1)])
 set(gca, 'YScale', 'log')
legend({'DO','RDO','ICP','CPD','NDT','IRLS'},'FontSize',18, 'Location','north', 'NumColumns', 4);
figure(3)
CSO1=sort(CSO);
plot( Outliers, CSO1, '-.s','LineWidth', 5, 'MarkerSize',12);
set(gca,'FontSize',18)
set(gca, 'YScale', 'log')
ylim([10^(-4),10^(-0)])
legend({'DO','RDO','ICP','CPD','NDT','IRLS'},'FontSize',18, 'Location','north', 'NumColumns', 4);
figure(4)
CSI1=sort(CSI,'descend');
plot( Incomplete, CSI1, '-.s','LineWidth', 5, 'MarkerSize',12);
set(gca,'FontSize',18)
set(gca, 'YScale', 'log')
ylim([10^(-3),10^(-0.8)])
legend({'DO','RDO','ICP','CPD','NDT','IRLS'},'FontSize',18, 'Location','north', 'NumColumns', 4);



%  hold on
% ylabel('Computation Time','FontSize',24);
% 
% hold on
% ylabel('Mean Square Error','FontSize',24);
% 
% hold on
% ylabel('Success Rate','FontSize',24);