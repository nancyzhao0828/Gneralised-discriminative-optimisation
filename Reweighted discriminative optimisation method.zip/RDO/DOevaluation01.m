function [iRSRDO,MSERDO,Runtime] = DOevaluation01(DM,Rtest1,Xtest1,MSERDO,iRSRDO)
   maxIter = 1000;
   stopThres = 0.001;
   starttime_RDO = tic;
   DM.Xmodel=single(DM.Xmodel);
   [RDOYout,Ystep,Xstep] = inferJX(DM,{Xtest1},maxIter,stopThres);%RDO
    Runtime  = toc(starttime_RDO);
   if size(DM.Xmodel,2)>3
   Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*DM.Xmodel,Rtest1(1:3,4));% groundtruth
   else
   Xgt = bsxfun(@plus,Rtest1(1:3,1:3)*DM.Xmodel',Rtest1(1:3,4));% groundtruth   
   end
   Xgts = Xstep{end}{1,1};
%    XgtsCHANG = XstepCHANG{end}{1,1};
   [irsRDO, mseRDO,judgement ] = isRegisterSuccessful( Xgt', Xgts');
   iRSRDO=[iRSRDO;irsRDO];
   MSERDO=[MSERDO;mseRDO];
end